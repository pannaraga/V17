# Dashboard page override

Inherits `MASTER.md`. This page adds:
- Four workspace tabs: Overview, Connections, Public Intelligence, Advanced Lab.
- Compact left-side research controls with channel-only fields disclosed only for Existing Channel / Both modes.
- Theme selector supports System, Light, and Dark.
- Overview prioritizes measured coverage, score status, sampled evidence, provider readiness, and explicit limitations.
- Detailed JSON remains available in expanders rather than dominating the primary scan path.
- Mobile tabs remain horizontally scrollable; metric columns and controls reflow to a single column.
