# V17 Niche Intelligence — Signal Atelier Design System

## Product context
Evidence-first YouTube niche and market intelligence workspace. Primary users are solo creators, channel operators, and research-oriented teams who compare opportunity signals without confusing public competitor evidence with private channel analytics. Locale: Indonesian-friendly labels with established English technical terms. Platform: Streamlit, desktop-first and responsive down to 320 CSS px.

## Experience architecture
- **Overview:** research status, coverage, sample size, provider readiness, public competitor sample diagnostics, results, limitations.
- **Research controls:** compact sidebar for niche, market, language, mode, date range, sample size, and primary run action.
- **Connections:** API keys, quota, OAuth accounts, private Analytics, privacy/security notes.
- **Public Intelligence:** public SERP history and public-page research.
- **Advanced Lab:** evidence-bundle analysis, persistent job/checkpoint monitor and machine-readable details.

Primary action is Run research. Credential and advanced operations are progressively disclosed. Private channel Analytics remains explicitly separated from public competitor data.

## Visual direction — Signal Atelier
A distinctive editorial analytics aesthetic: precise typography, mineral/ink palette, subtle signal-green accents, thin borders, restrained depth, and a quiet grid motif. Avoid generic neon gradients, excessive glassmorphism, noisy decoration, and dashboard-card overload.

## Semantic tokens
| Role | Light | Dark |
|---|---|---|
| Canvas | `#F4F5F1` | `#101719` |
| Surface | `#FFFFFF` | `#182326` |
| Elevated | `#FFFFFF` | `#202E31` |
| Text | `#17232B` | `#EAF1EE` |
| Muted | `#64727A` | `#A1B2AD` |
| Border | `#DCE3DF` | `#304144` |
| Primary | `#176B62` | `#78CFC0` |
| Accent | `#C6E86B` | `#C6E86B` |
| Danger | `#B74747` | `#FF8989` |
| Warning | `#9B681A` | `#E7BD70` |
| Focus | `#176B62` | `#C6E86B` |

## Typography and layout
- System UI sans stack; robust fallback for Indonesian and mixed technical strings.
- Monospace stack for IDs, JSON, and evidence identifiers.
- Fluid heading scale; body 14–16px; captions at least 12px.
- Wide content canvas; cards wrap fluidly; text-bearing surfaces grow with content.
- Mobile: columns collapse, sidebar remains accessible, tables scroll within their own region, labels wrap.

## Components and states
- Sidebar research controls: persistent labels, concise helper text, bounded localized query-variant budget, primary CTA, disabled state until topic exists.
- Workspace tabs: clear active state, keyboard focus, concise labels.
- Metric surfaces: value + explanatory label; never invent missing values.
- Status panels: text/icon plus color; color is never the only signal.
- Data tables: full-width, readable headers, horizontal overflow isolated to table.
- Sensitive actions: explicit confirmation, secret masking, success/failure feedback.
- Expanders: advanced and sensitive details disclosed progressively.

## Motion and iconography
- 140–220ms transitions using opacity/transform only.
- Respect `prefers-reduced-motion`.
- Use Streamlit-native icons and labels consistently; no emoji as interface icons.
- Focus ring remains visible in keyboard navigation.

## Accessibility and quality gates
- Visible focus and keyboard-operable controls.
- Touch-friendly controls, practical 44px target baseline where framework permits.
- Text and UI contrast must be checked in rendered UI before claiming WCAG conformance.
- Statuses use text labels in addition to color.
- No essential content clipped at 320/375/414/768/1024/1440px.
- Respect reduced motion and browser zoom.
- Do not claim runtime visual or screen-reader verification without browser evidence.
