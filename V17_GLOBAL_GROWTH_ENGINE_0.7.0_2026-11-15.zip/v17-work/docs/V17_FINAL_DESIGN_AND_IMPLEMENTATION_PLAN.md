# V17 YouTube Niche Intelligence Engine
## Final Design Specification and Implementation Plan

**Status:** Design approved; V17 implementation delivered in incremental phases; see current implementation report for verified scope and remaining live-integration gates  
**Date:** 2026-11-11  
**Baseline:** V16 GOD MODE project archive  
**Product scope:** Market Entry + Existing Channel, Shorts + long-form + live, CLI + Streamlit dashboard  
**Business objective:** Balanced opportunity discovery across demand, competition, momentum, format fit, business feasibility, and risk.

---

# Part I — Final design specification

## 1. Product objective

V17 is a research and decision-support system for identifying and evaluating YouTube content opportunities. It must support:

1. **Market Entry Mode:** assess niches for a new channel using public market evidence, without requiring access to the user's YouTube account.
2. **Existing Channel Mode:** assess an existing channel using public market evidence plus optional owner-authorized YouTube Analytics data or a validated Analytics CSV import.
3. **Both Mode:** run the two analyses separately and produce a comparison. Private channel data must never be mixed into public competitor data.

The product supports Shorts, long-form, and live-streaming research, with format-specific metrics and comparisons. It provides both a command-line interface and a Streamlit dashboard over the same application services and scoring engine.

V17 is not a virality predictor, revenue guarantee, or substitute for controlled channel experiments. Scores are decision aids. Predictive claims require historical outcome data, backtesting, calibration, and out-of-sample validation.

## 2. Goals

- Produce reproducible, traceable niche research.
- Distinguish measured values, proxies, estimates, and unavailable data.
- Separate public competitor evidence from private first-party channel analytics.
- Treat formats independently before comparing their opportunity profiles.
- Compare countries only when the underlying metrics are genuinely comparable.
- Preserve raw observations and source metadata so a result can be audited.
- Make partial provider failure survivable and visible.
- Keep CLI and dashboard behavior identical for identical inputs.
- Avoid generic templates: recommendations must be generated from observed evidence and explicit user constraints.

## 3. Non-goals

- Guaranteeing views, subscribers, monetization approval, RPM, CTR, or revenue.
- Claiming absolute keyword search volume from Google Trends.
- Treating public video views as watch time, impressions, unique viewers, or audience retention.
- Treating all videos under three minutes as confirmed Shorts.
- Inferring a competitor's private Analytics metrics.
- Scraping private or access-controlled account data.
- Automatically publishing videos, changing channel settings, or performing other channel mutations.
- Using an LLM to invent missing measurements or silently fill data gaps.

## 4. User modes and workflows

### 4.1 Market Entry Mode

Inputs:
- niche/topic and optional seed keywords;
- target countries and languages;
- preferred content formats (all by default);
- production constraints (solo/team, budget band, skills, publishing capacity);
- optional audience and business constraints.

Outputs:
- demand profile by country and keyword cluster;
- competitive landscape and content-gap evidence;
- separate Shorts, long-form, and live opportunity profiles;
- balanced opportunity assessment;
- confidence, data coverage, missing evidence, and validation experiments.

No OAuth is required.

### 4.2 Existing Channel Mode

Inputs:
- channel identifier/URL;
- target countries, date range, and formats;
- optional YouTube Analytics OAuth authorization;
- or Analytics CSV import matching a documented schema;
- production and business constraints.

Outputs:
- channel performance profile from authorized first-party data;
- content and format performance by available dimensions;
- market-vs-channel fit;
- gaps between public opportunity signals and actual channel performance;
- recommendations grounded in channel-owned evidence.

OAuth is opt-in, least-privilege, read-only, and revocable. Secrets/tokens are never stored in source code or emitted in logs. CSV import remains available when OAuth is unavailable or undesired.

### 4.3 Both Mode

Runs Market Entry and Existing Channel analyses as distinct sub-results. A comparison layer may compare normalized dimensions, but must retain provenance and must not blend private metrics into public competitor aggregates.

If no channel analytics are connected/imported, Existing Channel Mode must be marked `not_configured`, not silently treated as zero or as a failed channel.

## 5. Data-source policy

### 5.1 YouTube Data API

Use `search.list` for query samples with multiple sampling strategies where supported:
- relevance;
- date;
- view count.

Use `videos.list` to retrieve available snippet, statistics, content details, and live-streaming metadata. Use `channels.list` for public channel metadata when needed.

Persist:
- query and query strategy;
- region/language parameters;
- retrieval timestamp;
- video and channel identifiers;
- published timestamp;
- views/likes/comments when exposed;
- duration;
- live metadata when exposed;
- API status and quota/error metadata that can safely be retained.

Do not use `pageInfo.totalResults` as market supply or competitor count. A search sample is a sample, not a census.

### 5.2 Google Trends

Treat 0–100 as a relative interest index, not absolute search volume. Store:
- geo;
- language/locale;
- timeframe;
- query term;
- observation timestamp;
- individual time-series points;
- provider status.

Do not directly compare independently normalized country series as if their indices share one absolute scale. Cross-country comparisons require a documented anchor/overlap calibration method. If calibration is unavailable, report country-local trends and mark cross-country demand comparison as non-comparable.

Trend features should distinguish:
- level;
- direction;
- acceleration/deceleration;
- volatility;
- seasonality;
- short-lived spikes;
- persistence.

A single recent-vs-prior average is insufficient for a robust trend classification.

### 5.3 Reddit and other community sources

Reddit is optional and must be labeled as a community-discussion signal, not a country-specific population demand measure. Record query, time window, retrieval time, and source status. Do not infer a user's country from a global Reddit result. Respect rate limits and source terms.

Additional sources may be added only through provider adapters with documented licensing, access, coverage, and comparability. No source is included merely to increase the signal count.

### 5.4 YouTube Analytics

Use owner-authorized OAuth and read-only scopes only. Import only metrics returned for supported report combinations and date ranges. Metrics such as impressions, CTR, watch time, average view duration, retention, revenue, and RPM must remain unavailable when the authorized report does not provide them.

A CSV import path must validate:
- required columns;
- date format and timezone assumptions;
- channel/video identifiers;
- numeric types and nonnegative constraints where applicable;
- duplicate rows;
- reporting period;
- metric definitions and units.

Do not estimate private channel metrics from public competitor data.

## 6. Format classification

Public YouTube API data does not provide a universally reliable Shorts flag for every public video. Duration alone is insufficient because vertical/square orientation is also relevant to Shorts eligibility.

Use explicit labels:
- `shorts_candidate`: duration-based candidate only; not confirmed as a Short;
- `long_form_candidate`;
- `live_now`;
- `upcoming_live`;
- `completed_live` only where metadata supports it;
- `unknown`.

Every classification includes `classification_method`, `classification_confidence`, and `evidence_fields`. Never label a candidate as confirmed Shorts unless an authoritative source provides that fact.

Analyze each format independently:
- Shorts: short-form candidate distribution, age-adjusted views, publishing cadence, and engagement where exposed.
- Long-form: duration, age-adjusted views, evergreen signals, and channel publishing patterns.
- Live: upcoming/current/completed state, available live metadata, duration where valid, and post-stream performance where observable.

Do not compare raw views across formats as though they had identical distribution mechanics or exposure.

## 7. Competition intelligence

Competition is a profile, not one proxy. Its components:

1. **Search saturation:** density of relevant results in a defined sample, with sample method and sample size.
2. **Competitor strength:** robust distribution of public channel/video performance; do not infer private subscriber conversion or retention.
3. **Market concentration:** concentration of sampled results among channels, using transparent concentration metrics such as HHI/Gini only when sample quality permits.
4. **New-content traction:** performance of recently published videos. Initial lifetime views/day is labeled an age-adjusted lifetime average, not real-time velocity.
5. **Content gap:** evidence of underserved subtopics/questions/formats, derived from query clusters and content coverage rather than unsupported LLM claims.

True growth velocity requires at least two timestamped observations of the same public video. V17 should store snapshots and report interval growth only when the interval is known. Without repeated snapshots, display lifetime-average views/day and label it accurately.

## 8. Demand and trend intelligence

Demand output must separate:
- relative search interest;
- observed YouTube result activity;
- community discussion activity;
- keyword coverage;
- time-series stability.

No absolute search-volume number is emitted unless a source actually provides it. Keyword translation is a candidate-generation aid, not a validated localization. Store original keyword, translated keyword, translation provider, locale, and review status. Support native-language variants and query clusters.

## 9. Balanced opportunity model

Initial configurable heuristic weights:

| Dimension | Default weight |
|---|---:|
| Demand | 25 |
| Competition opportunity | 20 |
| Momentum and stability | 15 |
| Format fit | 15 |
| Business feasibility | 15 |
| Risk resilience | 10 |
| **Total** | **100** |

These are provisional product defaults, not empirically optimized weights.

Scoring rules:
- Every component has a definition, direction, unit, transformation, source, and availability state.
- Missing values are never silently replaced with 50.
- The engine returns component values, missing reasons, and coverage.
- If essential dimensions are missing or coverage is below a configurable threshold, return `insufficient_evidence` rather than a misleading aggregate.
- When a score is permitted, document whether weights were renormalized over available components. Prefer a fixed required-dimension gate and a separately reported coverage value.
- Scores are not probabilities.
- Ranking ties and sensitivity to weight changes must be visible.
- Weight configuration is versioned and included in every report.

### Confidence is independent of score

Confidence must account for:
- source reliability;
- freshness;
- sample size and representativeness;
- source independence;
- missingness;
- consistency across independent evidence;
- localization quality;
- format classification uncertainty.

Demand and momentum derived from the same Trends series count as one source family, not two independent sources. A count of metrics is not a confidence model.

Report `confidence_level`, `confidence_reasons`, `source_families`, and `data_coverage` separately.

## 10. Business feasibility and risk

Assess user-supplied constraints and clearly labeled research evidence:
- production effort and skill requirements;
- achievable publishing cadence;
- repeatability and content supply;
- monetization route plausibility;
- copyright/reused-content exposure;
- advertiser-suitability and policy risk;
- trend dependency;
- geographic and language constraints;
- operational cost and team capacity.

Do not make legal determinations or guarantee YouTube monetization eligibility. Present policy risks as review flags and link them to official policy references in product documentation when implemented.

## 11. Data model and storage

Use SQLite for local research history and snapshot persistence in the first release. Keep the repository boundary portable so a server database can be added later without rewriting the domain layer.

Core entities:
- `research_run`: run ID, created time, input configuration, mode, algorithm version, status.
- `query_variant`: original/translated keyword, locale, query strategy, translation provenance.
- `source_observation`: provider, retrieval time, status, query parameters, source family.
- `video_snapshot`: video ID, channel ID, observed time, public metrics, duration, live metadata.
- `channel_snapshot`: channel ID, observed time, public metadata.
- `trend_observation`: geo, term, timeframe, timestamp, relative index.
- `analytics_import`: source type, channel ID, date range, schema version, import status.
- `analytics_metric`: channel/video, period, metric, value, unit, provenance.
- `opportunity_assessment`: country, niche, format, component scores, coverage, confidence, rank.
- `score_config`: versioned weights, thresholds, transformations.
- `experiment_recommendation`: hypothesis, proposed test, success metric, minimum observation window.

Store raw provider payloads only where allowed and useful; otherwise store normalized fields plus source identifiers and retrieval metadata. Apply retention limits and avoid storing OAuth secrets or unnecessary personal data.

## 12. Proposed package architecture

```text
v17_niche_intel/
  __init__.py
  config.py
  cli.py
  dashboard.py
  domain/
    models.py
    enums.py
    validation.py
    duration.py
    format_classifier.py
    demand.py
    competition.py
    business.py
    scoring.py
    confidence.py
    explainability.py
  providers/
    base.py
    youtube_data_api.py
    google_trends.py
    reddit.py
    youtube_analytics.py
  storage/
    database.py
    repositories.py
    migrations/
  services/
    query_expansion.py
    research.py
    snapshot.py
    analysis.py
    comparison.py
    reporting.py
  importers/
    analytics_csv.py
  ui/
    dashboard_views.py
    components.py
tests/
  unit/
  integration/
  contract/
  evaluation/
  fixtures/
docs/
  architecture/
  adr/
  superpowers/plans/
```

The existing `v16_god_mode` package remains available as a compatibility/deprecation facade for one transition release. The new dashboard and CLI call only V17 services. V16 scores must never be silently merged with V17 scores because their semantics differ.

## 13. CLI and dashboard requirements

### CLI

Required commands:
- `research`: run Market Entry, Existing Channel, or Both.
- `snapshot`: collect a new observation for previously sampled public videos.
- `import-analytics`: validate and import a CSV export.
- `compare`: compare countries, niches, formats, or runs.
- `report`: regenerate CSV/JSON/Markdown report from stored results.
- `doctor`: validate configuration, provider availability, database access, and OAuth configuration without exposing secrets.

All commands support structured exit codes, useful error messages, `--output`, and `--json` where applicable. API keys must come from environment variables or a local secret mechanism, never be printed.

### Dashboard

Views:
- Research setup;
- Market Entry results;
- Existing Channel results;
- Both-mode comparison;
- Format comparison;
- Country comparison;
- Evidence and data-quality inspector;
- Research history and snapshot timeline;
- CSV/JSON/Markdown export.

Include loading, empty, partial-data, provider-error, and insufficient-evidence states. Do not hide warnings behind charts.

## 14. Reliability, security, and privacy

- Set explicit connection/read timeouts.
- Bound retries, exponential backoff, and concurrency.
- Respect API quotas and provider rate limits.
- Use idempotent writes keyed by run/source/entity/observation time.
- Continue when an optional provider fails; preserve and label partial results.
- Do not retry non-retryable authentication/validation failures.
- Keep OAuth tokens out of logs, exports, fixtures, and source control.
- Use read-only OAuth scopes and explicit user authorization.
- Validate imported files and enforce size/row limits.
- Treat provider responses and community content as untrusted data.
- Pin dependency versions and scan dependency advisories before release.
- Provide a local-only default dashboard; document network exposure before remote hosting.

## 15. Evaluation and acceptance gates

### Deterministic correctness
- Unit tests for transformations, duration, format classification, score gates, confidence, ranking, locale, and missingness.
- Provider contract tests using sanitized fixtures.
- Integration tests for provider-to-storage-to-analysis flow.
- CLI smoke tests and dashboard service tests.
- CSV import tests for malformed, duplicate, empty, and valid files.

### Research quality
- Golden datasets with known expected transformations.
- Sampling tests across relevance/date/view-count query strategies.
- Sensitivity analysis for weights and sample composition.
- Cross-country comparability tests.
- Confidence calibration review.
- Human review of a stratified sample of niche reports.

### Release gates
- No silent neutral fill for missing values.
- No unsupported absolute search volume, RPM, CTR, retention, or confirmed Shorts claims.
- Every score has component explanations, coverage, confidence, and algorithm version.
- CLI and dashboard produce the same result for the same run ID/input.
- Partial provider failure is represented and does not erase valid observations.
- OAuth is opt-in, read-only, and tested with mocked authorization/report fixtures.
- Backtesting required before any predictive language is introduced.

---

# Part II — Detailed implementation plan

## 16. Work sequence and ownership

Use one accountable engineering owner for integration. Workstreams can be reviewed independently, but shared domain contracts must be agreed before parallel implementation.

| Workstream | Primary responsibility | Deliverable |
|---|---|---|
| Product/data research | Product + marketing research | Metric dictionary, evidence definitions, sampling protocol |
| Core architecture | Software/backend engineering | Domain contracts, storage, service boundaries |
| Provider integration | Data engineering | YouTube, Trends, Reddit, Analytics adapters |
| Decision science | Data/statistics | Scoring, confidence, sensitivity, evaluation harness |
| UX | Frontend/product design | CLI workflows and dashboard states |
| Quality/security | QA/security | Test gates, privacy review, release checklist |

## 17. Phase 0 — Baseline and repository discovery

1. Extract the V16 archive into a clean working directory.
2. Record the archive checksum and file inventory.
3. Run the existing V16 test suite and compile check in a dependency-complete environment.
4. Capture current CLI/dashboard behavior and output schemas.
5. Inspect dependency versions and API usage.
6. Create `docs/architecture/v17-baseline.md` with confirmed behavior, limitations, and compatibility decisions.
7. Do not edit production code during this phase.

**Gate:** V16 baseline and reproducible test command are documented. Any environment blocker is recorded rather than represented as a pass.

## 18. Phase 1 — Domain contracts and data dictionary

Tests first:
- Add `tests/unit/test_domain_models.py`.
- Add `tests/unit/test_metric_availability.py`.
- Add `tests/unit/test_provenance.py`.

Implementation:
- Create `v17_niche_intel/domain/enums.py` for modes, formats, provider status, availability, and confidence.
- Create `v17_niche_intel/domain/models.py` for typed research inputs, observations, assessments, and report objects.
- Create `v17_niche_intel/domain/validation.py` for input constraints and invariants.
- Create `docs/architecture/metric-dictionary.md` defining every metric's unit, source, formula, direction, caveats, and availability rules.
- Create `docs/adr/0001-domain-contracts.md`.

**Gate:** Invalid values, missing values, and provenance requirements are enforced at domain boundaries.

## 19. Phase 2 — Persistence and reproducibility

Tests first:
- `tests/unit/test_repositories.py`
- `tests/integration/test_sqlite_roundtrip.py`
- `tests/integration/test_idempotent_snapshots.py`

Implementation:
- Create `v17_niche_intel/storage/database.py` with schema creation and transaction boundaries.
- Create `v17_niche_intel/storage/repositories.py` for runs, observations, snapshots, assessments, and score configurations.
- Add migration scripts under `v17_niche_intel/storage/migrations/`.
- Persist `schema_version`, `algorithm_version`, and `score_config_version`.
- Add `docs/adr/0002-local-storage-and-provenance.md`.

**Gate:** Re-running an identical import/snapshot does not create unintended duplicates; stored results can be reconstructed.

## 20. Phase 3 — Provider adapters and sampling protocol

Tests first:
- `tests/contract/test_youtube_provider_contract.py`
- `tests/contract/test_trends_provider_contract.py`
- `tests/contract/test_reddit_provider_contract.py`
- `tests/unit/test_provider_failure_policy.py`

Implementation:
- Create a common provider contract in `providers/base.py`.
- Move YouTube Data API logic into `providers/youtube_data_api.py`.
- Implement multiple query strategies with explicit sample metadata.
- Move Google Trends logic into `providers/google_trends.py`; persist full returned time series and query settings.
- Move Reddit logic into `providers/reddit.py`; mark it as global/community evidence unless country localization is verified.
- Add bounded timeout/retry/rate-limit handling and structured provider status.
- Add deterministic fixture payloads under `tests/fixtures/providers/`.

**Gate:** Provider output is typed, traceable, and testable without live credentials. Live API checks are a separate release check and must not be claimed unless run.

## 21. Phase 4 — Format, demand, and competition engines

Tests first:
- `tests/unit/test_format_classifier.py`
- `tests/unit/test_trend_features.py`
- `tests/unit/test_competition_profile.py`
- `tests/unit/test_cross_country_comparability.py`

Implementation:
- Add `domain/format_classifier.py`; distinguish candidates from confirmed formats.
- Add `domain/demand.py`; calculate relative trend features and query coverage.
- Add `domain/competition.py`; calculate sample saturation, channel concentration, competitor strength distributions, recent-content traction, and content-gap evidence.
- Add `services/snapshot.py`; calculate interval growth only from repeated timestamped observations.
- Add explicit comparability states for country-level trend data.

**Gate:** No format overclaim, no false absolute search volume, and no use of lifetime views/day as real-time velocity.

## 22. Phase 5 — Business feasibility, risk, scoring, and confidence

Tests first:
- `tests/unit/test_business_feasibility.py`
- `tests/unit/test_missing_data_scoring.py`
- `tests/unit/test_confidence_independence.py`
- `tests/unit/test_score_sensitivity.py`
- `tests/unit/test_explainability.py`

Implementation:
- Add `domain/business.py` for user constraints, production feasibility, monetization-route plausibility, and risk flags.
- Add `domain/scoring.py` with versioned provisional balanced weights and required-dimension gates.
- Add `domain/confidence.py` using source reliability, freshness, sample quality, independence, missingness, and consistency.
- Add `domain/explainability.py` to produce component-level reasons and evidence references.
- Add sensitivity analysis over configurable weights and sample perturbations.
- Store every score configuration and algorithm version with each assessment.

**Gate:** Missing data never becomes an unmarked neutral score; confidence is not a metric count; aggregate scores are explicitly heuristic until calibrated.

## 23. Phase 6 — Existing Channel and Analytics ingestion

Tests first:
- `tests/unit/test_analytics_csv_validation.py`
- `tests/contract/test_youtube_analytics_contract.py`
- `tests/integration/test_existing_channel_mode.py`
- `tests/security/test_oauth_secret_redaction.py`

Implementation:
- Add `importers/analytics_csv.py` with documented schemas, type checks, duplicate detection, date-range checks, and error reports.
- Add `providers/youtube_analytics.py` using owner-authorized read-only OAuth.
- Store imported/authorized Analytics data separately from public observations.
- Implement Existing Channel Mode and Both Mode in `services/research.py` and `services/comparison.py`.
- Add user-visible connect/disconnect and CSV-import states to the dashboard.
- Do not request write scopes or perform channel mutations.

**Gate:** Existing Channel Mode works with fixtures/CSV even when OAuth is not configured; secrets are never emitted.

## 24. Phase 7 — Application services, CLI, and exports

Tests first:
- `tests/integration/test_research_service.py`
- `tests/integration/test_cli_commands.py`
- `tests/integration/test_report_exports.py`

Implementation:
- Add `services/research.py`, `services/analysis.py`, `services/comparison.py`, and `services/reporting.py`.
- Add `cli.py` commands: `research`, `snapshot`, `import-analytics`, `compare`, `report`, and `doctor`.
- Include stable exit codes and machine-readable JSON output.
- Add versioned CSV, JSON, and Markdown report schemas.
- Keep a V16 compatibility entry point with a deprecation warning; do not reinterpret V16 scores as V17 scores.

**Gate:** CLI uses only application services; output includes provenance, coverage, confidence, score version, and limitations.

## 25. Phase 8 — Dashboard

Tests first:
- `tests/ui/test_dashboard_states.py`
- `tests/integration/test_dashboard_service_parity.py`

Implementation:
- Create `v17_niche_intel/dashboard.py` as the Streamlit entry point.
- Create `ui/dashboard_views.py` and `ui/components.py`.
- Implement research setup, mode selection, format comparison, country comparison, evidence inspector, history, snapshot timeline, and exports.
- Add loading, empty, partial, provider-error, insufficient-evidence, and authorization states.
- Ensure all actions call the same service functions as the CLI.

**Gate:** Same run ID/input yields the same analysis in CLI and dashboard; UI clearly displays missing data and provider failures.

## 26. Phase 9 — Evaluation, security, and release hardening

Tests and checks:
- Full unit, contract, integration, and UI suite.
- `ruff check .`
- `mypy v17_niche_intel` if type checking is adopted.
- `python -m compileall v17_niche_intel`
- Dependency vulnerability audit.
- CLI smoke tests.
- Dashboard startup smoke test.
- OAuth redaction and CSV adversarial-input tests.
- Evaluation benchmark on a versioned, stratified niche dataset.
- Human review of false-positive and false-negative opportunity rankings.

Implementation:
- Add `tests/evaluation/` with frozen input datasets and expected feature outputs.
- Add sensitivity and robustness reports.
- Add `docs/release-checklist.md`, `docs/data-limitations.md`, and setup documentation.
- Pin dependencies and define optional extras for dashboard, providers, and development.
- Add CI workflow only after repository hosting and runner constraints are known.

**Gate:** Release claims list exactly which checks ran, which were skipped, and why. Backtesting is required before predictive claims.

## 27. Phase 10 — Migration and release

1. Preserve V16 CSV/JSON as historical artifacts.
2. Add an optional V16 import utility that tags imported results `legacy_v16` and never mixes their scores with V17.
3. Run a parallel comparison on representative niches.
4. Review ranking changes and explain the causes.
5. Freeze V17 schema and scoring version for the release candidate.
6. Package source, tests, documentation, and dependency lock.
7. Run installation and smoke tests in a clean environment.
8. Publish only after all release gates pass.

## 28. Suggested implementation order

| Order | Deliverable | Dependency |
|---:|---|---|
| 1 | Baseline and metric dictionary | Existing V16 archive |
| 2 | Domain contracts | Baseline |
| 3 | SQLite/provenance | Domain contracts |
| 4 | Provider adapters | Domain contracts |
| 5 | Format/demand/competition engines | Providers + storage |
| 6 | Business/scoring/confidence | Domain + engines |
| 7 | Analytics ingestion and modes | Storage + provider contracts |
| 8 | Application services and CLI | All core engines |
| 9 | Dashboard | Application services |
| 10 | Evaluation, hardening, migration, release | Full system |

## 29. Risks and mitigations

| Risk | Mitigation |
|---|---|
| YouTube API quota limits | Query budgets, caching, pagination bounds, quota reporting |
| Google Trends instability | Adapter isolation, retries, cached observations, visible provider status |
| Cross-country index miscomparison | Anchor calibration or explicit non-comparable state |
| Shorts misclassification | Candidate labels and evidence-based confidence |
| Public metrics mistaken for private analytics | Separate data domains and report sections |
| Score instability | Sensitivity tests, versioned weights, rank stability reporting |
| OAuth/token exposure | Read-only scope, secret redaction, opt-in, local storage controls |
| Partial provider failure | Typed partial results and graceful degradation |
| LLM-generated unsupported claims | Deterministic calculations and evidence-linked explanations |
| V16/V17 semantic mismatch | Versioned schemas and explicit legacy import tagging |

## 30. Definition of done

V17 is ready for a release candidate only when:

- Market Entry, Existing Channel, and Both modes work.
- Shorts, long-form, and live are analyzed separately with honest classification labels.
- CLI and dashboard share the same application services.
- Data lineage and algorithm versions are present in reports.
- Missing data is explicit and never silently neutral-filled.
- Demand, competition, momentum, business feasibility, risk, coverage, and confidence are separately inspectable.
- Cross-country comparisons are only made when metrics are comparable.
- Public and private datasets remain separated.
- CSV import validation and optional read-only OAuth work.
- Partial provider failure is handled and visible.
- Unit, contract, integration, UI, and security tests pass in a clean environment.
- Evaluation results and known limitations are documented.
- No predictive or revenue guarantee is claimed without empirical validation.

---

## Immediate next step

Start Phase 0 only: extract the V16 archive into a clean working directory, run the baseline tests in a dependency-complete environment, and record the actual baseline. Do not begin implementation until that baseline is reproducible.
