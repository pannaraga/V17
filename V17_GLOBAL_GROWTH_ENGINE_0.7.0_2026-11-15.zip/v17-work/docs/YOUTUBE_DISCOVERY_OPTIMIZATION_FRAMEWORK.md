# YouTube Search and Recommendations Optimization Framework

## Purpose and boundary

This framework turns channel performance into testable editorial and packaging decisions. It is not a reverse-engineered ranking formula and cannot guarantee impressions, recommendations, search positions, views, subscribers, RPM, or revenue. YouTube personalizes discovery by viewer and surface; optimize viewer-value signals rather than attempting to manipulate a universal score.

## Two discovery systems, two jobs

| Surface | Viewer intent | Primary optimization job | Diagnostic evidence |
|---|---|---|---|
| YouTube Search | Viewer expresses a query or task | Match the actual query intent, answer it clearly, and deliver the promised result | Search impressions/views, query coverage, title/description relevance, watch time and satisfaction after search clicks |
| Home / Browse | Viewer may not have a specific query | Earn a relevant impression with a clear, differentiated promise | Browse impressions, CTR by surface, early retention, average view duration, returning viewers and satisfaction feedback |
| Suggested videos | Viewer is in a viewing session | Be a useful next video for the current viewing context | Suggested impressions/views, end-screen/card continuation where available, session continuation proxies, retention and repeat viewing |
| Shorts feed | Viewer is swiping a feed | Deliver immediate relevance and sustained viewing without misleading setup | Viewed vs swiped away, engaged views, average view duration, average percentage viewed, likes/dislikes and returning viewers where available |

Do not compare CTR across different surfaces, formats, audiences, or impression volumes as if they were interchangeable. Use matched cohorts and the same observation window.

## Search optimization workflow

1. **Resolve the job-to-be-done.** Classify each topic/query as informational, navigational, commercial investigation, transactional, or mixed. Write the audience problem in the viewer's own local phrasing.
2. **Localize intent, not just words.** Preserve the seed query, collect machine-translated candidates only as discovery hints, and prefer current native-reviewed query variants with provenance. Validate spelling, scripts, regional vocabulary, slang, code-switching, cultural context, and search result fit.
3. **Inspect the actual result set.** Sample results by country, language, query, and time. Record format, publish date, channel, views, and source. Treat results as a biased sample, not a census or search-volume estimate.
4. **Build a content-to-intent map.** One primary intent per video; document secondary intents and overlap. Avoid publishing near-duplicate videos that compete for the same audience job without a clear differentiated promise.
5. **Package honestly.** Title and thumbnail should communicate one specific outcome, tension, proof point, or question. The opening must quickly deliver on that promise. Do not keyword-stuff, misrepresent the content, or optimize only for clicks.
6. **Refresh deliberately.** Update content when the query intent, facts, product availability, or competitive result set materially changes. Track the before/after cohort; do not assume that changing a title caused an observed change without an appropriate experiment.

## Recommendations optimization workflow

1. **Define the audience context.** Topic, format, viewing occasion, prior viewer interests, and the channel's existing audience all affect who is likely to value the video.
2. **Make the promise legible.** Use a specific thumbnail focal point and title that work together rather than repeat the same words. Test a small number of meaningfully different concepts.
3. **Deliver the promise immediately.** Remove long generic intros. Establish the question, stakes, and payoff early, then sustain progression through demonstration, evidence, story, or useful novelty.
4. **Design coherent viewing paths.** Build related series and follow-up videos that solve the next logical audience problem. Use playlists, end screens, cards, and pinned comments only when they genuinely help viewers continue.
5. **Measure satisfaction, not just clicks.** Review retention curves, average view duration, average percentage viewed, returning viewers, likes/dislikes, qualitative feedback, and repeat viewing where available. A high CTR with weak retention is a packaging/promise mismatch warning, not a success.
6. **Segment before changing strategy.** Compare Home/Browse, Suggested, Search, and Shorts separately. Segment by format, video age, topic cluster, new/returning viewers, and geography when sample sizes permit.

## Diagnostic decision table

| Observed pattern | Likely hypotheses to test | Next action |
|---|---|---|
| Low impressions, strong satisfaction among reached viewers | Narrow topic demand, weak audience mapping, competition, or insufficient channel history | Validate query/topic demand and audience fit; build a coherent series; do not change packaging blindly |
| High impressions, low CTR on a comparable surface | Promise is unclear, thumbnail/title mismatch, or audience targeting is broad | Test a materially different promise/visual concept; keep the video content constant where possible |
| High CTR, sharp early retention drop | Opening does not pay off the packaging promise, slow setup, or audience mismatch | Rewrite the opening and narrative sequence in the next comparable video; inspect the first 30 seconds and retention curve |
| Good early retention, later decline | Pacing, repetition, weak transitions, or payoff arrives too late | Tighten the middle, add proof/progression, and move the payoff earlier |
| Search performs, Browse does not | Strong explicit intent but weak broad-audience packaging or topic framing | Preserve the search-serving asset; test a broader but still accurate framing on a new comparable video |
| Browse performs, Search does not | Discovery relies on topic interest/context rather than explicit query match | Build a query-to-video map and create a dedicated answer asset only if search intent is real |
| Suggested traffic is weak | Few coherent adjacent topics, unclear next-video relationship, or limited audience overlap | Develop a connected topic cluster and a useful sequel; measure Suggested separately |
| Views rise but returning viewers/subscriber conversion do not | One-off curiosity, weak channel promise, or no repeatable content system | Strengthen series identity and next-viewer journey; assess subscriber gain per 1,000 views by cohort |

These patterns are diagnostic hypotheses, not deterministic explanations. Validate with channel-specific evidence before changing multiple variables.

## KPI dictionary

| KPI | Definition | Interpretation guardrail |
|---|---|---|
| Impressions CTR | Impressions clicks / eligible impressions × 100% | Compare by surface, format, cohort, and age; not all views create eligible impressions |
| Average view duration | Total watch time / views, using YouTube's reported definition | Duration is not comparable across different video lengths without context |
| Average percentage viewed | Average view duration / video duration × 100% | Useful with duration and retention curve; do not optimize it in isolation |
| Subscriber conversion | Subscribers gained / views × 1,000 | Compare matched format/topic cohorts; include unsubscribes separately if available |
| Returning viewer rate | Returning viewers / unique viewers × 100% | Use YouTube's reported definitions and consistent date windows |
| Search contribution | Search views / total views × 100% | Mix metric, not a quality score; changes when other sources change |
| Suggested contribution | Suggested views / total views × 100% | Mix metric; interpret with Suggested impressions and viewer satisfaction |
| Experiment lift | (Treatment metric − control metric) / control metric × 100% | Descriptive only unless assignment and exposure support causal inference |
| WAPE | Σ|actual − forecast| / Σactual | Requires paired actual/forecast values and non-zero aggregate actuals |

For any percentage, store numerator, denominator, date range, traffic source, video format, and data origin. If denominators are zero or missing, return null/insufficient data, never zero by assumption.

## Experiment protocol

- Hypothesis: one audience, one promise/creative change, one expected mechanism.
- Primary metric: choose one metric aligned with the surface and decision.
- Guardrails: retention, dislikes/negative feedback, subscriber quality, production cost, rights/policy risk.
- Unit: video or eligible viewer, depending on the actual test design and YouTube's supported experiment capability.
- Sample and power: specify baseline, minimum detectable effect, confidence/power target, and required exposure before reading results. If the platform does not expose random assignment or enough sample, label the result observational.
- Duration: include full weekday/weekend cycles and avoid major seasonality or launch effects where practical.
- Analysis: report absolute and relative lift, sample sizes, confidence intervals when valid, missingness, and segmentation. Check sample-ratio mismatch if assignment data exists.
- Decision: stop, iterate, or scale against predeclared criteria. Avoid repeated peeking and multiple uncorrected comparisons.

## Data contract for V17

For each video/surface/cohort observation, store:

- `channel_id`, `video_id`, `observed_at`, `date_range`, `country`, `language`, `format`;
- `traffic_source`, `impressions`, `impressions_click_through_rate`, `views`, `watch_time_minutes`;
- `average_view_duration_seconds`, `average_view_percentage`, `subscribers_gained`, `unique_viewers`, `returning_viewers` when available;
- `source_ref`, `source_family`, `authorization_scope`, `metric_definition_version`, and `data_quality_status`.

Private channel metrics must come only from owner-authorized YouTube Analytics or a user-provided export with validated provenance. Competitor public data must never be used to infer private CTR, retention, impressions, audience demographics, or RPM.

## Release gate

A recommendation is actionable only when it includes: target surface, audience/job, observed baseline, source and sample window, metric definition, confidence/limitations, one prioritized change, experiment or monitoring plan, guardrails, and a rollback/stop rule. Without those inputs, return a hypothesis and the missing evidence, not a confident prescription.

## Executable V17 growth diagnostics

The framework now has a corresponding CLI audit for source-backed competitor gap observations, Search intent overlap, native localization review gates, first-party retention curves, surface-specific packaging/retention diagnostics, CTR experiment sample-size and inference checks, market revenue scenarios, portfolio concentration, and pre-publication readiness. Run `v17 growth-audit examples/growth_audit.template.json --output growth-audit-report.json`. The calculations and evidence boundaries are documented in [`GROWTH_INTELLIGENCE_UPGRADE.md`](GROWTH_INTELLIGENCE_UPGRADE.md). These are diagnostics and workflow gates, not a universal algorithm formula or a promise of reach.
