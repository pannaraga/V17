# V16 baseline audit — 2026-11-11

## Reproduction
- Source: `/mnt/data/V16_GOD_MODE_full_project.zip`, extracted to `/tmp/v17_work/v16_god_mode`.
- Runtime: Python 3.13.5.
- `python -m pytest -q`: **9 passed**.
- `python -m compileall -q .`: **passed**.
- Available: requests 2.32.5, pandas 2.2.3, pytest 9.0.2.
- Missing in audit environment: google-api-python-client, pytrends, deep-translator, streamlit. Live provider integration was not tested.

## Findings
1. Missing source metrics are replaced with 50 in `analyze_country`, creating neutral-looking scores for absent evidence.
2. Empty YouTube results can produce competition proxy 0 while YouTube status remains `ok`; the inverse-competition score then rewards a no-result sample.
3. `competition_proxy = len(videos) / limit` measures sample fill, not market competition.
4. Confidence counts metric fields, not independent source families. Trends demand and momentum are from the same series.
5. Trends momentum is only a recent-four vs prior-four comparison and does not model seasonality, persistence, volatility, or spike decay.
6. YouTube retrieval uses a single relevance query; no deliberate multi-query sampling or source-family coverage is recorded.
7. `views_per_day` is lifetime views divided by video age, not interval growth.
8. Public video detail requests omit `liveStreamingDetails`; no content-format classifier exists.
9. Existing-channel YouTube Analytics OAuth and CSV import are not implemented.
10. Reddit search is not localized by country; translation is fallback-based and not reviewed/validated.
11. CLI and dashboard share `run_research`, but there is no persistence/history/provenance layer or service boundary.
12. Provider integration, quota behavior, OAuth, and dashboard runtime are unverified because required dependencies and credentials are absent.

## Scope decision
V16 remains unchanged as a historical baseline. V17 starts a separate package and algorithm version; old V16 scores must not be mixed with V17 scores.
