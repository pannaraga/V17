# Global Market Discovery and Four-Layer Decision Model

## Scope and market coverage

When a metered YouTube Data API provider is available, the dashboard first calls `i18nRegions.list` and builds a market registry from the regions YouTube currently supports. `regionCode` is therefore based on YouTube's live supported-region list, not a hard-coded guess. The registry enriches each region with CLDR language/currency metadata and a representative timezone, then preserves curated multilingual segments. It includes major/official language segments; it does **not** claim to model every dialect, accent, subculture, or language community in every country.

If the live region lookup or the optional `global` metadata extra is unavailable, the app falls back to the curated registry (currently 50 profiles across 37 countries). The output identifies the registry source and actual country/profile counts. YouTube's supported region list is the authority for the region codes accepted by the API. [YouTube i18nRegions](https://developers.google.com/youtube/v3/docs/i18nRegions) [i18nRegions.list](https://developers.google.com/youtube/v3/docs/i18nRegions/list)

For each market-language profile, V17 records country, language, locale, currency, representative timezone, and a localization note. Country-level timezones may span multiple zones; the stored timezone is a representative value, not a country-wide scheduling rule.

## Single seed to localized discovery

One seed topic is expanded for each configured country-language profile:

1. Preserve the original seed.
2. Translate it to the profile's language/translation target when `deep-translator` is installed.
3. Allow an operator to provide up to 12 market-specific query variants in the evidence JSON. A fresh, provenance-backed `native_reviewed` variant takes priority; otherwise a supplied operator variant is selected but remains explicitly unverified. Machine translation is used only when no curated variants are supplied.
4. Use a configurable, quota-bounded query variant sample per market. The live CLI/dashboard default is two variants (1-12 configurable); each query variant consumes its own search.list calls and videos.list detail reserve. Retain every candidate and record exactly which variants were sampled. A partial quota scan is never ranked.
5. Pass YouTube `regionCode` and `relevanceLanguage` separately. Language relevance is a ranking hint, not an exclusive language filter; YouTube may still return highly relevant videos in other languages.
6. Record the selected query source, native-review status, reviewer reference, review timestamp, and evidence reference. **Native review is always required** before using a phrase in published titles, scripts, thumbnails, or audience-facing copy.

The YouTube search endpoint documents `regionCode` as the country content region and `relevanceLanguage` as the language relevance hint. Simplified and traditional Chinese use `zh-Hans` and `zh-Hant`. [YouTube Search: list](https://developers.google.com/youtube/v3/docs/search/list)

Machine translation does not validate dialect, accent, idiom, politeness, humor, cultural references, taboo terms, code-switching, or local buying behavior. V17 does not claim to generate native-level copy automatically. A market cannot pass the creator-fit layer without source-linked evidence marked `native_reviewed`.

## Four decision layers

The composite model has four equally weighted decision layers. The weights are transparent policy defaults, not empirically calibrated universal truths.

| Layer | Weight | Components and weights |
|---|---:|---|
| Audience demand | 25% | Search interest 30%; demand growth 20%; seasonality stability 15%; audience pain evidence 20%; consumption behavior 15% |
| Competitive opening | 25% | Competitor concentration opportunity 25%; median-views opportunity 20%; observed views-velocity opportunity 25%; validated content gaps 30% |
| Monetization economics | 25% | First-party RPM 20%; advertiser demand 25%; revenue-route diversity 15%; purchase intent 20%; audience purchasing power 20% |
| Creator execution fit | 25% | Language/cultural fluency 25%; format capability 25%; production feasibility 25%; policy/rights resilience 25% |

RPM and CPM are inputs, never the whole decision. Competitor RPM is not public. `first_party_rpm`, when available, must come from owner-authorized YouTube Analytics and is entered as a normalized 0–100 component score with a documented method; raw currency RPM is not treated as a universal cross-country score. For a pre-monetization channel, the monetization layer can still score at 80% coverage from independently sourced advertiser-demand, revenue-route-diversity, purchase-intent, and audience-purchasing-power evidence; it does not fabricate an RPM.

### Score formulas and gates

For layer `l`, component score `s_i` and component weight `w_i`:

\[
Coverage_l = \sum_{i\ observed} w_i
\]

\[
Score_l = \frac{\sum_{i\ observed} w_i s_i}{Coverage_l}
\]

A layer score is emitted only when weighted component coverage is at least 75%. The creator-execution layer additionally requires both `language_cultural_fluency` and `policy_rights_resilience`; language fluency evidence must be explicitly `native_reviewed`.

For the overall decision, each layer has weight `W_l = 0.25`:

\[
Coverage_{overall} = \sum_{l\ scored} W_l
\]

\[
DecisionScore = \frac{\sum_{l\ scored} W_l Score_l}{Coverage_{overall}}
\]

A provisional decision score can be shown at 75% overall layer coverage, but **ranking requires all four layers (100% coverage)**. A missing layer is not silently treated as zero or neutral. A quota-limited partial scan is not ranked, preventing first-markets-first bias.

Evidence older than the configured freshness window (default 180 days) is marked stale and excluded. Every accepted component requires:

- `score`: finite normalized score from 0 to 100;
- `source_ref`: stable source/report/record reference;
- `source_family`: source family for independence assessment;
- `observed_at`: timezone-aware ISO-8601 timestamp;
- `confidence`: 0 to 1;
- `method`: how raw observations were normalized to the score.

Confidence is the mean of source-family-level confidence values and is only a ranking tie-breaker. It cannot compensate for missing layer coverage.

### Hard gates

- `market_eligibility.status` may be `eligible`, `rejected`, `hold`, or `not_evaluated`.
- A rankable market must have an explicit `eligible` assessment with `source_ref`, `source_family`, timezone-aware `observed_at`, and `method`; `not_evaluated` is never ranked.
- `rejected` and `hold` markets are never ranked.
- A policy/rights resilience score below 50/100 automatically puts a market on hold. This is a conservative operating threshold, not legal advice.
- A non-native-reviewed language/cultural fluency score is not accepted. Evidence marked `native_reviewed` must use `source_family: native_speaker_review`.
- `first_party_rpm` evidence from any source family other than `owner_authorized_youtube_analytics` is rejected.

## Evidence input file

The dashboard accepts an optional JSON file containing `decision_evidence`, `market_eligibility`, and `localized_query_variants`. Local query variants are keyed by `COUNTRY-LANGUAGE`; `review_status: native_reviewed` requires a stable `source_ref` and timezone-aware `reviewed_at`, with optional `reviewer_ref`. Stale reviews are downgraded to `stale` and do not qualify as native-reviewed. The exact shape is defined in [`examples/global_market_decision_evidence.schema.json`](../examples/global_market_decision_evidence.schema.json); a blank starting point is [`examples/global_market_decision_evidence.template.json`](../examples/global_market_decision_evidence.template.json). Market IDs use `COUNTRY-LANGUAGE`, for example `US-en` or `IN-ta`.

A component score must be normalized against a documented, topic-appropriate rubric. The `method` field must state the denominator, benchmark, cohort, and normalization rule where relevant. Do not enter a guessed score to fill a missing component. If the evidence is unavailable, omit the component and allow the gate to withhold the score.

Example localized query entry:

```json
{
  "localized_query_variants": {
    "ID-id": {
      "queries": ["cara seduh kopi di rumah", "resep kopi rumahan"],
      "review_status": "native_reviewed",
      "source_ref": "localization-review:ID-id:v1",
      "reviewed_at": "2026-11-13T08:00:00+07:00",
      "reviewer_ref": "reviewer:language-team"
    }
  }
}
```

`review_status` may be `native_reviewed`, `pending`, or `not_reviewed`. A native-reviewed record requires a source reference and timezone-aware timestamp; review evidence older than the configured freshness window is marked stale. Up to 12 variants are accepted per market. The scan selects the first supplied variant as the query for that market, retains the full variant list for traceability, and avoids an extra machine-translation request when curated variants exist. It does not search all variants in one run.

## KPI dictionary: formula, evidence, and limits

| KPI | Formula / method | Evidence boundary |
|---|---|---|
| Google Trends relative interest | Mean of the returned 0–100 index | Relative index only; not absolute search volume and not cross-country comparable |
| Demand growth | `(mean(second half) - mean(first half)) / max(mean(first half), 1) × 100` | Relative change within the same market/query/timeframe |
| Audience purchasing power | Category-specific purchasing-power index normalized against a declared local benchmark | Use sourced disposable-income/consumer-spend or validated purchase-proxy data; do not substitute GDP per capita as an individual buyer metric |
| Consumption behavior | Cohort shares by format, session cadence, device, or viewing occasion; normalize to a comparable 0–100 rubric | Requires first-party audience analytics or a disclosed research panel; public search results do not reveal watch-time or retention behavior |
| Trend volatility | Population standard deviation of the relative index | Describes fluctuation, not audience size |
| Seasonality amplitude | `(peak monthly mean - trough monthly mean) / overall monthly mean × 100` | Requires at least 12 observed months; recurring seasonality requires at least two years |
| Competitor concentration (HHI) | `Σ(channel share²)` using a clearly defined comparable sample | A search-result sample is biased; label as sample proxy and never call it the whole market |
| Median competitor views | Median views for a matched format/age/cohort | Lifetime views alone are not growth velocity; cohort normalization is required |
| Views velocity | `(views_t2 - views_t1) / elapsed days` for the same video | Requires repeated timestamped snapshots of the same video |
| First-party RPM | `estimated revenue / views × 1,000` | Private owner-authorized Analytics only; not available for competitors |
| Production capacity | `available creator hours / hours per video`; compare with target cadence | Requires creator-supplied capacity and production-time evidence |
| Forecast error | `WAPE = Σ|actual - forecast| / Σ|actual|`; `MAPE` averages percentage errors only where actuals are non-zero; `MAE = mean(|actual - forecast|)` | Implemented in `services/kpi_calculations.py`; requires paired historical actual/forecast observations |
| Experiment lift | `mean(treatment) - mean(baseline)`; relative lift divides by baseline mean | Implemented as descriptive lift with sample sizes; requires valid baseline/treatment samples and does not itself prove statistical significance or causality |

Additional KPIs such as CTR, average view duration, retention curves, subscriber conversion, revenue per viewer, and audience demographics require owner-authorized first-party Analytics or an appropriately consented research source. Public search samples do not establish them. Portfolio concentration can be measured with `HHI_portfolio = Σ(market allocation share²)` once an explicit allocation plan exists; V17 does not invent allocation shares. Forecast calibration (WAPE/MAPE) and causal experiment attribution require historical forecast/outcome or valid treatment/control records and are not inferred from keyword research.

## Quota controls

YouTube's current quota model (June 2026 onward) has separate buckets:

- `search.list`: 1 quota unit per call in its own Search Queries bucket, with a default limit of 100 calls/day.
- `i18nRegions.list`: 1 unit in the general daily-units bucket.
- `videos.list`: 1 unit per details request in the general daily-units bucket.
- Other read endpoints use the general daily-units bucket, whose default allocation is 10,000 units/day.
- Daily quota buckets reset at midnight Pacific Time.
- The dashboard defaults to 90 `search.list` calls and 9,000 general units, configurable up to the limits configured for the project. If Google has approved higher quota, set `YOUTUBE_SEARCH_DAILY_LIMIT` and/or `YOUTUBE_DAILY_QUOTA_LIMIT` to the approved limits.
- Preflight reserves one general-bucket unit per market for `videos.list` and one unit for the `i18nRegions.list` lookup. A full registry may exceed the default 100 search calls/day; the UI shows both bucket estimates.
- When either budget is reached, remaining markets are marked `skipped_quota_budget`, the scan is `partial_quota_limited`, and no market ranking is returned.
- Each bucket is project-wide across keys and use cases in the same Google Cloud Project. Multiple keys do not multiply quota. Legacy V17 aggregate usage is migrated conservatively; the search-call estimate may overcount because older mixed usage cannot be disaggregated exactly.

## What is automated vs. still evidence-dependent

Automated: supported-region discovery, registry construction, locale metadata, query translation when installed, precedence-aware selection of provenance-backed operator query variants, country/language YouTube sampling, Google Trends collection, provider-failure isolation, quota accounting, provenance validation, stale-evidence exclusion, weighted score calculation, confidence aggregation, hard-gate enforcement, and ranking only when complete.

Evidence-dependent: native language/cultural review, competitor RPM, advertiser demand, normalized market-specific RPM, purchase intent, validated content gaps, creator skill/capacity, and rights/policy assessment. These are never invented from a keyword.

Not claimed: exhaustive coverage of every dialect/accent, absolute search volume from Google Trends, exact competitor revenue, guaranteed RPM, predicted views/subscribers/revenue, automatic causal attribution, or production deployment acceptance.
