# V17 Eight-Priority Global Growth Engine

**Engine:** `v17-global-growth-engine-1.0.0`  
**Package baseline:** V17 Niche Intelligence 0.4.0  
**Purpose:** one auditable workflow joining global market discovery, localization, evidence ingestion, first-party Analytics, distribution diagnostics, experiments, learning proposals and bounded automation QA.

## 1. Operating contract

The engine is evidence-first. Missing values remain missing; estimates remain estimates; source timestamps and provenance are retained. It does not infer competitor-private Analytics, guarantee YouTube rankings, manufacture RPM, or modify live channel state. All live provider calls require explicit CLI flags and configured credentials. Native localization, publishing decisions, policy changes and scheduling remain human-approved.

## 2. Eight integrated capabilities

### 2.1 Global Market Discovery

- Uses the existing `GlobalMarketDiscoveryService` and YouTube `i18nRegions.list` supported-region registry.
- `build_market_registry` enriches supported regions with CLDR/ISO language, locale, currency and timezone metadata, preserving curated multilingual profiles. Coverage is constrained by YouTube-supported regions and local metadata; it is not every language spoken in each country.
- A single seed topic is passed across every profile supplied to the discovery service. Optional machine translation is a discovery aid only; native review remains required.
- YouTube search is country- and relevance-language-specific. Optional Google Trends results are market-local relative indices, never cross-country absolute search-volume comparisons.
- YouTube search, Google Trends and Firecrawl SERP calls have separate explicit budgets. A quota-limited scan is marked partial and must not produce a final ranked list, preventing early-market selection bias.
- Live mode: `v17 global-growth INPUT.json --live-market-discovery --search-call-budget 80`.

### 2.2 Native Localization

Each market requires locale, language and query variants. A market is marked `native_reviewed` only when all are true and current: native review flag, HTTPS review evidence, timezone-aware review date, dialect review, accent/pronunciation review and cultural review. Machine translation, generated text and curated-but-unverified variants remain `native_review_required`.

### 2.3 Research Data Pipeline

The normalizer enforces an explicit HTTPS hostname allowlist, timezone-aware timestamps, future-date rejection, freshness labels, stable SHA-256 fingerprints and duplicate suppression. Optional `--live-web-serp` collects bounded public web SERP samples per discovered market through the existing Firecrawl Search adapter. It requires an explicit `allowed_hosts` list in the input; returned URLs outside that list are discarded. This is a sampled public web SERP, not YouTube Search results or a census. No arbitrary website crawl is started. Scrapling browser/MCP sessions are not required or claimed. Additional source adapters still need their own rate limits, checkpoints, retries, parser tests, retention and terms/robots controls.

### 2.4 Channel Analytics Integration

The optional live Analytics path uses owner-authorized OAuth read-only scopes:
- `yt-analytics.readonly`
- `yt-analytics-monetary.readonly` for `estimatedRevenue`.

It retrieves daily views, estimated minutes watched, average view duration/percentage, subscribers gained, thumbnail impressions, thumbnail impression click rate and estimated revenue. It also queries the country dimension for views and estimated revenue, then derives the channel's observed country RPM. Daily and country rows are stored in private Analytics tables, separate from public competitor evidence. Rates are aggregated with denominators: average view percentage is view-weighted; thumbnail CTR is impression-weighted; revenue and counts are summed. Estimated revenue may be adjusted by YouTube at month-end.

KPI formulas:

| KPI | Formula / semantics |
|---|---|
| Thumbnail impressions CTR | YouTube `videoThumbnailImpressionsClickRate` percentage; weighted by thumbnail impressions when aggregating days |
| AVD | Total estimated watch-time minutes × 60 / total views |
| APV | View-weighted mean of YouTube `averageViewPercentage` |
| Watch time hours | Estimated minutes watched / 60 |
| Subscribers gained per 1,000 views | Subscribers gained / views × 1,000; channel-level, not causal video attribution |
| Revenue per 1,000 views | Estimated revenue / views × 1,000 |
| Country RPM | Country estimated revenue / country views × 1,000; this channel and reporting period only |

The Analytics API requires owner authorization. Revenue metrics require the monetary read-only scope. API values are not independently authenticated by the pure calculation layer; the CLI fetch path is the trusted collection boundary. Country RPM for the creator's own channel is not a competitor benchmark or a market-wide RPM estimate.

Example:

```bash
v17 global-growth examples/global_growth_engine.template.json \
  --channel-analytics --channel-id UC... \
  --analytics-start-date 2026-10-01 --analytics-end-date 2026-10-31
```

The OAuth account must already be connected to the channel and have both scopes. In the dashboard Connections tab, enable “Include estimated revenue and country RPM” before generating a new Google consent link to request the additional monetary read-only scope. This is opt-in and does not grant publishing or channel-management access. The CLI does not initiate consent or broaden existing grants automatically.

### 2.5 Distribution Optimization

Four separate diagnostic scores are available:

| Surface | Inputs | Weights |
|---|---|---|
| Search | intent match, topic relevance, metadata alignment, satisfaction | 35%, 30%, 15%, 20% |
| Browse | audience fit, packaging, early retention, satisfaction | 25% each |
| Suggested | topic adjacency, viewer overlap, session continuity, satisfaction | 30%, 25%, 20%, 25% |
| Shorts | swipe-stop, viewed-vs-swiped, retention, satisfaction | 25% each |

Every component must be supplied on a 0-100 scale. Missing inputs withhold the score. These are operator diagnostics, not disclosed YouTube ranking weights or predictions.

### 2.6 Experimentation

Two independent proportions use a normal-approximation sample-size estimate:

\[
n=\frac{\left[z_{1-\alpha/2}\sqrt{2\bar p(1-\bar p)}+z_{1-\beta}\sqrt{p_1(1-p_1)+p_2(1-p_2)}\right]^2}{(p_2-p_1)^2}
\]

The evaluator reports observed lift, approximate 95% confidence interval, p-value, sample-ratio mismatch (SRM) chi-square screen and underpowered status. The simple two-arm SRM threshold is chi-square 3.841 at one degree of freedom. This is not sufficient for clustered, repeated-exposure, sequential, multiple-comparison or non-randomized experiments; those require a richer design and platform-side controls.

### 2.7 Continuous Learning

Forecast error uses MAE, WAPE, MAPE (non-zero actuals) and aggregate bias. Policy proposals require a minimum observation count and weights summing to one. The engine emits a versioned proposal for out-of-sample backtesting; it never changes production weights automatically. Approval, holdout evaluation and rollback remain explicit operator decisions.

### 2.8 Automation & QA

Jobs must declare a unique ID, idempotency key, explicit hostname allowlist, kill switch and bounded attempts, timeout, items and budget. Only read-only operations can pass. Mutating actions are blocked pending human approval. V17 persists job/checkpoint state and provides a manually invoked one-job runner for host-registered handlers; it does not deploy a background scheduler or browser session.

## 3. Existing four-layer market decision model

The global discovery service retains the existing evidence-weighted four-layer model. Layer weights are equal: audience demand 25%, competitive opening 25%, monetization economics 25%, and creator execution fit 25%. Within-layer component weights are defined in `services/global_market.py`. A layer is scored only when at least 75% of its weighted component coverage is present; final market ranking requires all four layers, full coverage, current evidence and verified market eligibility. Missing evidence is never filled with zero or neutral values. The creator-fit layer includes language/cultural fluency and policy/rights resilience as required components; policy/rights resilience below 50 triggers a hold.

## 4. Market economics formulas

For market `m`:

\[
GrossRevenue_{m,s}=\frac{ReachableMonthlyViews_m}{1000}\times RPM_{m,s}
\]

\[
NetContribution_{m,base}=GrossRevenue_{m,base}-(ProductionCost+LocalizationCost+RiskReserve)
\]

The opportunity score uses normalized base RPM within one reporting currency:

\[
Score_m=.25D_m+.20M_m+.20G_m+.20F_m+.15C_m
\]

Where `D` = demand score, `M` = base RPM relative to the highest supplied base RPM, `G` = competitor gap, `F` = creator fit, and `C` = confidence, all normalized to 0-100. `ConfidenceAdjustedScore = Score × confidence`. Cross-currency inputs require a dated HTTPS FX source and explicit conversion rate no older than seven days. Scenario revenue is not actual revenue; reachable views and component scores must be evidence-backed operator inputs. When a market lacks RPM but owner-authorized country Analytics supplies an RPM in the same currency, V17 can use that observed channel RPM as the baseline; it never substitutes another currency or treats the channel's audience as the whole market.

## 5. CLI and input

Offline deterministic run:

```bash
v17 global-growth examples/global_growth_engine.template.json --output global-growth-report.json
```

Live multi-market scan (requires configured YouTube Data API credentials and `[global]` metadata dependencies):

```bash
v17 global-growth input.json --live-market-discovery --search-call-budget 80 --market-limit 25
```

Optional machine translation and Google Trends:

```bash
v17 global-growth input.json --live-market-discovery --machine-translate --google-trends --trends-call-budget 40
```

Optional owner Analytics is described above. Flags are opt-in; no live request occurs in the offline mode. See `examples/global_growth_engine.schema.json` and `examples/global_growth_engine.template.json`.

## 6. Readiness and limitations

`decision_support_ready_with_gates` means the report was generated but at least one evidence/validation gate remains. It does not mean market, localization, experiment or automation readiness. Live country coverage depends on the supported-region response, CLDR/ISO metadata and provider quota. Machine translations are not native-quality certification. Google Trends indices are relative within a market. Public competitor metrics cannot reveal private RPM, CTR, retention or audience demographics. Owner Analytics requires existing OAuth consent. No external scheduler or deployment is included.


## 6.1 Integrated P0-P8 hardening in package 0.4.1

- **P0 scoring provenance:** owner-channel country RPM is marked `used_in_opportunity_score=true` only when it fills a missing market `rpm_base` in the same currency and the market remains scoreable. Existing scenario RPM is not silently replaced.
- **P1 discovery/economics bridge:** exact `market_id` joins expose four-layer decision status/score/coverage beside the economics opportunity score. Scores are intentionally not blended; each has distinct evidence semantics.
- **P2 query expansion:** live CLI/dashboard can sample 1-12 localized query variants per market (default 2). Calls and detail reserves are counted per variant; duplicate public videos are deduplicated by video ID. Native-review status remains separate from query sampling.
- **P3 competitor diagnostics:** public sample median views, channel count, sample-view-share HHI, top-channel share and lifetime-average views/day. These are sample-scoped; views/day is not growth velocity. True velocity requires repeated timestamped snapshots.
- **P4 first-party funnel diagnostics:** owner Analytics exposes metric availability and packaging/consumption/audience-response supporting metrics. Satisfaction remains explicitly unmeasured unless a suitable first-party satisfaction signal is supplied.
- **P5 experimentation:** observed experiment output includes an explicit ship gate and guardrail checklist. SRM failure, underpowered samples, and non-significant results block shipping. The normal approximation assumes independent observations.
- **P6 learning:** proposals report calibration status and require out-of-sample/holdout backtesting. `apply_allowed` remains false; no automatic weight update exists.
- **P7 persistent orchestration:** SQLite queue/checkpoints persist idempotency key, config, state, attempt count, worker lease and JSON checkpoint. A manually invoked one-job worker runs only injected registered handlers, refreshes leases on checkpoint, resumes expired leases, and fails closed for unknown handlers. Delivery is at-least-once, so handlers must be idempotent. No background scheduler is deployed.
- **P8 dashboard:** shows public competitor sample diagnostics and persistent job checkpoint status with tabular fallback. Browser accessibility/runtime QA still requires installing the optional app dependencies and running the dashboard.

### Additional diagnostic formulas

- Sample channel concentration: `HHI_sample = 10,000 × Σ(channel_sampled_views / all_sampled_views)²`. This is concentration in the observed sample only.
- Top-channel share: `100 × max(channel_sampled_views) / all_sampled_views`.
- Lifetime-average views/day: `video_views / max(video_age_days, 1)`, averaged across valid sampled videos. It is not interval velocity.
- Experiment ship gate: block when SRM fails, sample is underpowered, or inferential result is not significant; otherwise require human guardrail review.

These additions do not expand public YouTube ranking disclosures or grant new API permissions.

Manual worker entry point (the host application must register its own reviewed handlers):

```python
from v17_niche_intel.services.job_runner import PersistentJobRunner
from v17_niche_intel.storage.repositories import JobCheckpointRepository

runner = PersistentJobRunner(
    JobCheckpointRepository(database),
    {"approved_read_only_scan": approved_read_only_scan_handler},
)
result = runner.run_once(worker_id="research-worker-01")
```

The handler receives `(config, checkpoint, save_checkpoint)`. It must validate job config, respect the stored allowlist/budgets, checkpoint progress, and be idempotent because a worker lease may expire while a process is still running. Invoke `run_once` from a supervised host process; V17 does not create a scheduler or run this automatically.
