# V17 Phase 1 — Domain contracts and evidence-aware core

## Objective
Establish the V17 domain boundary before provider integration: typed evidence, conservative content-format classification, score coverage semantics, and confidence based on independent evidence families. V16 remains untouched and is not silently migrated into V17 scoring semantics.

## Architecture context
- Python package: `v17_niche_intel/` (repository root package files will be added in Phase 1).
- Pure domain logic has no network, UI, database, or credential dependencies.
- Provider observations are represented as evidence with source family, timestamp, status, and optional value.
- Score and confidence are separate outputs. Missing data is never silently converted into a neutral score.

## Decisions
1. Six provisional score dimensions: demand (25), competition opportunity (20), momentum/stability (15), format fit (15), business feasibility (15), risk resilience (10). These are heuristic weights and must be versioned; they are not validated predictive coefficients.
2. A score is `insufficient_evidence` when weighted coverage is below 0.75. Above threshold, available dimensions are reweighted proportionally and the original coverage is reported.
3. Confidence uses independent source families, freshness, and evidence quality metadata; two metrics from one provider family count as one family.
4. Format labels are deliberately conservative: `live_now`, `upcoming_live`, `completed_live`, `shorts_candidate`, `long_form_candidate`, or `unknown`. A duration-only short video is a candidate, not a confirmed Short, because aspect ratio/orientation is not reliably public in the normal public video resource.
5. Domain functions are deterministic and independently testable. No production implementation before a failing test.

## Task sequence (RED → GREEN)

### Task 1 — package and domain contracts
- Add `v17_niche_intel/__init__.py`, `domain/__init__.py`, `domain/models.py`, and `domain/enums.py`.
- Tests first: `tests/unit/test_domain_models.py` validates evidence status/value invariants and serializable stable enums.
- RED: `python -m pytest tests/unit/test_domain_models.py -q` must fail because the package/contracts do not exist.
- GREEN: implement dataclasses/enums and validation; rerun focused test.

### Task 2 — format classifier
- Add `domain/format_classifier.py`.
- Tests first: active live, upcoming live, completed live, <=180-second candidate, >180-second candidate, unknown/malformed duration, live precedence over duration.
- RED: focused tests fail before implementation.
- GREEN: use live metadata first; parse duration conservatively; return method/evidence/confidence with each classification.

### Task 3 — score and coverage
- Add `domain/scoring.py`.
- Tests first: exact weights, bounds, missing-value coverage, below-threshold insufficient result, reweighting of observed dimensions, invalid values.
- RED then GREEN.
- Score dimensions and weights carry `algorithm_version`; expose per-dimension contribution and missing dimensions.

### Task 4 — confidence by independent source family
- Add `domain/confidence.py`.
- Tests first: same-family metrics count once; distinct source families increase confidence; stale/low-quality evidence reduces confidence; empty evidence is low.
- RED then GREEN.

### Task 5 — integrate domain documentation and quality gate
- Add `docs/architecture/domain-contracts.md` and update README with phase status.
- Run `python -m pytest -q`, `python -m compileall -q v17_niche_intel tests`, and inspect the tree.
- Do not claim provider, database, CLI, or dashboard integration in this phase.

## Acceptance criteria
- Domain modules import without third-party packages.
- All domain behavior is deterministic and unit-tested.
- Missing values remain missing and affect coverage.
- Confidence is not a count of metric columns.
- Live classification takes precedence over duration.
- Shorts classification is explicitly candidate-level unless aspect-ratio evidence exists.
- V16 baseline remains byte-for-byte untouched in its source ZIP and extraction.

## Rollback
Phase 1 is additive. If a domain contract proves unsuitable, revert only `v17_niche_intel/`, `tests/unit/`, and this plan; retain the V16 baseline and audit notes.
