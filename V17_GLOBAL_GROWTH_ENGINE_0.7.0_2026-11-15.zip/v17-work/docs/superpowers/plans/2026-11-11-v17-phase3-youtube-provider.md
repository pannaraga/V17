# V17 Phase 3 — YouTube Data API provider

## Objective
Build a quota-aware, testable public YouTube provider that samples more than one ranking surface, deduplicates video IDs, and retrieves duration/statistics/live metadata in one detail pass per batch.

## Constraints
- Default search orders: `relevance` and `date`; `viewCount` remains configurable.
- `search.list` has a separate daily quota bucket with a default 100-call/day limit; every search call consumes one call. Budget calls explicitly and do not assume unlimited search.
- `videos.list` costs one unit per call; batch at most 50 IDs per request.
- Never infer Shorts from duration alone; preserve metadata for the domain classifier.
- Missing statistics stay `None`, not zero.
- Provider has no embedded API key, no write methods, and supports injected clients for deterministic tests.

## Tasks (RED → GREEN)
1. Add tests using a fake Google API client for order sampling, deduplication, max-results bounds, video detail fields, missing stats, and partial search failures.
2. Confirm RED because provider module is absent.
3. Add typed `VideoRecord` and `VideoSearchBatch` domain records.
4. Implement lazy `YouTubeDataAPIProvider`; initialize network client only when no injected client is supplied.
5. Run focused tests, full unit suite, compileall, and inspect generated request parameters.
6. Document quota planning and public/private data boundary.

## Acceptance criteria
- Exactly configured search orders are requested; defaults are relevance + date.
- Duplicate IDs across query orders are fetched once.
- Details include snippet, statistics, contentDetails, and liveStreamingDetails.
- Missing public counts remain null.
- API errors are surfaced as `error`/`partial`, not disguised as no demand.
- No actual network call is required for unit tests.
