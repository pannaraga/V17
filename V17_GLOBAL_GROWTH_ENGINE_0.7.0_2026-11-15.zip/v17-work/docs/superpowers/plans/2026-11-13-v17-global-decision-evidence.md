# V17 global market and decision-evidence hardening

## Objective
Connect global discovery to validated four-layer evidence, discover the current YouTube-supported regions dynamically, and prevent incomplete or unsafe market ranking.

## Implemented scope

1. Add regression tests for evidence provenance, freshness, native-language review, quota limits, hard gates, dynamic registry generation, and language relevance.
2. Add a dynamic region registry using YouTube `i18nRegions.list` plus CLDR country/language/currency/timezone metadata, with explicit partial-metadata fallback.
3. Pass `relevanceLanguage` to YouTube searches and use script-specific Chinese values.
4. Validate source-linked normalized component scores, reject stale evidence, and wire component scores into the four-layer decision.
5. Require native-reviewed language fluency and policy/rights resilience for creator fit; put low-resilience markets on hold.
6. Require full four-layer coverage and no hard gate for ranking; block ranking on partial quota scans.
7. Add quota preflight, detail-call reservation, optional evidence upload, schema, KPI formulas, and operational documentation.

## Verification

- Baseline before changes: 153 tests passed.
- New focused tests were first run red against the missing behavior, then green after implementation.
- Final verification is recorded in `BUILD_MANIFEST.txt` and the updated implementation report.

## Explicit non-goals

- No automatic native-speaker validation or accent-perfect copy generation.
- No competitor RPM inference, guaranteed RPM forecast, or absolute Google Trends search-volume estimate.
- No live API acceptance test without user-owned credentials and quota.
- No Scrapling MCP execution because the Scrapling server is not connected in this host.
