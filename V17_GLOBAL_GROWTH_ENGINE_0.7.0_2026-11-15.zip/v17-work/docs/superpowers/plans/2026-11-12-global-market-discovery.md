# Global Market Discovery implementation

## Objective
Replace the single-country default research path with a single-seed global scan across configured country-language markets, while preventing unsupported monetization or market-opportunity claims.

## Architecture decisions
- Keep the existing single-market `ResearchService` intact for owner-authorized channel Analytics and targeted investigations.
- Add `GlobalMarketDiscoveryService` as a separate orchestrator. Each market request is isolated so one provider failure does not stop other markets.
- Use a registry of 37 countries and 50 language-market profiles, including major multilingual segments.
- Keep translated query text labeled as machine translated and requiring native review.
- Use four equally weighted decision layers: audience demand, competitive opening, monetization economics, creator execution fit.
- Score layer components only when at least 75% of their weighted evidence is present; score the total only when at least 75% of layer weight is covered. Do not neutral-fill missing data.
- Rank only evidence-qualified markets. RPM/CPM is one component, never the sole ranking variable.

## TDD sequence
1. Add failing tests for market registry, localized query deduplication, four-layer coverage, and evidence-qualified ranking.
2. Implement the market profile registry and deterministic scoring contracts.
3. Add isolated per-market provider orchestration and native-review localization metadata.
4. Wire global discovery as the dashboard default while preserving single-market mode for private Analytics.
5. Add explicit Google Trends locale override for regional language markets.
6. Document provider semantics, localization caveats, and quota requirements.
7. Run full tests and compile checks; inspect the resulting archive.

## Acceptance criteria
- One seed can trigger country-language-specific YouTube and Google Trends requests for all configured profiles.
- One country/provider error cannot abort other markets.
- Trend values are labeled market-local relative indices, never absolute search volume.
- Machine translation is not presented as native cultural adaptation.
- Four-layer score rejects invalid values and incomplete evidence; RPM/CPM cannot independently produce a ranking.
- Existing single-market workflows and the existing test suite remain green.

## Verification limits
Automated tests cover deterministic service behavior. Live API quota, actual country coverage, Streamlit interaction, visual contrast, and keyboard behavior require configured credentials and a Streamlit runtime; these are not proven by unit tests.
