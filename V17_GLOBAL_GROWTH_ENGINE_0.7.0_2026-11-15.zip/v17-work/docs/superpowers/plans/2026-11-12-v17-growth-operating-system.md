# V17 Growth Operating System implementation plan

## Goal
Add the first channel-building workflow that converts explicit audience/creator inputs and source-linked competitor/audience observations into a reviewable positioning and editorial foundation.

## Design decisions
- Keep the strategy engine deterministic and in the existing service layer.
- Require niche, target audience, audience problem, desired outcome and differentiated method.
- Exclude competitor-gap claims without competitor ID, source family and at least one evidence reference.
- Build content pillars only from audience signals with source family and evidence references.
- Keep opportunity scores and growth forecasts null; the current evidence does not justify predictive precision.
- Reuse the same service from CLI, dashboard and MarketIntelligenceService.
- Do not add an LLM provider, background scheduler, publisher, database migration or new dependency in this increment.

## Implementation sequence
1. Add failing unit tests for positioning, evidence-linked gaps, missing inputs, malformed values and content pillars.
2. Implement `ChannelStrategyService` with explicit output status and limitations.
3. Integrate the service into market intelligence and add `v17 strategy` CLI command.
4. Add a Channel Strategy dashboard tab and JSON export.
5. Document the growth operating model and blank JSON template.
6. Run focused tests, full suite, compile check, CLI smoke test and wheel packaging.

## Acceptance criteria
- Unsupported competitor claims are excluded and counted.
- Missing required inputs produce `insufficient_inputs` without fabricated positioning.
- Strategy output contains source references and explicit hypothesis labels.
- No opportunity score or growth forecast is fabricated.
- CLI writes a valid JSON result.
- Market intelligence exposes `channel_strategy` as either configured or `not_configured`.
- All tests and package build pass; unavailable UI/runtime checks are reported as not verified.

## Verification evidence
- TDD RED observed for missing service and missing integration behavior.
- Focused strategy tests: 8 passed.
- Full test suite: 144 passed.
- `compileall`: passed.
- CLI strategy blank-template smoke test: passed with `insufficient_inputs`.
- Wheel build: passed and contains `channel_strategy.py`.
- Streamlit runtime: not verified because Streamlit is not installed in this environment.
- Ruff: not run because Ruff is not installed.
