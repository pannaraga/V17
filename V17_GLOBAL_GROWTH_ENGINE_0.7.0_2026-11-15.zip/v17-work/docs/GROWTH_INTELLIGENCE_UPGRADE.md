# V17 Growth Intelligence Upgrade

## Purpose and boundary

This release adds an executable, evidence-first growth audit to the existing four-layer market decision model. It does not replace the original model or claim to reverse-engineer YouTube's recommendation system. It converts supplied observations into diagnostics, checks, and explicit decision holds.

Run:

```bash
v17 growth-audit examples/growth_audit.template.json --output growth-audit-report.json
```

The same input can be nested under `growth_audit` in the existing `v17 intelligence` evidence bundle. The standalone CLI is useful for a focused review; the integrated report keeps market research, channel strategy, and growth diagnostics together.

## Added capabilities

### 1. Competitor weakness intelligence

`analyze_competitor_weaknesses` groups operator-coded gap observations by gap type. Every accepted observation requires a competitor ID, gap label, and stable `source_ref`. Severity is a 0–100 rubric supplied by the analyst. Where audience-evidence counts exist, severity is weighted by those counts; otherwise the aggregate is explicitly labelled unweighted. A source-backed observation is not automatically true, representative, or a market opportunity. The analyst must distinguish observed fact, interpretation, and testable opportunity.

### 2. Search intent coverage and overlap

`analyze_search_intent_map` counts queries by intent, identifies queries without a video assignment, and flags intents assigned to multiple videos. These are overlap-review flags, not proof of cannibalization. Confirm with first-party Search traffic, actual query performance, video audience overlap, and matched observation windows before merging or retiring content.

### 3. Localization quality gates

`audit_localization_coverage` requires localized query variants, a review source reference, a timezone-aware review timestamp within the freshness window (default 180 days), and explicit dialect, accent, and cultural review flags before a market becomes `ready_for_content_qa`. A human review record is evidence that a review happened, not an automatic guarantee that the language is excellent. Translation alone never qualifies as native review. The registry does not claim exhaustive dialect or accent coverage.

### 4. Retention diagnostics

`analyze_retention_curve` validates a time-ordered curve, interpolates 30-second and 60-second retention where the input covers those times, and reports the largest observed drop segment. Compare only matched cohorts by format, duration, source, audience and video age. The function does not infer why viewers left.

### 5. Discovery-surface packaging diagnostics

`analyze_discovery_surface` accepts one of Search, Browse, Suggested, Shorts, External or Other and optional matched-cohort baselines. It flags high CTR with weak retention as a promise-delivery review, or low CTR with stronger retention as a packaging review. Thresholds (20% relative CTR change and 25% relative APV change) are configurable only by changing code; they are conservative triage heuristics, not official YouTube thresholds or ranking rules. Never compare CTR across unmatched surfaces, formats or impression volumes.

### 6. Experiment design and analysis

`estimate_ctr_sample_size` estimates per-arm impressions for a two-proportion CTR test using a normal approximation, two-sided alpha and target power. Its `baseline_ctr` and `minimum_detectable_effect` inputs are proportions (for example, 0.05 means 5% CTR and 0.01 means a one-percentage-point absolute effect), not percentage numbers. Its `baseline_ctr` and `minimum_detectable_effect` inputs are proportions (for example, 0.05 means 5% CTR and 0.01 means a one-percentage-point absolute effect), not percentage numbers. `analyze_ctr_experiment` reports CTR, absolute/relative lift, an approximate 95% Wald interval, and a two-sided pooled z-test only when the caller declares randomized assignment. Sample-size planning inputs live under `ctr_sample_size_plans`. Non-randomized data is always `observational_only`. The result is not valid if randomization was not implemented, sample-ratio mismatch exists, viewers are repeatedly exposed in a way that violates independence, the primary metric was selected after seeing results, or multiple comparisons are ignored. Small cell counts are flagged for caution. For platform-native thumbnail/title experiments, prefer the platform's own experiment design and outcome reporting.

### 7. Market economics scenarios

`evaluate_market_economics` calculates low/base/high revenue and net scenarios from expected views, RPM assumptions, production cost, localization cost, risk reserve and confidence. It reports break-even RPM and a confidence-adjusted base case. `rpm_source` must be either `scenario_assumption` or `owner_authorized_youtube_analytics`; competitor estimates are rejected because competitor RPM is not public evidence. First-party RPM also requires a stable `rpm_source_ref`. Scenario values are not forecasts. First-party RPM must be sourced from the channel owner's authorized Analytics and retain its source reference in the operator's evidence record.

### 8. Pre-publication content readiness

`evaluate_content_readiness` checks hook, promise, proof, payoff, rights, localization, thumbnail/title alignment and CTA relevance. Rights and localization are hard gates. A score is workflow completion, not a prediction of audience response or legal/platform approval.

### 9. Portfolio concentration

The audit reuses the existing `portfolio_concentration_hhi` calculation when explicit allocation weights are supplied. It does not invent portfolio allocation. HHI and effective market count describe concentration of the supplied plan, not the addressable market.

## Data contract

See [`examples/growth_audit.schema.json`](../examples/growth_audit.schema.json) and [`examples/growth_audit.template.json`](../examples/growth_audit.template.json). Sections are optional. Missing sections are returned as `not_configured`; empty collections return `insufficient_data`. Do not replace missing evidence with zero, neutral, or synthetic values.

## Operational workflow

1. Capture source-linked competitor observations and localized query variants.
2. Assign one primary intent to each planned video; inspect overlap flags manually.
3. Collect authorized channel retention and discovery-surface metrics by matched cohorts.
4. Record a dated native-speaker review for each target market, including dialect, accent and cultural checks appropriate to that audience.
5. Estimate market economics with explicitly labelled scenarios; replace scenario RPM only with owner-authorized first-party data.
6. Complete the content readiness checklist before publication.
7. Run predeclared randomized experiments where the platform supports valid testing; otherwise label analysis observational.
8. Re-run the audit after new evidence is collected and compare only compatible cohorts/time windows.

## Automation and production boundary

The new audit is deterministic and can be invoked in CI or a scheduler using the CLI. This repository does not install a scheduler, configure credentials, run a live cron job, publish videos, or create a connected Scrapling MCP session. For scheduled use, operators must configure an authorized environment and run a bounded job with logs, retries, idempotency, quota budgets, retention controls, and an alert on provider failure. Do not schedule destructive actions or publishing without a separate human approval gate.

## Remaining validation requirements

- Validate localization with qualified native reviewers and record dialect/accent/cultural scope.
- Validate market RPM assumptions with owner-authorized Analytics and representative historical periods.
- Validate retention/surface metrics from first-party Analytics exports or authorized API data.
- Validate experiment design, sample ratio, power, and independence before inferential claims.
- Run Streamlit browser, responsive, keyboard and screen-reader QA in an environment with the optional UI dependencies installed.
- Run authorized live-provider integration tests separately; unit tests do not prove API quota, OAuth, provider availability or data correctness.

## P1-P10 operating-system expansion (v0.3.0)

The optional `growth-audit` payload now supports a broader set of deterministic operating workflows. These are diagnostics and planning aids, not an autonomous publisher or a YouTube ranking formula.

| Workstream | Input key | Output | Evidence boundary |
|---|---|---|---|
| P1 Market economics | `market_economics` | low/base/high RPM scenarios, net, break-even | scenario assumptions unless owner Analytics source is declared; competitor RPM is never inferred |
| P2 Localization | `localization_markets` | freshness, native/dialect/accent/culture review gates | a record cannot perform native review; a human reviewer must supply evidence |
| P3 Competitor intelligence | `competitor_evidence_observations` | HTTPS source graph, deduplication, timestamps, stale flags | public, source-backed observations only |
| P4 Audience and retention | `audience_samples`, `retention_curves` | labelled pain-theme clusters and retention drop segments | sample counts are not population prevalence; retention is first-party/cohort data |
| P5 Search intelligence | `search_intent_rows` | unassigned queries and intent-overlap review flags | overlap is not confirmed cannibalization |
| P6 Recommendation surfaces | `discovery_surfaces` | surface-specific packaging/retention diagnostics | descriptive cohort comparison, not an algorithm ranking rule |
| P7 Content production | `editorial_backlog`, `video_briefs`, `content_readiness` | capacity-bounded priorities, evidence-linked briefs, hard gates | scores are operator inputs; rights and native localization still require human review |
| P8 Portfolio | `portfolio_resource_allocation`, `portfolio_allocations` | risk-adjusted capacity allocation and HHI | heuristic allocation; no automatic spending or market launch |
| P9 Experimentation | `ctr_sample_size_plans`, `ctr_experiments`, `experiment_integrity` | power planning, approximate CTR inference, SRM screen | causal claims require valid randomization, pre-registration, power and guardrails |
| P10 Automation and QA | `automation_jobs` | bounded read-only job contract validation | validates only; does not schedule or execute jobs |

### New input contracts

- `competitor_evidence_observations`: each accepted record needs a unique observation identifier (or a deterministic fallback key), competitor ID, gap label, HTTPS source reference and timezone-aware `observed_at`. Duplicate records are removed; stale records are retained but flagged.
- `audience_samples`: text is used only for presence validation and is not echoed in output. Supply a human-reviewed `theme`, language, source reference and optional sample window. Theme clustering is exact-label grouping, not unsupervised semantic inference.
- `editorial_backlog`: each topic needs evidence references, five explicit 0-100 operator scores and estimated production hours. The transparent weights are demand 25%, audience pain 25%, competitive gap 20%, creator fit 20%, freshness 10%. Items are allocated by score per hour under a hard capacity limit.
- `video_briefs`: require topic ID, title, audience problem, promise and evidence references. The generated narrative beats are a scaffold; factual claims must be checked against referenced evidence.
- `first_party_kpis`: require an owner-authorized Analytics source declaration and source reference. For registered-impression CTR, pass the provider's `impressions_ctr_pct` metric directly. Clicks are used only when `clicks_semantics` explicitly declares `views_from_registered_impressions`.
- `experiment_integrity`: checks declared randomization and two-arm sample-ratio mismatch. A passing screen does not prove a valid experiment.
- `portfolio_resource_allocation`: requires market opportunity, confidence, risk, effort and a total hour budget. No money is committed.
- `automation_jobs`: require idempotency, bounded retries/timeouts/items/budget, a non-empty domain allowlist and kill switch. Only `read_only` jobs can pass; mutating jobs are blocked pending human approval. No scheduler is configured by this feature.

### Example

Run `v17 growth-audit examples/growth_audit.template.json --output growth-audit-report.json`. Add only the sections for which evidence is available. Empty or missing sections remain unconfigured; they are never filled with invented values.
