# Domain contracts — V17

## Evidence
Every external observation is represented by `Evidence` with:
- `metric` and `value` (only successful observations carry a value),
- `source_family` (the independence boundary, e.g. `google_trends`),
- timezone-aware `observed_at`,
- explicit `status`,
- quality in `[0, 1]`, optional source reference, and metadata.

Provider status values are not converted into numeric zeroes. `no_data`, `unavailable`, `error`, and `stale` remain distinct.

## Format classification
Priority is completed live → live now → upcoming live → duration candidate → unknown. Live metadata takes precedence over duration. Duration at most 180 seconds yields `shorts_candidate`; it does not prove a video is a YouTube Short. The normal public video resource does not reliably expose aspect ratio for all public videos. Longer non-live videos are `long_form_candidate`.

## Opportunity score
Algorithm: `v17-balanced-0.1.0`.

| Dimension | Weight |
|---|---:|
| Demand | 25% |
| Competition opportunity | 20% |
| Momentum and stability | 15% |
| Format fit | 15% |
| Business feasibility | 15% |
| Risk resilience | 10% |

Each dimension is a 0–100 value. Coverage is the sum of weights for observed dimensions. Under 75% coverage, status is `insufficient_evidence` and score is null. At or above 75%, observed dimensions are renormalized to 100%; coverage is still exposed so a score is never shown without its evidence coverage. Weights are provisional decision heuristics, not fitted coefficients or probabilities.

## Confidence
Confidence is not derived from the number of metric columns. Valid observations are grouped by `source_family`; multiple metrics from the same family count once. Per-family quality combines provider quality and exponential freshness decay (30-day half-life by default). Thresholds are transparent in `domain/confidence.py` and will be revisited using evaluation data.

## Time and growth
All observation timestamps must be timezone-aware. `views_per_day` from one observation is a lifetime average. True interval growth requires at least two snapshots of the same video separated by a known interval.

## Separation of public and private data
Public competitor observations and the user's authorized channel Analytics must remain distinguishable by source, ownership, and authorization context. No credentials or OAuth tokens belong in the SQLite research database.
