# V17 Credential Management

## Scope
V17 supports multiple YouTube Data API keys from multiple Google Cloud projects and multiple Google OAuth identities. Every credential is explicitly assigned to a project/use case or an authorized channel. Ownership of credentials does not change provider quota or authorization rules.

## API-key routing
- Register each key with `credential_id`, `project_id`, `use_case`, `environment`, and a secret reference.
- A use case/environment route must resolve to exactly one Cloud project. Different independent projects require distinct use-case identifiers.
- Multiple keys in one project may provide operational failover for invalid/disabled keys. They share one project quota ledger.
- Quota exhaustion blocks the project route. The selector does not fall through to a different project.
- Quota units are recorded by `(project_id, use_case)`, never by individual key.

## OAuth routing
- Each Google identity is registered separately with access/refresh secret references, explicit scopes, and explicit authorized channel IDs.
- Selection is by requested channel and required scopes; there is no random account rotation.
- Expired access tokens may be refreshed using the stored refresh token. `invalid_grant` transitions the identity to `reauth_required`.
- Revoked, disabled, invalid, and reauthorization-required identities are excluded.
- OAuth identity selection does not multiply YouTube Data API quota.

## Secret handling
- SQLite stores secret references and non-secret metadata only.
- `KeyringSecretStore` stores values in the OS credential vault (`pip install -e '.[secrets]'`).
- `EnvironmentSecretStore` reads named environment variables; `MemorySecretStore` is for tests/ephemeral sessions only.
- Never print token values, API keys, OAuth client secrets, or full authorization responses. Do not commit `.env` files.

## Minimal setup

```python
from v17_niche_intel.storage.database import Database
from v17_niche_intel.credentials import CredentialManager, KeyringSecretStore

manager = CredentialManager(Database("v17_niche_intel.sqlite3"), KeyringSecretStore())
manager.add_api_key(
    "yt-prod-a", project_id="gcp-project-a", use_case="market-entry-us",
    environment="prod", secret="YOUR_API_KEY",
)
manager.add_api_key(
    "yt-prod-b", project_id="gcp-project-b", use_case="existing-channel-eu",
    environment="prod", secret="YOUR_OTHER_API_KEY",
)
```

OAuth accounts must be added only after the user completes Google's consent flow and the app has verified the granted scopes and channel ownership/authorization. Never infer channel access from the fact that an account belongs to the same person.

## Current boundary
The registry, routing, secret-store adapters, project-wide quota ledger, request-level Data API metering, Streamlit credential screen, OAuth consent-link/PKCE callback validation, token refresh, explicit remote revocation, and Analytics query adapter are implemented. The dashboard uses a loopback-only callback listener for local installations and retains a manual callback URL fallback for hosted/non-loopback deployments. Production secret-vault health checks and encrypted backup/restore remain operational work. No live Google API calls are made during tests.

## Current application integration

- The Streamlit credential screen registers API keys and OAuth accounts, lists credential metadata, allows local disable/enable, shows project-wide daily quota, and supports explicit remote Google token revocation.
- Local OAuth callback listener binds only to `127.0.0.1`, suppresses callback URL logging, uses `Cache-Control: no-store`, and returns credentials to the app in memory only. Hosted deployments use a manually pasted callback URL with an HTTPS redirect URI.
- OAuth consent uses PKCE, a single-use state with a 10-minute expiry, exact redirect URI validation, approved read-only scopes, and explicit channel binding. The dashboard currently asks the operator to paste the callback URL; a hosted callback listener is not bundled.
- OAuth client ID is retained as non-secret metadata; client secret and access/refresh tokens remain in the OS keyring.
- The YouTube Analytics adapter supports daily channel reports (`dimensions=day`) and filtered per-video daily reports. A single video uses `dimensions=day` with a `video==ID` filter; multiple videos may use `dimensions=day,video` with an explicit comma-separated video filter, as documented by Google. Private data is stored in dedicated private tables, not public competitor observations.
- Data API quota is metered before each request in two project/day buckets. `search.list` costs 1 unit in its separate Search Queries bucket (default 100 calls/day); `videos.list`, `i18nRegions.list`, and other read endpoints consume the general daily-units bucket (default 10,000 units/day). Both buckets reset at midnight Pacific Time and are shared across all use cases and API keys in that project. A quota exhaustion exception is surfaced rather than swallowed as a generic provider error. Legacy V17 aggregate quota rows are migrated conservatively: old general usage is retained and an estimated search-call count is seeded from prior 100-unit search charges, which can temporarily overcount but will not silently grant extra quota.
- Legacy per-use-case quota rows are migrated into a project-wide daily counter by summing prior usage and retaining the strictest recorded limit.

## OAuth and Analytics references

- [YouTube Analytics API channel reports](https://developers.google.com/youtube/analytics/channel_reports)
- [YouTube Analytics API metrics](https://developers.google.com/youtube/analytics/metrics)
- [Google OAuth 2.0](https://developers.google.com/identity/protocols/oauth2)

The Analytics query defaults to `dimensions=day`. Per-video daily data requires explicitly supplied video IDs and a video filter; do not assume `dimensions=day,video` is valid without that filter. Only request metrics supported by the selected report and granted scopes.


## Encrypted backup and restore

- `v17 backup --output <file>` creates a password-encrypted archive of the SQLite database and referenced secret values. The archive uses scrypt-derived AES-256-GCM encryption, a random salt/nonce, authenticated header, and restrictive file permissions.
- `v17 restore <file> --target-database <new-path>` refuses to overwrite an existing database, verifies the authentication tag and SQLite integrity, writes secret material to the destination OS keyring, and remaps secret references.
- Use a unique high-entropy passphrase and keep it separate from the backup file. Environment-backed secrets are read into the encrypted archive; restored secrets are written into the destination keyring.
- `v17 doctor --json` probes local keyring write/read/delete capability without displaying the probe value.
- Backups are sensitive. Store them in encrypted storage and do not send them through chat or commit them to source control.
