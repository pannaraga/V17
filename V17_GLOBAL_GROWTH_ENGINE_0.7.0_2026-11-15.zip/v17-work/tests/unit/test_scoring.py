from v17_niche_intel.domain.scoring import SCORE_WEIGHTS, score_opportunity


def test_weights_sum_to_one_and_are_versioned():
    assert round(sum(SCORE_WEIGHTS.values()), 8) == 1.0


def test_complete_score_is_bounded_and_explains_components():
    result = score_opportunity({
        "demand": 80,
        "competition_opportunity": 70,
        "momentum_stability": 60,
        "format_fit": 90,
        "business_feasibility": 50,
        "risk_resilience": 80,
    })
    assert result.status == "scored"
    assert 0 <= result.score <= 100
    assert result.coverage == 1.0
    assert set(result.contributions) == set(SCORE_WEIGHTS)


def test_missing_values_are_not_neutral_filled():
    result = score_opportunity({
        "demand": 80,
        "competition_opportunity": None,
        "momentum_stability": 60,
        "format_fit": None,
        "business_feasibility": 50,
        "risk_resilience": 80,
    })
    assert result.status == "insufficient_evidence"
    assert result.score is None
    assert result.coverage == 0.65
    assert "competition_opportunity" in result.missing_dimensions


def test_observed_dimensions_are_reweighted_only_above_coverage_threshold():
    result = score_opportunity({
        "demand": 80,
        "competition_opportunity": 70,
        "momentum_stability": 60,
        "format_fit": 90,
        "business_feasibility": 50,
        "risk_resilience": None,
    })
    assert result.status == "scored"
    assert result.coverage == 0.9
    assert result.score is not None


def test_out_of_range_values_are_rejected():
    try:
        score_opportunity({"demand": 101})
    except ValueError as exc:
        assert "0" in str(exc) and "100" in str(exc)
    else:
        raise AssertionError("Expected invalid score dimension to be rejected")
