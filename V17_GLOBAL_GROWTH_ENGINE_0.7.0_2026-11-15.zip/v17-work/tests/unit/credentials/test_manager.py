from __future__ import annotations

import pytest

from v17_niche_intel.credentials import (
    CredentialManager,
    MemorySecretStore,
    QuotaExhaustedError,
    CredentialUnavailableError,
)
from v17_niche_intel.storage.database import Database


def make_manager():
    db = Database(":memory:")
    secrets = MemorySecretStore()
    return db, secrets, CredentialManager(db, secrets)


def test_api_keys_from_distinct_projects_are_registered_and_selected_by_use_case():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a")
    manager.add_api_key("key-b", project_id="project-b", use_case="research-b", environment="prod", secret="secret-b")

    selected = manager.select_api_key(use_case="research-b", environment="prod")
    assert selected.credential_id == "key-b"
    assert secrets.get(selected.secret_ref) == "secret-b"
    db.close()


def test_api_key_rotation_never_switches_project_after_quota_exhaustion():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a1", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a1")
    manager.add_api_key("key-a2", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a2")
    manager.add_api_key("key-b", project_id="project-b", use_case="research-b", environment="prod", secret="secret-b")

    manager.record_project_quota("project-a", used=100, limit=100, use_case="research-a")
    with pytest.raises(QuotaExhaustedError):
        manager.select_api_key(use_case="research-a", environment="prod")
    db.close()


def test_invalid_key_can_rotate_within_same_project():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a1", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a1")
    manager.add_api_key("key-a2", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a2")
    manager.set_api_key_status("key-a1", "invalid")

    selected = manager.select_api_key(use_case="research-a", environment="prod")
    assert selected.credential_id == "key-a2"
    db.close()


def test_oauth_selection_is_bound_to_authorized_channel_and_scopes():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-1", account_label="owner-one", secret_access_token="access-one",
        secret_refresh_token="refresh-one", scopes={"youtube.readonly"}, channel_ids={"UC_ONE"},
    )
    manager.add_oauth_account(
        "google-2", account_label="owner-two", secret_access_token="access-two",
        secret_refresh_token="refresh-two", scopes={"youtube.readonly"}, channel_ids={"UC_TWO"},
    )

    selected = manager.select_oauth_account("UC_TWO", required_scopes={"youtube.readonly"})
    assert selected.account_id == "google-2"
    assert secrets.get(selected.access_token_ref) == "access-two"
    with pytest.raises(CredentialUnavailableError):
        manager.select_oauth_account("UC_TWO", required_scopes={"youtube.upload"})
    db.close()


def test_oauth_revocation_blocks_account_selection():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-1", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", scopes={"youtube.readonly"}, channel_ids={"UC_ONE"},
    )
    manager.set_oauth_status("google-1", "revoked")
    with pytest.raises(CredentialUnavailableError):
        manager.select_oauth_account("UC_ONE", required_scopes={"youtube.readonly"})
    db.close()


def test_secret_values_are_not_persisted_in_sqlite_metadata():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="project-a", use_case="research-a", environment="prod", secret="TOP_SECRET")
    rows = db.connection.execute("SELECT * FROM api_credentials").fetchall()
    assert "TOP_SECRET" not in repr([dict(row) for row in rows])
    db.close()


def test_same_use_case_cannot_be_routed_across_multiple_projects():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="project-a", use_case="shared", environment="prod", secret="a")
    manager.add_api_key("key-b", project_id="project-b", use_case="shared", environment="prod", secret="b")
    with pytest.raises(CredentialUnavailableError, match="Ambiguous project route"):
        manager.select_api_key(use_case="shared", environment="prod")
    db.close()


def test_expired_oauth_access_token_can_be_selected_for_refresh():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-expired", account_label="owner", secret_access_token="old-access",
        secret_refresh_token="refresh", scopes={"youtube.readonly"}, channel_ids={"UC_ONE"},
        expires_at="2000-01-01T00:00:00+00:00",
    )
    selected = manager.select_oauth_account("UC_ONE", required_scopes={"youtube.readonly"})
    assert selected.account_id == "google-expired"
    db.close()


def test_project_quota_units_are_shared_across_all_keys_in_project():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-1", project_id="project-a", use_case="research", environment="prod", secret="one")
    manager.add_api_key("key-2", project_id="project-a", use_case="research", environment="prod", secret="two")
    assert manager.consume_project_quota("project-a", units=90, limit=100, use_case="research") == 90
    with pytest.raises(QuotaExhaustedError):
        manager.consume_project_quota("project-a", units=11, limit=100, use_case="research")
    db.close()


def test_oauth_client_id_is_persisted_as_non_secret_metadata():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-client", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", client_secret_ref=secrets.put("client-secret"),
        client_id="client-id.apps.googleusercontent.com", scopes={"youtube.readonly"}, channel_ids={"UC_ONE"},
    )
    row = db.connection.execute("SELECT client_id FROM oauth_accounts WHERE account_id='google-client'").fetchone()
    assert row["client_id"] == "client-id.apps.googleusercontent.com"
    db.close()


def test_project_quota_is_shared_across_distinct_use_cases_in_same_project():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="shared-project", use_case="market-entry", environment="prod", secret="a")
    manager.add_api_key("key-b", project_id="shared-project", use_case="channel-audit", environment="prod", secret="b")
    assert manager.consume_project_quota("shared-project", units=80, limit=100, use_case="market-entry") == 80
    with pytest.raises(QuotaExhaustedError):
        manager.consume_project_quota("shared-project", units=21, limit=100, use_case="channel-audit")
    db.close()


def test_revoked_oauth_account_cannot_be_manually_reactivated():
    db, secrets, manager = make_manager()
    manager.add_oauth_account("revoked", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", scopes={"youtube.readonly"}, channel_ids={"UC_ONE"})
    manager.set_oauth_status("revoked", "revoked")
    with pytest.raises(ValueError, match="terminal"):
        manager.set_oauth_status("revoked", "active")
    db.close()


def test_reauth_required_oauth_account_cannot_be_manually_reactivated():
    db, secrets, manager = make_manager()
    manager.add_oauth_account("reauth", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", scopes={"youtube.readonly"}, channel_ids={"UC_ONE"})
    manager.set_oauth_status("reauth", "reauth_required")
    with pytest.raises(ValueError, match="new consent flow"):
        manager.set_oauth_status("reauth", "active")
    db.close()


def test_search_list_has_its_own_100_calls_daily_bucket_separate_from_general_units():
    db, secrets, manager = make_manager()
    assert manager.consume_project_quota("project-a", units=100, limit=100,
        use_case="research", bucket="search.list") == 100
    with pytest.raises(QuotaExhaustedError, match="search.list"):
        manager.consume_project_quota("project-a", units=1, limit=100,
            use_case="channel-audit", bucket="search.list")
    # The general 10,000-unit bucket remains independent.
    assert manager.consume_project_quota("project-a", units=9999, limit=10000,
        use_case="research", bucket="default") == 9999
    db.close()


def test_quota_inventory_reports_both_daily_buckets():
    db, secrets, manager = make_manager()
    manager.consume_project_quota("project-a", units=3, limit=10000, use_case="research")
    manager.consume_project_quota("project-a", units=2, limit=100, use_case="research", bucket="search.list")
    rows = manager.quota_inventory()
    assert {row["bucket"] for row in rows} == {"general", "search.list"}
    db.close()


def test_configured_project_quota_limit_can_reflect_an_approved_increase():
    db, secrets, manager = make_manager()
    manager.consume_project_quota("project-a", units=100, limit=100, use_case="research")
    assert manager.consume_project_quota("project-a", units=50, limit=200, use_case="research") == 150
    db.close()


def test_quota_day_uses_midnight_pacific_reset_boundary():
    from datetime import datetime
    from zoneinfo import ZoneInfo
    expected = datetime.now(ZoneInfo("America/Los_Angeles")).date().isoformat()
    assert CredentialManager._quota_date() == expected


def test_monetary_analytics_scope_is_required_for_revenue_reports():
    db, secrets, manager = make_manager()
    manager.add_oauth_account("readonly", account_label="owner", secret_access_token="a",
        secret_refresh_token="r", scopes={"https://www.googleapis.com/auth/yt-analytics.readonly"}, channel_ids={"UC_ONE"})
    manager.add_oauth_account("monetary", account_label="owner-revenue", secret_access_token="b",
        secret_refresh_token="s", scopes={"https://www.googleapis.com/auth/yt-analytics.readonly",
            "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"}, channel_ids={"UC_TWO"})
    required = {"https://www.googleapis.com/auth/yt-analytics.readonly",
                "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"}
    with pytest.raises(CredentialUnavailableError):
        manager.select_oauth_account("UC_ONE", required_scopes=required)
    assert manager.select_oauth_account("UC_TWO", required_scopes=required).account_id == "monetary"
    db.close()
