import json
import socket
from v17_niche_intel.providers.firecrawl_search import FirecrawlSearchProvider


def test_firecrawl_search_uses_public_ephemeral_search_request(monkeypatch):
    import urllib.request
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self): return json.dumps({"data": {"web": [
            {"url": "https://example.com/coffee", "title": "Coffee", "description": "Public page"}
        ]}}).encode()
    captured = {}
    def fake_urlopen(request, timeout):
        captured["payload"] = json.loads(request.data.decode())
        captured["headers"] = dict(request.header_items())
        return Response()
    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    result = FirecrawlSearchProvider("test-key").search("coffee roasting", country="ID", location="Surabaya", limit=5)
    assert result["status"] == "ok"
    assert result["results"][0]["url"] == "https://example.com/coffee"
    payload = captured["payload"]
    assert payload["country"] == "ID"
    assert payload["location"] == "Surabaya"
    assert payload["scrapeOptions"]["storeInCache"] is False
    assert payload["scrapeOptions"]["proxy"] == "basic"
    assert "profile" not in payload and "cookies" not in payload
    assert "Authorization" in captured["headers"]
