import pytest

from v17_niche_intel.services.channel_strategy import ChannelStrategyService


def valid_brief():
    return {
        "niche": "home coffee brewing",
        "target_audience": "beginner home baristas in Indonesia",
        "audience_problem": "they cannot reproduce cafe-quality coffee at home",
        "desired_outcome": "brew consistently good coffee with affordable tools",
        "unique_method": "repeatable recipes tested with locally available equipment",
        "creator_advantages": ["hands-on testing", "Indonesian language"],
        "audience_signals": [
            {"problem": "grinder settings are confusing", "source_family": "youtube_comments",
             "evidence_refs": ["comments:video-1", "comments:video-2"], "frequency": "high"},
            {"problem": "equipment is too expensive", "source_family": "search_queries",
             "evidence_refs": ["serp:query-1"], "frequency": "medium"},
        ],
        "competitor_gaps": [
            {"competitor_id": "channel-a", "gap": "does not test budget grinders",
             "audience_impact": "high", "source_family": "competitor_video_review",
             "evidence_refs": ["video:abc123", "video:def456"]},
            {"competitor_id": "channel-b", "gap": "does not localize recipes for Indonesian beans",
             "audience_impact": "medium", "source_family": "competitor_video_review",
             "evidence_refs": ["video:ghi789"]},
        ],
    }


def test_builds_positioning_and_evidence_linked_opportunity_map():
    result = ChannelStrategyService().build(valid_brief())

    assert result["status"] == "ready_for_validation"
    assert "beginner home baristas in Indonesia" in result["positioning"]["statement"]
    assert len(result["opportunity_map"]) == 2
    assert result["opportunity_map"][0]["priority"] == "high"
    assert result["opportunity_map"][0]["evidence_refs"] == ["video:abc123", "video:def456"]
    assert result["evidence_quality"]["distinct_source_families"] == 3
    assert result["scores"] == {"opportunity_score": None, "growth_forecast": None}


def test_missing_foundation_inputs_do_not_generate_fake_positioning():
    result = ChannelStrategyService().build({"niche": "coffee"})

    assert result["status"] == "insufficient_inputs"
    assert result["positioning"] is None
    assert "target_audience" in result["missing_inputs"]


def test_unreferenced_competitor_claim_is_excluded_and_reported():
    brief = valid_brief()
    brief["competitor_gaps"].append({
        "competitor_id": "channel-c", "gap": "weak storytelling", "audience_impact": "high",
        "source_family": "competitor_video_review", "evidence_refs": [],
    })
    result = ChannelStrategyService().build(brief)

    assert len(result["opportunity_map"]) == 2
    assert result["excluded_claims"] == 1


def test_invalid_impact_and_empty_evidence_references_are_handled_safely():
    brief = valid_brief()
    brief["competitor_gaps"][0]["audience_impact"] = "massive"
    with pytest.raises(ValueError, match="audience_impact"):
        ChannelStrategyService().build(brief)


def test_audience_signals_create_content_pillars_without_inventing_metrics():
    result = ChannelStrategyService().build(valid_brief())

    assert [pillar["audience_problem"] for pillar in result["content_pillars"]] == [
        "grinder settings are confusing", "equipment is too expensive"
    ]
    assert all(pillar["evidence_refs"] for pillar in result["content_pillars"])
    assert all("views" not in pillar for pillar in result["content_pillars"])


def test_market_intelligence_exposes_channel_strategy_when_brief_is_supplied():
    from v17_niche_intel.services.market_intelligence import MarketIntelligenceService

    payload = {"channel_strategy": valid_brief()}
    result = MarketIntelligenceService().analyze(payload)

    assert result["channel_strategy"]["status"] == "ready_for_validation"
    assert result["channel_strategy"]["scores"]["growth_forecast"] is None


def test_market_intelligence_marks_channel_strategy_not_configured_when_absent():
    from v17_niche_intel.services.market_intelligence import MarketIntelligenceService

    result = MarketIntelligenceService().analyze({})

    assert result["channel_strategy"]["status"] == "not_configured"


def test_malformed_observation_collections_are_rejected():
    brief = valid_brief()
    brief["competitor_gaps"] = None
    with pytest.raises(ValueError, match="competitor_gaps"):
        ChannelStrategyService().build(brief)
