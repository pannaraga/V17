from pathlib import Path

import pytest
from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_TEMPLATE_PAIRS = (
    ("global_growth_engine.schema.json", "global_growth_engine.template.json"),
    ("global_market_decision_evidence.schema.json", "global_market_decision_evidence.template.json"),
    ("growth_audit.schema.json", "growth_audit.template.json"),
)


@pytest.mark.parametrize(("schema_name", "template_name"), SCHEMA_TEMPLATE_PAIRS)
def test_example_template_validates_against_its_json_schema(schema_name, template_name):
    import json

    schema = json.loads((ROOT / "examples" / schema_name).read_text(encoding="utf-8"))
    template = json.loads((ROOT / "examples" / template_name).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(template)
