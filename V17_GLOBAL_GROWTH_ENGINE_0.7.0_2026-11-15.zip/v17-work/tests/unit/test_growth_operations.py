from datetime import datetime, timezone

import pytest

from v17_niche_intel.services.growth_operations import (
    analyze_audience_voice,
    assess_experiment_integrity,
    build_competitor_evidence_graph,
    build_editorial_backlog,
    build_video_brief,
    calculate_first_party_kpi_tree,
    evaluate_portfolio_allocation,
    validate_automation_job,
)


def test_competitor_graph_rejects_unreferenced_and_deduplicates_stale_evidence():
    now = datetime(2026, 11, 13, tzinfo=timezone.utc)
    result = build_competitor_evidence_graph([
        {"observation_id": "1", "competitor_id": "c1", "gap": "beginner setup",
         "source_ref": "https://example.com/a", "observed_at": "2026-11-12T00:00:00Z"},
        {"observation_id": "1", "competitor_id": "c1", "gap": "beginner setup",
         "source_ref": "https://example.com/a", "observed_at": "2026-11-12T00:00:00Z"},
        {"competitor_id": "c2", "gap": "missing proof", "observed_at": "2026-11-12T00:00:00Z"},
        {"observation_id": "2", "competitor_id": "c2", "gap": "missing proof",
         "source_ref": "https://example.com/b", "observed_at": "2025-01-01T00:00:00Z"},
    ], now=now, freshness_days=90)
    assert result["accepted_count"] == 2
    assert result["duplicate_count"] == 1
    assert result["conflicting_id_count"] == 0
    assert result["rejected_count"] == 1
    assert result["stale_count"] == 1


def test_audience_voice_groups_explicit_themes_without_claiming_population_prevalence():
    result = analyze_audience_voice([
        {"text": "I cannot understand the setup", "theme": "beginner setup", "language": "en", "source_ref": "comment:1"},
        {"text": "The setup steps are confusing", "theme": "beginner setup", "language": "en", "source_ref": "comment:2"},
        {"text": "Harga terlalu mahal", "theme": "pricing", "language": "id", "source_ref": "comment:3"},
    ])
    assert result["cluster_count"] == 2
    assert result["sample_count"] == 3
    assert "not_population_prevalence" in result["interpretation_limit"]


def test_editorial_backlog_prioritizes_evidence_and_respects_capacity():
    result = build_editorial_backlog([
        {"topic_id": "a", "title": "Setup guide", "evidence_refs": ["comment:1", "serp:1"],
         "demand_signal": 90, "audience_pain": 90, "competitive_gap": 80,
         "creator_fit": 90, "freshness": 80, "effort_hours": 5},
        {"topic_id": "b", "title": "Advanced tips", "evidence_refs": ["serp:2"],
         "demand_signal": 70, "audience_pain": 60, "competitive_gap": 60,
         "creator_fit": 70, "freshness": 70, "effort_hours": 8},
    ], capacity_hours=6)
    assert result["allocated_hours"] <= 6
    assert result["items"][0]["topic_id"] == "a"
    assert result["items"][0]["allocation_status"] == "within_capacity"
    assert result["items"][1]["allocation_status"] == "capacity_deferred"


def test_video_brief_requires_evidence_and_keeps_claims_grounded():
    with pytest.raises(ValueError, match="evidence_refs"):
        build_video_brief({"topic_id": "x", "title": "How to grow"})
    result = build_video_brief({"topic_id": "x", "title": "Beginner setup", "audience_problem": "Confusing setup",
                                "promise": "A clear setup walkthrough", "evidence_refs": ["comment:1"]})
    assert result["evidence_refs"] == ["comment:1"]
    assert result["claim_policy"] == "claims_must_be_supported_by_brief_evidence"


def test_first_party_kpi_tree_has_explicit_denominators_and_null_for_missing():
    result = calculate_first_party_kpi_tree({"source": "owner_authorized_youtube_analytics",
        "source_ref": "analytics:channel:1", "impressions": 1000, "views": 200,
        "impressions_ctr_pct": 5.0, "watch_time_seconds": 12000, "video_duration_seconds": 120,
        "subscribers_gained": 10, "estimated_revenue": 4.0})
    assert result["metrics"]["impressions_ctr_pct"]["value"] == 5.0
    assert result["metrics"]["average_view_duration_seconds"]["value"] == 60.0
    assert result["metrics"]["average_percentage_viewed_pct"]["value"] == 50.0
    assert result["metrics"]["revenue_per_1000_views"]["value"] == 20.0
    missing = calculate_first_party_kpi_tree({"source": "owner_authorized_youtube_analytics",
        "source_ref": "analytics:1", "impressions": 0, "views": 0})
    assert missing["metrics"]["impressions_ctr_pct"]["value"] is None


def test_experiment_integrity_flags_sample_ratio_mismatch_and_unrandomized_data():
    result = assess_experiment_integrity({"randomized": True, "control_impressions": 900,
        "treatment_impressions": 100, "allocation_control": 0.5,
        "predeclared_primary_metric": True, "sample_ratio_mismatch_alpha": 0.001})
    assert result["sample_ratio_mismatch"] is True
    assert result["decision_status"] == "invalid_srm_review_required"
    observational = assess_experiment_integrity({"randomized": False, "control_impressions": 50,
        "treatment_impressions": 50})
    assert observational["decision_status"] == "observational_only"


def test_portfolio_allocation_is_capacity_bounded_and_exposes_concentration():
    result = evaluate_portfolio_allocation([
        {"market_id": "us", "opportunity_score": 90, "confidence": 0.9, "risk": 10, "effort_hours": 10},
        {"market_id": "id", "opportunity_score": 70, "confidence": 0.8, "risk": 20, "effort_hours": 10},
    ], capacity_hours=10)
    assert result["allocated_hours"] <= 10
    assert result["allocation"][0]["market_id"] == "us"
    assert 0 <= result["allocation_hhi"] <= 10000


def test_automation_job_requires_bounded_read_only_contract_and_kill_switch():
    result = validate_automation_job({"job_id": "daily-serp", "operation": "read_only",
        "idempotency_key": "serp:kw:2026-11-13", "max_attempts": 3,
        "timeout_seconds": 30, "max_items": 50, "budget_units": 100,
        "kill_switch_enabled": True, "target_domains": ["youtube.com"]})
    assert result["status"] == "ready_for_operator_scheduling"
    blocked = validate_automation_job({"job_id": "publish", "operation": "publish",
        "idempotency_key": "publish:1", "max_attempts": 3, "timeout_seconds": 30,
        "max_items": 1, "budget_units": 1, "kill_switch_enabled": True})
    assert blocked["status"] == "blocked_human_approval_required"


def test_automation_rejects_url_instead_of_hostname_allowlist():
    result = validate_automation_job({"job_id": "bad", "operation": "read_only", "idempotency_key": "x",
        "max_attempts": 2, "timeout_seconds": 20, "max_items": 10, "budget_units": 5,
        "kill_switch_enabled": True, "target_domains": ["https://youtube.com"]})
    assert result["status"] == "blocked_policy_validation"
    assert "target_domains_must_be_hostnames_not_urls" in result["violations"]


def test_first_party_kpi_source_declaration_is_not_misrepresented_as_authenticated():
    result = calculate_first_party_kpi_tree({"source": "owner_authorized_youtube_analytics", "source_ref": "claimed:1"})
    assert result["source_verification"] == "declared_not_independently_authenticated"


def test_competitor_graph_flags_conflicting_reuse_of_observation_id():
    now = datetime(2026, 11, 13, tzinfo=timezone.utc)
    result = build_competitor_evidence_graph([
        {"observation_id": "same", "competitor_id": "c1", "gap": "gap A",
         "source_ref": "https://example.com/a", "observed_at": "2026-11-12T00:00:00Z"},
        {"observation_id": "same", "competitor_id": "c2", "gap": "gap B",
         "source_ref": "https://example.com/b", "observed_at": "2026-11-12T00:00:00Z"},
    ], now=now)
    assert result["accepted_count"] == 1
    assert result["conflicting_id_count"] == 1


def test_persistent_job_runner_processes_bounded_batch_and_reports_no_scheduler():
    from v17_niche_intel.services.job_runner import PersistentJobRunner
    from v17_niche_intel.storage.database import Database
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    for index in range(3):
        repo.create(job_id=f"job-{index}", idempotency_key=f"job-{index}:v1",
            job_type="safe", config={"max_attempts": 2})
    runner = PersistentJobRunner(repo, {"safe": lambda config, checkpoint, save: {"status": "completed"}})
    result = runner.run_batch(worker_id="batch-worker", max_jobs=2)
    assert result["processed_count"] == 2
    assert result["status"] == "batch_processed"
    assert result["recurring_schedule"] == "not_configured_host_scheduler_required"
    db.close()
