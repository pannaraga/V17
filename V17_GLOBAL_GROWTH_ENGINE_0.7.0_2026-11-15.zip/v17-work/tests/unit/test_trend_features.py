from v17_niche_intel.domain.demand import extract_trend_features


def test_trend_features_are_relative_and_explicitly_not_search_volume():
    result=extract_trend_features([20,25,30,40,50,60])
    assert result['direction']=='rising'
    assert result['relative_change_pct'] > 0
    assert result['absolute_search_volume'] is None
    assert result['metric_semantics']=='relative_index'


def test_flat_and_insufficient_series_are_handled():
    assert extract_trend_features([10,10,10])['direction']=='stable'
    assert extract_trend_features([20])['status']=='insufficient_data'


def test_google_trends_provider_uses_requested_language_locale():
    from v17_niche_intel.providers.google_trends import GoogleTrendsProvider
    class FakeTrends:
        def build_payload(self, *args, **kwargs): self.kwargs = kwargs
        def interest_over_time(self):
            import pandas as pd
            return pd.DataFrame({"kopi": [10, 20]}, index=pd.to_datetime(["2025-01-01", "2025-01-08"]))
    fake = FakeTrends()
    provider = GoogleTrendsProvider(client=fake, language_code="id")
    result = provider.interest_over_time("kopi", geo="ID")
    assert result["geo"] == "ID"
    assert provider.language_code == "id"
    assert provider.locale == "id-ID"
