import pytest
from v17_niche_intel.providers.incognito_scraper import IncognitoScraper, ScrapePolicyError

class FakeScraper:
    def __init__(self): self.kwargs=None
    def scrape(self, url, **kwargs):
        self.kwargs=kwargs
        return {'url':url,'markdown':'public page','metadata':{'statusCode':200}}


def test_scraper_uses_ephemeral_privacy_policy():
    client=FakeScraper(); result=IncognitoScraper(client).scrape('https://example.com/public')
    assert result.markdown == 'public page'
    assert client.kwargs['profile'] is None
    assert client.kwargs['zero_data_retention'] is True
    assert client.kwargs['cookies'] is None

@pytest.mark.parametrize('url',['file:///etc/passwd','http://127.0.0.1/admin','https://user:pass@example.com'])
def test_scraper_rejects_nonpublic_or_credentialed_targets(url):
    with pytest.raises(ScrapePolicyError): IncognitoScraper(FakeScraper()).scrape(url)

def test_scraper_rejects_private_ip_literal():
    with pytest.raises(ScrapePolicyError): IncognitoScraper(FakeScraper()).scrape('https://192.168.1.10/private')


def test_firecrawl_http_client_requests_ephemeral_non_stealth_scrape(monkeypatch):
    import io, json, socket
    from v17_niche_intel.providers.incognito_scraper import FirecrawlHTTPClient
    class Response:
        status = 200
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self): return json.dumps({"success": True, "data": {"markdown": "public", "metadata": {"statusCode": 200}}}).encode()
    captured = {}
    def fake_urlopen(request, timeout):
        captured["payload"] = json.loads(request.data.decode())
        captured["headers"] = dict(request.header_items())
        return Response()
    monkeypatch.setattr(socket, "getaddrinfo", lambda *args: [(None,None,None,None,("93.184.216.34",443))])
    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    result = FirecrawlHTTPClient("not-a-real-key").scrape("https://example.com/public")
    assert result["markdown"] == "public"
    payload = captured["payload"]
    assert payload["zeroDataRetention"] is True
    assert payload["storeInCache"] is False
    assert payload["lockdown"] is False
    assert payload["checkPromptInjection"] is True
    assert payload["threatProtection"]["riskScoreThreshold"] == 75
    assert payload["proxy"] == "basic"
    assert "cookies" not in payload and "headers" not in payload and "profile" not in payload


def test_scraper_rejects_nonstandard_https_ports():
    with pytest.raises(ScrapePolicyError, match="standard HTTPS port"):
        IncognitoScraper(FakeScraper()).scrape("https://example.com:8443/public")


def test_firecrawl_client_fails_closed_when_dns_returns_no_addresses(monkeypatch):
    import socket
    from v17_niche_intel.providers.incognito_scraper import FirecrawlHTTPClient
    monkeypatch.setattr(socket, "getaddrinfo", lambda *args: [])
    with pytest.raises(ScrapePolicyError, match="no addresses"):
        FirecrawlHTTPClient("not-a-real-key").scrape("https://example.com/public")
