import sys, types
import pytest
from v17_niche_intel.credentials.oauth_flow import GoogleOAuthConsentFlow, ANALYTICS_READONLY_SCOPE, ANALYTICS_MONETARY_READONLY_SCOPE

class FakeCredentials:
    scopes=[ANALYTICS_READONLY_SCOPE]
    token='access'; refresh_token='refresh'

class FakeFlow:
    credentials=FakeCredentials()
    def __init__(self,state): self.state=state
    def authorization_url(self,**kwargs): return 'https://accounts.google.com/o/oauth2/auth?state='+self.state, self.state
    def fetch_token(self,authorization_response): self.response=authorization_response

class FakeFlowClass:
    @staticmethod
    def from_client_config(config,scopes,state,redirect_uri,code_verifier):
        assert code_verifier
        return FakeFlow(state)


def test_oauth_state_is_single_use_and_callback_state_must_match(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow({'installed':{'client_id':'x'}})
    auth=flow.begin()
    with pytest.raises(ValueError,match='state mismatch'):
        flow.complete(state=auth.state,authorization_response='http://127.0.0.1:8765/oauth2/callback?state=wrong&code=x')
    # A mismatched state is consumed and cannot be replayed.
    with pytest.raises(ValueError,match='already used'):
        flow.complete(state=auth.state,authorization_response='http://127.0.0.1:8765/oauth2/callback?state='+auth.state+'&code=x')


def test_oauth_requires_callback_state(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package); monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow({'installed':{'client_id':'x'}}); auth=flow.begin()
    with pytest.raises(ValueError): flow.complete(state=auth.state,authorization_response='http://127.0.0.1/callback?code=x')


def test_oauth_callback_must_match_registered_redirect_uri(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow({'installed':{'client_id':'x'}}); auth=flow.begin()
    callback=f'https://attacker.example/callback?state={auth.state}&code=x'
    with pytest.raises(ValueError, match='redirect URI'):
        flow.complete(state=auth.state,authorization_response=callback)


def test_oauth_provider_error_is_rejected(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow({'installed':{'client_id':'x'}}); auth=flow.begin()
    callback=f'http://127.0.0.1:8765/oauth2/callback?state={auth.state}&error=access_denied'
    with pytest.raises(PermissionError, match='denied'):
        flow.complete(state=auth.state,authorization_response=callback)


def test_oauth_consent_rejects_non_readonly_or_unapproved_scopes():
    flow=GoogleOAuthConsentFlow({'installed':{'client_id':'x'}})
    with pytest.raises(ValueError, match='read-only'):
        flow.begin(scopes=('https://www.googleapis.com/auth/youtube.upload',))


def test_oauth_state_expires_after_ten_minutes(monkeypatch):
    import v17_niche_intel.credentials.oauth_flow as oauth_module
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow({'installed':{'client_id':'x'}}); auth=flow.begin()
    pending=flow._pending[auth.state]
    flow._pending[auth.state]=(pending[0],pending[1],pending[2],0)
    with pytest.raises(ValueError, match='expired'):
        flow.complete(state=auth.state, authorization_response=f'http://127.0.0.1:8765/oauth2/callback?state={auth.state}&code=x')


def test_oauth_allows_monetary_analytics_scope_as_read_only(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow = GoogleOAuthConsentFlow({"installed": {"client_id": "x"}})
    auth = flow.begin(scopes=(ANALYTICS_READONLY_SCOPE, ANALYTICS_MONETARY_READONLY_SCOPE))
    assert auth.authorization_url.startswith("https://accounts.google.com/")
