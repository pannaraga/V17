import asyncio
import threading
import time

import pytest

from v17_niche_intel.services.async_provider import BoundedAsyncExecutor


def test_executor_never_exceeds_configured_concurrency():
    async def scenario():
        executor = BoundedAsyncExecutor(max_concurrency=2)
        lock = threading.Lock()
        active = 0
        peak = 0

        def blocking_call(value):
            nonlocal active, peak
            with lock:
                active += 1
                peak = max(peak, active)
            time.sleep(0.03)
            with lock:
                active -= 1
            return value

        results = await asyncio.gather(*(executor.run(blocking_call, i) for i in range(8)))
        assert results == list(range(8))
        assert peak == 2

    asyncio.run(scenario())


def test_cancelled_caller_keeps_slot_until_thread_finishes():
    async def scenario():
        executor = BoundedAsyncExecutor(max_concurrency=1)
        first_started = threading.Event()
        second_started = threading.Event()
        release_first = threading.Event()

        def first_call():
            first_started.set()
            release_first.wait(timeout=2)
            return "first"

        def second_call():
            second_started.set()
            return "second"

        first = asyncio.create_task(executor.run(first_call))
        assert await asyncio.to_thread(first_started.wait, 1)
        first.cancel()
        second = asyncio.create_task(executor.run(second_call))
        await asyncio.sleep(0.05)
        assert not second_started.is_set()
        release_first.set()
        with pytest.raises(asyncio.CancelledError):
            await first
        assert await second == "second"
        assert second_started.is_set()

    asyncio.run(scenario())
