from urllib.request import urlopen

import pytest

from v17_niche_intel.credentials.oauth_callback import OAuthCallbackListener


class FakeFlow:
    redirect_uri = "http://127.0.0.1:0/oauth2/callback"
    def complete(self, *, state, authorization_response):
        assert state == "state-1"
        assert authorization_response.startswith(self.redirect_uri.split("/oauth2/callback")[0])
        assert "code=auth-code" in authorization_response
        return {"access_token": "in-memory-only"}


def test_loopback_oauth_callback_listener_completes_state_and_does_not_log_code():
    flow = FakeFlow()
    listener = OAuthCallbackListener(flow, port=0)
    redirect = listener.start()
    try:
        with urlopen(redirect + "?state=state-1&code=auth-code", timeout=3) as response:
            body = response.read().decode()
            assert response.status == 200
            assert "authorization completed" in body
        result = listener.poll()
        assert result["status"] == "ok"
        assert result["credentials"]["access_token"] == "in-memory-only"
        assert listener.poll() is None
    finally:
        listener.stop()


def test_loopback_callback_listener_refuses_non_loopback_hosts():
    with pytest.raises(ValueError, match="loopback"):
        OAuthCallbackListener(FakeFlow(), host="0.0.0.0")
