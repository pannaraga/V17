"""Evidence-first growth diagnostics for YouTube channel portfolios.

The functions in this module are deliberately conservative: they expose gaps,
observed patterns and scenario economics without inferring hidden competitor
RPM, algorithm preferences, native language quality, or causal lift.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from math import ceil, erfc, isfinite, sqrt
from statistics import mean
from typing import Any, Mapping, Sequence


def _finite_number(value: Any, label: str, *, minimum: float | None = None,
                   maximum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)):
        raise ValueError(f"{label} must be a finite number")
    number = float(value)
    if minimum is not None and number < minimum:
        raise ValueError(f"{label} must be at least {minimum}")
    if maximum is not None and number > maximum:
        raise ValueError(f"{label} must be at most {maximum}")
    return number


def analyze_retention_curve(points: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Summarize a first-party retention curve; percentages are audience remaining."""
    if isinstance(points, (str, bytes)) or len(points) < 2:
        raise ValueError("retention curve requires at least two time points")
    normalized: list[tuple[float, float]] = []
    for point in points:
        if not isinstance(point, Mapping):
            raise ValueError("each retention point must be an object")
        time_s = _finite_number(point.get("time_seconds"), "time_seconds", minimum=0)
        retention = _finite_number(point.get("retention_pct"), "retention_pct", minimum=0, maximum=100)
        if normalized and time_s <= normalized[-1][0]:
            raise ValueError("retention time points must be strictly increasing")
        normalized.append((time_s, retention))
    if normalized[0][0] != 0:
        raise ValueError("retention curve must start at time_seconds=0")
    drops = []
    for (start_t, start_r), (end_t, end_r) in zip(normalized, normalized[1:]):
        drops.append({"from_seconds": start_t, "to_seconds": end_t,
                      "drop_pct_points": round(max(0.0, start_r - end_r), 4),
                      "retention_change_pct_points": round(end_r - start_r, 4)})
    largest = max(drops, key=lambda item: item["drop_pct_points"])

    def at_time(target: float) -> float | None:
        if target < normalized[0][0] or target > normalized[-1][0]:
            return None
        for (t0, r0), (t1, r1) in zip(normalized, normalized[1:]):
            if t0 <= target <= t1:
                ratio = (target - t0) / (t1 - t0)
                return round(r0 + ratio * (r1 - r0), 4)
        return normalized[-1][1] if target == normalized[-1][0] else None

    return {
        "status": "analyzed", "point_count": len(normalized),
        "retention_at_30s_pct": at_time(30), "retention_at_60s_pct": at_time(60),
        "largest_drop": largest, "drop_segments": drops,
        "net_retention_change_pct_points": round(normalized[-1][1] - normalized[0][1], 4),
        "interpretation_limit": "Descriptive first-party curve; compare by format, duration, traffic source and cohort before changing content.",
    }


def analyze_search_intent_map(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Find uncovered queries and intent clusters assigned to multiple videos.

    Multi-video intent clusters are review flags, not proof of cannibalization.
    """
    if isinstance(rows, (str, bytes)):
        raise ValueError("search intent rows must be a sequence of objects")
    grouped: dict[str, set[str]] = defaultdict(set)
    unassigned: list[str] = []
    normalized = []
    for row in rows:
        if not isinstance(row, Mapping):
            raise ValueError("each search intent row must be an object")
        query = str(row.get("query") or "").strip()
        intent = str(row.get("intent") or "").strip().lower()
        video_id = str(row.get("video_id") or "").strip()
        if not query:
            raise ValueError("each search intent row requires a query")
        if not intent:
            raise ValueError(f"query {query!r} requires an intent")
        normalized.append({"query": query, "intent": intent, "video_id": video_id or None})
        if video_id:
            grouped[intent].add(video_id)
        else:
            unassigned.append(query)
    flags = [{"intent": intent, "video_ids": sorted(video_ids), "video_count": len(video_ids),
              "status": "review_overlap_not_confirmed_cannibalization"}
             for intent, video_ids in sorted(grouped.items()) if len(video_ids) > 1]
    return {"status": "analyzed", "query_count": len(normalized),
            "assigned_query_count": len(normalized) - len(unassigned),
            "unassigned_query_count": len(unassigned), "unassigned_queries": unassigned,
            "intent_counts": {intent: sum(1 for row in normalized if row["intent"] == intent)
                              for intent in sorted({row["intent"] for row in normalized})},
            "cannibalization_flags": flags,
            "interpretation_limit": "Intent overlap is a review signal; confirm with actual Search traffic, query-level performance and audience differences.",
            "rows": normalized}


def audit_localization_coverage(markets: Sequence[Mapping[str, Any]], *, now: datetime | None = None,
                                freshness_days: int = 180) -> dict[str, Any]:
    """Audit per-market localization evidence; never equate translation with fluency."""
    if isinstance(markets, (str, bytes)):
        raise ValueError("markets must be a sequence of objects")
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    if isinstance(freshness_days, bool) or not isinstance(freshness_days, int) or freshness_days < 1:
        raise ValueError("freshness_days must be a positive integer")
    results = []
    seen = set()
    for market in markets:
        if not isinstance(market, Mapping):
            raise ValueError("each market localization record must be an object")
        market_id = str(market.get("market_id") or "").strip()
        if not market_id or market_id in seen:
            raise ValueError("market_id must be non-empty and unique")
        seen.add(market_id)
        variants = market.get("query_variants") or []
        if not isinstance(variants, Sequence) or isinstance(variants, (str, bytes)):
            raise ValueError(f"query_variants for {market_id} must be a list")
        clean_variants = [str(item).strip() for item in variants if str(item).strip()]
        review_time = None
        try:
            raw_reviewed_at = str(market.get("reviewed_at") or "").strip()
            review_time = datetime.fromisoformat(raw_reviewed_at.replace("Z", "+00:00")) if raw_reviewed_at else None
        except ValueError:
            review_time = None
        review_fresh = bool(review_time and review_time.tzinfo and review_time.utcoffset() is not None
                            and reference - timedelta(days=freshness_days) <= review_time <= reference + timedelta(days=1))
        native = (market.get("native_reviewed") is True
                  and bool(str(market.get("review_source_ref") or "").strip()) and review_fresh)
        dialect = market.get("dialect_reviewed") is True
        accent = market.get("accent_reviewed") is True
        cultural = market.get("cultural_reviewed") is True
        if not clean_variants:
            status = "missing_localized_queries"
        elif market.get("native_reviewed") is True and not review_fresh:
            status = "stale_or_undated_native_review"
        elif not native:
            status = "machine_or_unreviewed"
        elif not (dialect and accent and cultural):
            status = "native_reviewed_dialect_pending"
        else:
            status = "ready_for_content_qa"
        results.append({"market_id": market_id, "query_variant_count": len(clean_variants),
                        "native_reviewed": native, "review_fresh": review_fresh,
                        "reviewed_at": review_time.isoformat() if review_time and review_time.tzinfo else None,
                        "dialect_reviewed": dialect,
                        "accent_reviewed": accent, "cultural_reviewed": cultural,
                        "review_source_ref": str(market.get("review_source_ref") or "") or None,
                        "status": status})
    ready = sum(item["status"] == "ready_for_content_qa" for item in results)
    return {"status": "audited", "market_count": len(results), "ready_market_count": ready,
            "pending_market_count": len(results) - ready, "markets": results,
            "interpretation_limit": "Readiness requires recorded human review; this audit does not itself validate language, accent, dialect or cultural quality."}


def analyze_competitor_weaknesses(observations: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Aggregate explicitly sourced competitor-gap observations by gap category."""
    if isinstance(observations, (str, bytes)):
        raise ValueError("observations must be a sequence of objects")
    groups: dict[str, list[tuple[float, int, str]]] = defaultdict(list)
    rejected = 0
    for item in observations:
        if not isinstance(item, Mapping):
            raise ValueError("each competitor observation must be an object")
        competitor = str(item.get("competitor_id") or "").strip()
        gap = str(item.get("gap") or "").strip()
        source = str(item.get("source_ref") or "").strip()
        if not competitor or not gap or not source:
            rejected += 1
            continue
        severity = _finite_number(item.get("severity"), "severity", minimum=0, maximum=100)
        raw_count = item.get("audience_evidence_count", 0)
        if isinstance(raw_count, bool) or not isinstance(raw_count, int) or raw_count < 0:
            raise ValueError("audience_evidence_count must be a non-negative integer")
        audience_count = raw_count
        groups[gap].append((severity, audience_count, competitor))
    opportunities = []
    for gap, entries in groups.items():
        evidence_total = sum(entry[1] for entry in entries)
        weighted = (sum(severity * count for severity, count, _ in entries) / evidence_total
                    if evidence_total else mean(entry[0] for entry in entries))
        opportunities.append({"gap": gap, "weighted_severity": round(weighted, 2),
                              "observation_count": len(entries),
                              "competitor_count": len({entry[2] for entry in entries}),
                              "audience_evidence_count": evidence_total,
                              "priority_basis": "audience_evidence_weighted" if evidence_total else "unweighted_observation_only"})
    opportunities.sort(key=lambda item: (item["audience_evidence_count"], item["weighted_severity"]), reverse=True)
    return {"status": "analyzed", "accepted_observation_count": sum(map(len, groups.values())),
            "rejected_observation_count": rejected, "opportunities": opportunities,
            "interpretation_limit": "Only source-referenced observations are included. Severity is operator-coded, not independently verified or a guarantee of market demand."}


def analyze_ctr_experiment(control_impressions: int, control_clicks: int,
                           treatment_impressions: int, treatment_clicks: int, *,
                           randomized: bool = False, alpha: float = 0.05) -> dict[str, Any]:
    """Analyze a two-arm CTR test; inferential output is withheld unless randomized."""
    for value, label in ((control_impressions, "control_impressions"),
                         (treatment_impressions, "treatment_impressions"),
                         (control_clicks, "control_clicks"),
                         (treatment_clicks, "treatment_clicks")):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{label} must be a non-negative integer")
    if control_impressions == 0 or treatment_impressions == 0:
        raise ValueError("both arms require at least one impression")
    if control_clicks > control_impressions or treatment_clicks > treatment_impressions:
        raise ValueError("clicks cannot exceed impressions")
    alpha_value = _finite_number(alpha, "alpha", minimum=0.0001, maximum=0.2)
    p1 = control_clicks / control_impressions
    p2 = treatment_clicks / treatment_impressions
    difference = p2 - p1
    lift = difference / p1 * 100 if p1 > 0 else None
    ci_half = 1.96 * sqrt(p1 * (1 - p1) / control_impressions + p2 * (1 - p2) / treatment_impressions)
    ci = [round((difference - ci_half) * 100, 4), round((difference + ci_half) * 100, 4)]
    p_value = None
    significant = None
    if randomized:
        pooled = (control_clicks + treatment_clicks) / (control_impressions + treatment_impressions)
        standard_error = sqrt(pooled * (1 - pooled) * (1 / control_impressions + 1 / treatment_impressions))
        if standard_error == 0:
            p_value = 1.0 if difference == 0 else 0.0
        else:
            z = difference / standard_error
            p_value = min(1.0, erfc(abs(z) / sqrt(2)))
        significant = p_value < alpha_value
    low_expected = min(control_impressions * p1, control_impressions * (1 - p1),
                       treatment_impressions * p2, treatment_impressions * (1 - p2)) < 5
    if not randomized:
        status = "observational_only"
    elif low_expected:
        status = "randomized_small_cell_counts_interpret_cautiously"
    elif significant:
        status = "statistically_detectable"
    else:
        status = "no_statistically_detectable_difference"
    return {"status": "analyzed", "decision_status": status,
            "control_ctr_pct": round(p1 * 100, 4), "treatment_ctr_pct": round(p2 * 100, 4),
            "absolute_lift_pct_points": round(difference * 100, 4),
            "relative_lift_pct": round(lift, 4) if lift is not None else None,
            "approx_95pct_ci_lift_pct_points": ci,
            "p_value_two_sided": round(p_value, 8) if p_value is not None else None,
            "alpha": alpha_value, "randomized": randomized,
            "sample_sizes": {"control_impressions": control_impressions,
                             "treatment_impressions": treatment_impressions},
            "interpretation_limit": "Approximate two-proportion z-test and Wald interval; valid only with proper random assignment, no sample-ratio mismatch, adequate power and predeclared primary metric."}


def evaluate_market_economics(expected_views: float, rpm_low: float, rpm_base: float,
                              rpm_high: float, production_cost: float,
                              localization_cost: float, risk_reserve: float,
                              confidence: float, rpm_source: str,
                              rpm_source_ref: str | None = None) -> dict[str, Any]:
    """Calculate transparent revenue scenarios; competitor RPM is never accepted."""
    views = _finite_number(expected_views, "expected_views", minimum=0)
    low = _finite_number(rpm_low, "rpm_low", minimum=0)
    base = _finite_number(rpm_base, "rpm_base", minimum=0)
    high = _finite_number(rpm_high, "rpm_high", minimum=0)
    if not low <= base <= high:
        raise ValueError("RPM scenarios must satisfy rpm_low <= rpm_base <= rpm_high")
    production = _finite_number(production_cost, "production_cost", minimum=0)
    localization = _finite_number(localization_cost, "localization_cost", minimum=0)
    reserve = _finite_number(risk_reserve, "risk_reserve", minimum=0)
    certainty = _finite_number(confidence, "confidence", minimum=0, maximum=1)
    source = str(rpm_source or "").strip()
    if source not in {"scenario_assumption", "owner_authorized_youtube_analytics"}:
        raise ValueError("rpm_source must be scenario_assumption or owner_authorized_youtube_analytics; competitor RPM is not public evidence")
    source_ref = str(rpm_source_ref or "").strip()
    if source == "owner_authorized_youtube_analytics" and not source_ref:
        raise ValueError("first-party RPM requires rpm_source_ref")
    costs = production + localization + reserve
    revenue = {name: round(views / 1000 * rate, 2)
               for name, rate in (("low", low), ("base", base), ("high", high))}
    net = {name: round(amount - costs, 2) for name, amount in revenue.items()}
    break_even = costs / (views / 1000) if views > 0 else None
    return {"status": "scenario_calculated", "expected_views": views,
            "rpm_scenarios": {"low": low, "base": base, "high": high},
            "revenue_scenarios": revenue, "total_cost_and_reserve": round(costs, 2),
            "net_scenarios": net,
            "confidence_adjusted_base_net": round(revenue["base"] * certainty - costs, 2),
            "break_even_rpm": round(break_even, 4) if break_even is not None else None,
            "confidence": certainty,
            "rpm_evidence_status": "first_party_analytics" if source == "owner_authorized_youtube_analytics" else "scenario_only",
            "rpm_source": source, "rpm_source_ref": source_ref or None,
            "interpretation_limit": "Views and RPM are assumptions unless backed by representative first-party history. This is a scenario model, not a forecast or monetization guarantee."}


def estimate_ctr_sample_size(baseline_ctr: float, minimum_detectable_effect: float, *,
                             alpha: float = 0.05, power: float = 0.8) -> dict[str, Any]:
    """Approximate impressions required per arm for a two-sided CTR comparison."""
    from statistics import NormalDist
    baseline = _finite_number(baseline_ctr, "baseline_ctr", minimum=0.000001, maximum=0.999999)
    mde = _finite_number(minimum_detectable_effect, "minimum_detectable_effect", minimum=0.000001)
    target = baseline + mde
    if target >= 1:
        raise ValueError("baseline_ctr + minimum_detectable_effect must be below 1")
    alpha_value = _finite_number(alpha, "alpha", minimum=0.0001, maximum=0.2)
    power_value = _finite_number(power, "power", minimum=0.5, maximum=0.999)
    z_alpha = NormalDist().inv_cdf(1 - alpha_value / 2)
    z_power = NormalDist().inv_cdf(power_value)
    pooled = (baseline + target) / 2
    numerator = z_alpha * sqrt(2 * pooled * (1 - pooled)) + z_power * sqrt(
        baseline * (1 - baseline) + target * (1 - target))
    per_arm = int(ceil((numerator / mde) ** 2))
    return {"status": "estimate", "impressions_per_arm": per_arm,
            "total_impressions": per_arm * 2, "baseline_ctr": baseline,
            "target_ctr": target, "minimum_detectable_effect": mde,
            "alpha": alpha_value, "power": power_value,
            "method": "normal approximation for two independent proportions",
            "interpretation_limit": "Planning approximation only; use the platform experiment design, account for multiple testing, traffic allocation, repeated viewers and eligibility constraints."}


def analyze_discovery_surface(surface: str, *, impressions: int, views: int,
                              ctr_pct: float, avg_view_duration_seconds: float,
                              avg_percentage_viewed: float,
                              baseline_ctr_pct: float | None = None,
                              baseline_avg_percentage_viewed: float | None = None) -> dict[str, Any]:
    """Diagnose packaging/retention alignment within one discovery surface."""
    name = str(surface or "").strip().lower()
    if name not in {"search", "browse", "suggested", "shorts", "external", "other"}:
        raise ValueError("surface must be search, browse, suggested, shorts, external or other")
    if isinstance(impressions, bool) or not isinstance(impressions, int) or impressions < 0:
        raise ValueError("impressions must be a non-negative integer")
    if isinstance(views, bool) or not isinstance(views, int) or views < 0:
        raise ValueError("views must be a non-negative integer")
    ctr = _finite_number(ctr_pct, "ctr_pct", minimum=0, maximum=100)
    avd = _finite_number(avg_view_duration_seconds, "avg_view_duration_seconds", minimum=0)
    apv = _finite_number(avg_percentage_viewed, "avg_percentage_viewed", minimum=0, maximum=100)
    if (baseline_ctr_pct is None) != (baseline_avg_percentage_viewed is None):
        raise ValueError("both baseline metrics must be supplied together")
    flags = []
    if baseline_ctr_pct is not None and baseline_avg_percentage_viewed is not None:
        base_ctr = _finite_number(baseline_ctr_pct, "baseline_ctr_pct", minimum=0.000001, maximum=100)
        base_apv = _finite_number(baseline_avg_percentage_viewed,
                                  "baseline_avg_percentage_viewed", minimum=0.000001, maximum=100)
        if ctr >= base_ctr * 1.2 and apv <= base_apv * 0.75:
            flags.append("high_ctr_low_retention_review_promise_delivery")
        elif ctr <= base_ctr * 0.8 and apv >= base_apv * 1.2:
            flags.append("low_ctr_high_retention_review_packaging")
    return {"status": "analyzed", "surface": name, "impressions": impressions,
            "views": views, "ctr_pct": ctr, "avg_view_duration_seconds": avd,
            "avg_percentage_viewed": apv, "diagnostic_flags": flags,
            "baseline_comparison_available": baseline_ctr_pct is not None and baseline_avg_percentage_viewed is not None,
            "interpretation_limit": "Heuristic diagnostic thresholds are not YouTube ranking rules. Compare matched format, video age, audience and traffic-source cohorts."}


def evaluate_content_readiness(checklist: Mapping[str, Any]) -> dict[str, Any]:
    """Score a pre-publication checklist while enforcing rights/localization gates."""
    if not isinstance(checklist, Mapping):
        raise ValueError("checklist must be an object")
    items = ("hook_defined", "promise_clear", "proof_present", "payoff_delivered",
             "rights_reviewed", "localization_reviewed", "thumbnail_title_aligned", "cta_relevant")
    normalized = {name: checklist.get(name) is True for name in items}
    passed = sum(normalized.values())
    blocking = [name for name in ("rights_reviewed", "localization_reviewed") if not normalized[name]]
    status = "hold_hard_gate" if blocking else ("ready_for_human_final_qa" if passed == len(items) else "revise_before_publish")
    return {"status": status, "readiness_score_pct": round(passed / len(items) * 100, 2),
            "passed_count": passed, "total_count": len(items),
            "missing_items": [name for name, value in normalized.items() if not value],
            "blocking_items": blocking, "checklist": normalized,
            "interpretation_limit": "Checklist completion is a workflow gate, not proof of audience satisfaction, legal clearance or platform approval."}


def analyze_growth_bundle(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Run all supplied growth diagnostics; absent inputs remain explicitly unconfigured."""
    if not isinstance(payload, Mapping):
        raise ValueError("growth bundle must be a JSON object")

    def mapping_input(key: str) -> Mapping[str, Any]:
        value = payload.get(key)
        if value is None:
            return {}
        if not isinstance(value, Mapping):
            raise ValueError(f"{key} must be an object keyed by stable IDs")
        return value

    def sequence_input(key: str):
        value = payload.get(key)
        if value is None:
            return None
        if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
            raise ValueError(f"{key} must be a list")
        return value

    def optional_sequence(key: str, fn):
        value = sequence_input(key)
        if value is None:
            return {"status": "not_configured"}
        if not value:
            return {"status": "insufficient_data"}
        return fn(value)

    retention_input = mapping_input("retention_curves")
    retention = {str(video_id): analyze_retention_curve(points)
                 for video_id, points in retention_input.items()}
    experiment_input = mapping_input("ctr_experiments")
    experiments = {}
    for experiment_id, data in experiment_input.items():
        if not isinstance(data, Mapping):
            raise ValueError(f"CTR experiment {experiment_id} must be an object")
        try:
            experiments[str(experiment_id)] = analyze_ctr_experiment(
                data["control_impressions"], data["control_clicks"],
                data["treatment_impressions"], data["treatment_clicks"],
                randomized=data.get("randomized", False), alpha=data.get("alpha", 0.05))
        except KeyError as exc:
            raise ValueError(f"CTR experiment {experiment_id} is missing {exc.args[0]}") from exc
    sample_plan_input = mapping_input("ctr_sample_size_plans")
    sample_plans = {}
    for plan_id, data in sample_plan_input.items():
        if not isinstance(data, Mapping):
            raise ValueError(f"CTR sample-size plan {plan_id} must be an object")
        try:
            sample_plans[str(plan_id)] = estimate_ctr_sample_size(**data)
        except TypeError as exc:
            raise ValueError(f"CTR sample-size plan {plan_id} has invalid fields: {exc}") from exc
    economics_input = mapping_input("market_economics")
    economics = {}
    for market_id, data in economics_input.items():
        if not isinstance(data, Mapping):
            raise ValueError(f"market economics {market_id} must be an object")
        try:
            economics[str(market_id)] = evaluate_market_economics(**data)
        except TypeError as exc:
            raise ValueError(f"market economics {market_id} has invalid fields: {exc}") from exc
    surface_input = mapping_input("discovery_surfaces")
    surfaces = {}
    for video_id, data in surface_input.items():
        if isinstance(data, (str, bytes)) or not isinstance(data, Sequence):
            raise ValueError(f"discovery surfaces for {video_id} must be a list")
        surfaces[str(video_id)] = [analyze_discovery_surface(**item) for item in data]
    readiness_input = mapping_input("content_readiness")
    readiness = {str(video_id): evaluate_content_readiness(checklist)
                 for video_id, checklist in readiness_input.items()}
    portfolio_input = payload.get("portfolio_allocations")
    if portfolio_input is not None and not isinstance(portfolio_input, Mapping):
        raise ValueError("portfolio_allocations must be an object")
    from .kpi_calculations import portfolio_concentration_hhi
    portfolio = ({"status": "not_configured"} if portfolio_input is None else
                 ({"status": "insufficient_data"} if not portfolio_input else
                  portfolio_concentration_hhi(portfolio_input)))
    from .growth_operations import (
        analyze_audience_voice, assess_experiment_integrity, build_competitor_evidence_graph,
        build_editorial_backlog, build_video_brief, calculate_first_party_kpi_tree,
        evaluate_portfolio_allocation, validate_automation_job,
    )
    competitor_graph_input = sequence_input("competitor_evidence_observations")
    audience_input = sequence_input("audience_samples")
    backlog_input = payload.get("editorial_backlog")
    if backlog_input is not None and not isinstance(backlog_input, Mapping):
        raise ValueError("editorial_backlog must be an object with topics and capacity_hours")
    brief_input = mapping_input("video_briefs")
    first_party_input = mapping_input("first_party_kpis")
    integrity_input = mapping_input("experiment_integrity")
    allocation_input = payload.get("portfolio_resource_allocation")
    if allocation_input is not None and not isinstance(allocation_input, Mapping):
        raise ValueError("portfolio_resource_allocation must be an object")
    automation_input = sequence_input("automation_jobs")

    from .advanced_intelligence import (
        analyze_competitor_velocity, analyze_forecast_intervals, analyze_originality_risk,
        analyze_proportion_experiment, analyze_satisfaction_survey, analyze_topic_saturation,
        analyze_forecast_drift, audit_market_coverage, audit_source_quality, compare_forecast_models,
        calculate_risk_adjusted_contribution, correct_multiple_testing,
        generate_localized_query_plan, summarize_audience_cohorts,
    )
    market_coverage_input = payload.get("market_coverage")
    if market_coverage_input is not None and not isinstance(market_coverage_input, Mapping):
        raise ValueError("market_coverage must be an object")
    localized_input = payload.get("localized_query_plan")
    if localized_input is not None and not isinstance(localized_input, Mapping):
        raise ValueError("localized_query_plan must be an object")
    def keyed_advanced(key: str, fn):
        data = mapping_input(key)
        output = {}
        for item_id, config in data.items():
            if not isinstance(config, Mapping):
                raise ValueError(f"{key}.{item_id} must be an object")
            output[str(item_id)] = fn(config)
        return output or {"status": "not_configured"}

    forecast = keyed_advanced("forecast_intervals", lambda row: analyze_forecast_intervals(
        row["actuals"], row["lower_bounds"], row["upper_bounds"]))
    robust_experiments = keyed_advanced("proportion_experiments", lambda row: analyze_proportion_experiment(**row))
    model_comparisons = keyed_advanced("forecast_model_comparisons", lambda row: compare_forecast_models(**row))
    topic_saturation = keyed_advanced("topic_saturation", lambda row: analyze_topic_saturation(**row))
    satisfaction_surveys = keyed_advanced("satisfaction_surveys", lambda row: analyze_satisfaction_survey(row["responses"]))
    forecast_drift = keyed_advanced("forecast_drift", lambda row: analyze_forecast_drift(**row))
    multiple_testing = keyed_advanced("multiple_testing_families", lambda row: correct_multiple_testing(row["p_values"]))
    economics_advanced = keyed_advanced("risk_adjusted_economics", lambda row: calculate_risk_adjusted_contribution(**row))
    competitor_snapshots = optional_sequence("competitor_snapshots", analyze_competitor_velocity)
    originality = optional_sequence("originality_items", analyze_originality_risk)
    cohorts = optional_sequence("audience_cohorts", summarize_audience_cohorts)
    source_quality = optional_sequence("source_quality_records", audit_source_quality)
    localized_plan = (generate_localized_query_plan(
        localized_input.get("seed", ""), localized_input.get("markets", []),
        curated_variants=localized_input.get("curated_variants", {}),
        translated_queries=localized_input.get("translated_queries", {}),
        max_variants=localized_input.get("max_variants", 5))
        if localized_input is not None else {"status": "not_configured"})

    return {
        "schema_version": "v17-growth-audit-1.2",
        "retention": retention or {"status": "not_configured"},
        "search_intent": optional_sequence("search_intent_rows", analyze_search_intent_map),
        "localization": optional_sequence("localization_markets", audit_localization_coverage),
        "competitor_weaknesses": optional_sequence("competitor_observations", analyze_competitor_weaknesses),
        "ctr_experiments": experiments or {"status": "not_configured"},
        "ctr_sample_size_plans": sample_plans or {"status": "not_configured"},
        "market_economics": economics or {"status": "not_configured"},
        "discovery_surfaces": surfaces or {"status": "not_configured"},
        "content_readiness": readiness or {"status": "not_configured"},
        "portfolio_metrics": portfolio,
        "competitor_evidence_graph": (build_competitor_evidence_graph(competitor_graph_input)
                                      if competitor_graph_input is not None else {"status": "not_configured"}),
        "audience_voice": (analyze_audience_voice(audience_input)
                           if audience_input is not None else {"status": "not_configured"}),
        "editorial_backlog": (build_editorial_backlog(backlog_input.get("topics", []),
                                                       capacity_hours=backlog_input.get("capacity_hours", 0))
                              if backlog_input is not None else {"status": "not_configured"}),
        "video_briefs": ({str(key): build_video_brief(value) for key, value in brief_input.items()}
                         if brief_input else {"status": "not_configured"}),
        "first_party_kpis": ({str(key): calculate_first_party_kpi_tree(value) for key, value in first_party_input.items()}
                              if first_party_input else {"status": "not_configured"}),
        "experiment_integrity": ({str(key): assess_experiment_integrity(value) for key, value in integrity_input.items()}
                                  if integrity_input else {"status": "not_configured"}),
        "portfolio_resource_allocation": (evaluate_portfolio_allocation(
            allocation_input.get("markets", []), capacity_hours=allocation_input.get("capacity_hours", 0))
            if allocation_input is not None else {"status": "not_configured"}),
        "automation_job_reviews": ([validate_automation_job(job) for job in automation_input]
                                   if automation_input is not None else {"status": "not_configured"}),
        "market_coverage": (audit_market_coverage(market_coverage_input.get("expected_market_ids", []),
                                                   market_coverage_input.get("attempts", []))
                            if market_coverage_input is not None else {"status": "not_configured"}),
        "localized_query_plan": localized_plan,
        "competitor_velocity": competitor_snapshots,
        "originality_risk": originality,
        "audience_cohorts": cohorts,
        "source_quality": source_quality,
        "forecast_intervals": forecast,
        "robust_proportion_experiments": robust_experiments,
        "forecast_model_comparisons": model_comparisons,
        "topic_saturation": topic_saturation,
        "satisfaction_surveys": satisfaction_surveys,
        "forecast_drift": forecast_drift,
        "multiple_testing_adjustment": multiple_testing,
        "risk_adjusted_economics": economics_advanced,
        "decision_log_inputs": {"status": "not_configured", "note": "Persist decisions through DecisionLogRepository after human approval."},
        "limitations": [
            "No hidden competitor RPM, audience demographics or algorithm ranking factors are inferred.",
            "Public search samples are not a census; retention and CTR require first-party or experiment data.",
            "Native dialect/accent/cultural quality requires recorded human review.",
            "A diagnostic flag is a hypothesis for review, not proof of causality or a guaranteed growth tactic.",
            "Coverage, localization, originality and competitor velocity are bounded by supplied records; no all-country or all-YouTube census is implied.",
            "Forecast interval coverage and multiple-testing adjustments require valid holdout and experiment designs.",
        ],
    }
