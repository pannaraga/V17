from __future__ import annotations
import json
from pathlib import Path
from typing import Any


def export_report(result: dict[str,Any], path: str | Path, *, format: str | None=None) -> Path:
    target=Path(path); kind=(format or target.suffix.lstrip(".") or "json").lower()
    if kind=="json": target.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
    elif kind=="md":
        lines=[f"# V17 Research: {result['run']['topic']}","",f"- Run: `{result['run']['id']}`",f"- Mode: {result['run']['mode']}",
               f"- Country: {result['run']['country_code']}",f"- Score status: {result['analysis']['status']}",
               f"- Coverage: {result['analysis']['coverage']:.0%}","","## Provider status"]
        lines += [f"- **{name}:** {value.get('status','unknown')}" for name,value in result['providers'].items()]
        lines += ["","## Videos"] + [f"- {v['title']} — {v['format']['label']} — views: {v['views']}" for v in result['videos']]
        lines += ["","## Limitations"] + [f"- {x}" for x in result['limitations']]
        target.write_text("\n".join(lines)+"\n",encoding="utf-8")
    elif kind=="csv":
        import csv
        with target.open("w",newline="",encoding="utf-8") as f:
            writer=csv.DictWriter(f,fieldnames=["video_id","title","channel_id","views","published_at","format"]); writer.writeheader()
            for v in result["videos"]: writer.writerow({**{k:v.get(k) for k in ("video_id","title","channel_id","views","published_at")},"format":v["format"]["label"]})
    else: raise ValueError("format must be json, md, or csv")
    return target
