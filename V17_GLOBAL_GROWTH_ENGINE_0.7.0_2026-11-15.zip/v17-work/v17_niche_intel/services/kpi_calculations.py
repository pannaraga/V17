"""Transparent portfolio, forecast, and experiment KPI calculations.

These utilities calculate descriptive metrics only. They do not infer missing
market allocations, manufacture forecasts, or establish causal significance.
"""
from __future__ import annotations

from math import isfinite
from statistics import mean
from typing import Mapping, Sequence


def portfolio_concentration_hhi(allocations: Mapping[str, float]) -> dict[str, float | int]:
    """Return normalized portfolio HHI (0-10,000) and effective market count."""
    if not isinstance(allocations, Mapping) or not allocations:
        raise ValueError("allocations must be a non-empty market-to-allocation mapping")
    values: dict[str, float] = {}
    for market, raw in allocations.items():
        if not isinstance(market, str) or not market.strip():
            raise ValueError("market allocation keys must be non-empty strings")
        if isinstance(raw, bool) or not isinstance(raw, (int, float)) or not isfinite(float(raw)) or raw < 0:
            raise ValueError(f"allocation for {market} must be a finite non-negative number")
        values[market] = float(raw)
    total = sum(values.values())
    if total <= 0:
        raise ValueError("total portfolio allocation must be greater than zero")
    shares = [value / total for value in values.values()]
    hhi = sum((share * 100) ** 2 for share in shares)
    concentration = sum(share ** 2 for share in shares)
    return {
        "hhi_0_10000": round(hhi, 2),
        "effective_market_count": round(1 / concentration, 4),
        "largest_market_share_pct": round(max(shares) * 100, 2),
        "top_three_market_share_pct": round(sum(sorted(shares, reverse=True)[:3]) * 100, 2),
        "market_count": len(shares),
    }


def forecast_error_metrics(actuals: Sequence[float], forecasts: Sequence[float]) -> dict[str, float | int | None]:
    """Return MAE, WAPE, MAPE (non-zero actuals), and signed aggregate bias."""
    if isinstance(actuals, (str, bytes)) or isinstance(forecasts, (str, bytes)):
        raise ValueError("actuals and forecasts must be numeric sequences")
    if not actuals or len(actuals) != len(forecasts):
        raise ValueError("actuals and forecasts must have the same non-zero length")
    actual_values: list[float] = []
    forecast_values: list[float] = []
    for actual, forecast in zip(actuals, forecasts):
        for value, label in ((actual, "actual"), (forecast, "forecast")):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)) or value < 0:
                raise ValueError(f"{label} values must be finite non-negative numbers")
        actual_values.append(float(actual))
        forecast_values.append(float(forecast))
    errors = [abs(forecast - actual) for actual, forecast in zip(actual_values, forecast_values)]
    total_actual = sum(actual_values)
    nonzero_actual_errors = [error / actual for actual, error in zip(actual_values, errors) if actual > 0]
    signed_error = sum(forecast - actual for actual, forecast in zip(actual_values, forecast_values))
    return {
        "n": len(actual_values),
        "mae": round(mean(errors), 6),
        "wape_pct": round(sum(errors) / total_actual * 100, 6) if total_actual > 0 else None,
        "mape_pct": round(mean(nonzero_actual_errors) * 100, 6) if nonzero_actual_errors else None,
        "aggregate_bias_pct": round(signed_error / total_actual * 100, 6) if total_actual > 0 else None,
        "zero_actual_count": sum(1 for actual in actual_values if actual == 0),
    }


def experiment_lift(baseline: Sequence[float], treatment: Sequence[float]) -> dict[str, float | int | None]:
    """Return descriptive treatment lift; statistical/causal validity is separate."""
    if isinstance(baseline, (str, bytes)) or isinstance(treatment, (str, bytes)) or not baseline or not treatment:
        raise ValueError("baseline and treatment must be non-empty numeric sequences")
    groups: list[list[float]] = []
    for values, label in ((baseline, "baseline"), (treatment, "treatment")):
        normalized = []
        for value in values:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)) or value < 0:
                raise ValueError(f"{label} values must be finite non-negative numbers")
            normalized.append(float(value))
        groups.append(normalized)
    baseline_mean, treatment_mean = mean(groups[0]), mean(groups[1])
    lift = treatment_mean - baseline_mean
    return {
        "baseline_n": len(groups[0]),
        "treatment_n": len(groups[1]),
        "baseline_mean": round(baseline_mean, 6),
        "treatment_mean": round(treatment_mean, 6),
        "absolute_lift": round(lift, 6),
        "relative_lift_pct": round(lift / baseline_mean * 100, 6) if baseline_mean > 0 else None,
    }
