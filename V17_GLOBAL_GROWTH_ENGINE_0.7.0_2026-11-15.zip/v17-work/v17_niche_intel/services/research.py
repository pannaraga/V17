from __future__ import annotations
from datetime import date, datetime, timezone
from typing import Any
from ..domain.format_classifier import classify_video_format
from ..domain.scoring import score_opportunity
from ..storage.repositories import ResearchRunRepository, EvidenceRepository, ResultRepository, SnapshotRepository, PrivateAnalyticsRepository
from ..domain.models import Evidence
from ..domain.enums import EvidenceStatus
from ..credentials.manager import QuotaExhaustedError
from ..domain.confidence import assess_confidence
from ..domain.market_intelligence import (classify_search_intent, cluster_topics, calculate_serp_volatility,
    analyze_seasonality, assess_freshness, analyze_content_freshness, extract_audience_pain_points)
from .market_intelligence import MarketIntelligenceService
from .retention import purge_expired_public_youtube_data

class ResearchService:
    def __init__(self, database, *, youtube_provider=None, trends_provider=None, analytics_provider=None):
        self.db=database; self.youtube=youtube_provider; self.trends=trends_provider; self.analytics=analytics_provider
        self.runs=ResearchRunRepository(database); self.evidence=EvidenceRepository(database); self.results=ResultRepository(database); self.snapshots=SnapshotRepository(database)
        self.private_analytics=PrivateAnalyticsRepository(database)

    def research(self, *, topic: str, country_code: str, mode: str="market_entry", limit: int=25,
                 formats: tuple[str,...]=( "shorts", "long_form", "live"), language_code: str | None = None,
                 channel_id: str | None = None, analytics_start_date: date | None = None,
                 analytics_end_date: date | None = None) -> dict[str,Any]:
        if mode not in {"market_entry","existing_channel","both"}: raise ValueError("unsupported mode")
        retention_result = purge_expired_public_youtube_data(self.db, retention_days=30)
        run_id=self.runs.create(topic=topic,mode=mode,country_code=country_code,
            algorithm_version="v17-balanced-0.1.0",config={"limit":min(max(1,limit),50),"formats":list(formats),
                "country_code":country_code.upper(),"language_code":language_code})
        providers={}; videos=[]
        if self.youtube:
            try:
                batch=self.youtube.search_videos(topic,country_code,limit=limit)
                providers["youtube"]={"status":batch.status,"failed_orders":list(batch.failed_orders),"detail_failures":batch.detail_failures}
                videos=list(batch.videos)
                now=datetime.now(timezone.utc)
                has_sample = bool(videos) and batch.status in {"ok", "partial"}
                self.evidence.add(run_id,Evidence("youtube_sample_size",len(videos) if has_sample else None,"youtube_data_api",now,
                    EvidenceStatus.OK if has_sample else EvidenceStatus.NO_DATA,0.8,
                    f"youtube-search:{country_code}:{topic}",{"query_orders":list(batch.query_orders),"provider_status":batch.status}))
                for video in videos:
                    self.evidence.add(run_id,Evidence("public_video_views",video.views,"youtube_data_api",now,
                        EvidenceStatus.OK if video.views is not None else EvidenceStatus.NO_DATA,0.8,
                        f"youtube-video:{video.video_id}",{"video_id":video.video_id,"channel_id":video.channel_id})) if video.views is not None else None
            except QuotaExhaustedError:
                providers["youtube"]={"status":"quota_exhausted","error_type":"QuotaExhaustedError"}
            except Exception as exc:
                providers["youtube"]={"status":"error","error_type":type(exc).__name__}
        else: providers["youtube"]={"status":"not_configured"}
        if self.trends:
            try: providers["google_trends"]=self.trends.interest_over_time(topic,geo=country_code)
            except Exception as exc: providers["google_trends"]={"status":"error","error_type":type(exc).__name__}
        else: providers["google_trends"]={"status":"not_configured"}
        trends_result = providers.get("google_trends", {})
        if isinstance(trends_result, dict) and trends_result.get("status") == "ok":
            features = trends_result.get("features", {})
            trend_value = features.get("mean_relative_interest")
            if trend_value is not None:
                self.evidence.add(run_id, Evidence("trend_mean_relative_interest", trend_value,
                    "google_trends", datetime.now(timezone.utc), EvidenceStatus.OK, 0.7,
                    f"google-trends:{country_code}:{topic}", {"geo": country_code.upper(),
                    "language_code": language_code, "timeframe": trends_result.get("timeframe"),
                    "metric_semantics": "relative_index_not_search_volume"}))
        comment_texts = []
        comment_statuses = []
        if self.youtube and hasattr(self.youtube, "fetch_public_comments"):
            for video in videos[:5]:
                try:
                    comment_batch = self.youtube.fetch_public_comments(video.video_id, limit=20)
                    comment_texts.extend(comment_batch.get("comments", ()))
                    comment_statuses.append(comment_batch.get("status", "unknown"))
                except Exception as exc:
                    comment_statuses.append(type(exc).__name__)
        classified=[]
        for v in videos:
            c=classify_video_format(duration_seconds=v.duration_seconds,live_broadcast_content=v.live_broadcast_content,
                                    live_streaming_details=v.live_streaming_details)
            classified.append({"video_id":v.video_id,"title":v.title,"channel_id":v.channel_id,"views":v.views,
                "published_at":v.published_at.isoformat(),"format":{"label":str(c.label),"confidence":c.confidence,"method":c.method}})
        # Public evidence alone does not satisfy the complete balanced score gate.
        score=score_opportunity({"demand":None,"competition_opportunity":None,"momentum_stability":None,
            "format_fit":None,"business_feasibility":None,"risk_resilience":None})
        run=self.runs.get(run_id)
        analysis={"status":score.status,"score":score.score,"coverage":score.coverage,
                  "missing_dimensions":list(score.missing_dimensions),"algorithm_version":score.algorithm_version}
        private_channel_result = {"status": "not_configured"}
        if mode in {"existing_channel", "both"}:
            if self.analytics and channel_id and analytics_start_date and analytics_end_date:
                if analytics_start_date > analytics_end_date:
                    raise ValueError("analytics_start_date must not be after analytics_end_date")
                try:
                    analytics_payload = self.analytics.query_daily(channel_id=channel_id,
                        start_date=analytics_start_date, end_date=analytics_end_date)
                    aliases = {"day": "date", "video": "video_id", "estimatedMinutesWatched": "watch_time_minutes",
                               "averageViewDuration": "average_view_duration_seconds"}
                    rows = tuple({aliases.get(key, key): value for key, value in item.items()}
                                 for item in analytics_payload.get("records", []))
                    if rows and "video_id" in rows[0]:
                        inserted = self.private_analytics.import_rows(channel_id=channel_id, rows=rows, run_id=run_id,
                            provenance=analytics_payload.get("provenance"))
                    else:
                        inserted = self.private_analytics.import_daily_rows(channel_id=channel_id, rows=rows,
                            provenance=analytics_payload.get("provenance"))
                    private_channel_result = {"status": "ok", "channel_id": channel_id,
                        "date_range": [analytics_start_date.isoformat(), analytics_end_date.isoformat()],
                        "rows_returned": len(rows), "rows_inserted": inserted,
                        "storage": "private_channel_analytics_only", "metrics": rows}
                except Exception as exc:
                    private_channel_result = {"status": "error", "error_type": type(exc).__name__}
            elif self.analytics and not channel_id:
                private_channel_result = {"status": "missing_channel_id"}
            elif self.analytics and (not analytics_start_date or not analytics_end_date):
                private_channel_result = {"status": "missing_date_range"}
            analysis["existing_channel_status"] = private_channel_result["status"]
        evidence_rows = self.evidence.list_for_run(run_id)
        from ..domain.models import Evidence as EvidenceModel
        from ..domain.enums import EvidenceStatus as Status
        confidence_evidence = [EvidenceModel(
            metric=row["metric"], value=row["value"], source_family=row["source_family"],
            observed_at=datetime.fromisoformat(row["observed_at"]), status=Status(row["status"]),
            quality=row["quality"], source_ref=row["source_ref"], metadata=row["metadata"])
            for row in evidence_rows]
        confidence = assess_confidence(confidence_evidence, now=datetime.now(timezone.utc))
        trends = providers.get("google_trends", {})
        trend_points = trends.get("points", []) if isinstance(trends, dict) else []
        seasonality = analyze_seasonality(trend_points) if trend_points else {"status": "not_configured"}
        for video in videos:
            self.snapshots.add(run_id,video_id=video.video_id,observed_at=datetime.now(timezone.utc),
                views=video.views,likes=video.likes,comments=video.comments)
        with self.db.read() as connection:
            snapshot_count = connection.execute("SELECT COUNT(*) FROM video_snapshots WHERE run_id=?", (run_id,)).fetchone()[0]
            tracked_video_count = connection.execute("SELECT COUNT(*) FROM (SELECT video_id FROM video_snapshots WHERE run_id=? GROUP BY video_id HAVING COUNT(*) >= 2)", (run_id,)).fetchone()[0]
            history_rows = connection.execute("SELECT video_id,observed_at,views FROM video_snapshots WHERE run_id=? ORDER BY observed_at", (run_id,)).fetchall()
        historical_tracking = MarketIntelligenceService._history([dict(row) for row in history_rows])
        market_intelligence = {
            "search_intent": classify_search_intent(topic),
            "topic_clusters": cluster_topics([topic]),
            "competitor_overlap": {"status": "not_configured", "reason": "Requires comparable multi-keyword channel samples."},
            "serp_volatility": {"status": "insufficient_data", "reason": "Requires timestamped SERP rank snapshots."},
            "cannibalization": {"status": "not_configured", "reason": "Requires the channel's content inventory and assigned intents."},
            "seasonality": seasonality,
            "geographic_segmentation": {"status": "single_market", "country": country_code.upper(), "cross_market_comparable": False},
            "language_segmentation": {"status": "configured" if language_code else "not_configured", "language": language_code},
            "freshness": assess_freshness(datetime.now(timezone.utc)),
            "content_freshness": analyze_content_freshness([{"published_at": video.published_at.isoformat(), "views": video.views} for video in videos]),
            "thumbnail_benchmark": {"status": "not_configured", "reason": "Requires sampled thumbnail image metadata."},
            "audio_benchmark": {"status": "not_configured", "reason": "Requires measured audio feature data."},
            "audience_pain_points": ({**extract_audience_pain_points(comment_texts),
                "collection_source": "public_youtube_comment_threads", "video_sample_size": min(len(videos), 5),
                "comment_statuses": comment_statuses, "raw_comments_persisted": False}
                if comment_texts else {"status": ("error" if any(status in {"error", "APIKeyInvalidError", "QuotaExhaustedError"} for status in comment_statuses)
                    else "no_data" if comment_statuses else "not_configured"),
                    "reason": "Comments may be disabled, unavailable, or unsupported by the configured provider.",
                    "comment_statuses": comment_statuses, "raw_comments_persisted": False}),
            "confidence": {"level": str(confidence.level), "independent_source_count": confidence.independent_source_count,
                           "quality_index": confidence.quality_index, "source_families": list(confidence.source_families)},
            "historical_tracking": {**historical_tracking, "video_snapshot_count": snapshot_count,
                "videos_with_multiple_snapshots": tracked_video_count, "growth_velocity_available": tracked_video_count > 0},
            "experiment_validation": {"status": "not_configured", "reason": "Requires baseline and treatment observations."},
            "data_provenance": ([{"source": "youtube_data_api" if name == "youtube" else name, "status": value.get("status", "unknown") if isinstance(value, dict) else "ok",
                                  "retrieved_at": datetime.now(timezone.utc).isoformat(),
                                  "sample_size": len(videos) if name == "youtube" else len(trend_points) if name == "google_trends" else None}
                                 for name, value in providers.items()] + ([{"source": "youtube_comment_threads",
                                    "status": "ok" if comment_texts else "not_available", "retrieved_at": datetime.now(timezone.utc).isoformat(),
                                    "sample_size": len(comment_texts), "author_metadata_returned": False, "raw_comments_persisted": False}]
                                    if hasattr(self.youtube, "fetch_public_comments") else [])),
        }
        result={"run":run,"providers":providers,"videos":classified,"analysis":analysis,
                "retention": retention_result,
                "private_channel_analytics": private_channel_result if mode in {"existing_channel", "both"} else {"status": "not_applicable"},
                "market_intelligence":market_intelligence,
                "limitations":["YouTube search results are a sample, not a census.","Shorts are candidates unless authoritative format metadata is available.",
                "Public competitor metrics do not reveal private Analytics metrics.","A score is withheld until minimum evidence coverage is met.",
                "Unconfigured intelligence modules are explicitly marked; they are not inferred or filled with synthetic data."]}
        self.results.save(run_id,result)
        return result

    def snapshot(self, run_id: str) -> dict[str,Any]:
        run=self.runs.get(run_id)
        if run is None: raise KeyError(run_id)
        if not self.youtube: raise RuntimeError("YouTube provider is not configured")
        batch=self.youtube.search_videos(run["topic"],run["country_code"] or "US",limit=50)
        now=datetime.now(timezone.utc); inserted=0
        for video in batch.videos:
            inserted += int(self.snapshots.add(run_id,video_id=video.video_id,observed_at=now,
                views=video.views,likes=video.likes,comments=video.comments))
        with self.db.read() as connection:
            history_rows = connection.execute("SELECT video_id,observed_at,views FROM video_snapshots WHERE run_id=? ORDER BY observed_at", (run_id,)).fetchall()
        history = MarketIntelligenceService._history([dict(row) for row in history_rows])
        saved = self.results.get(run_id)
        if saved:
            intel = saved.setdefault("market_intelligence", {})
            intel["historical_tracking"] = {**history, "video_snapshot_count": len(history_rows),
                "videos_with_multiple_snapshots": history["videos_with_growth_measurement"],
                "growth_velocity_available": history["videos_with_growth_measurement"] > 0}
            self.results.save(run_id, saved)
        return {"run_id":run_id,"status":batch.status,"videos_seen":len(batch.videos),"snapshots_inserted":inserted,
                "historical_tracking": history,
                "note":"Growth is calculated only between two timestamped snapshots of the same video."}
