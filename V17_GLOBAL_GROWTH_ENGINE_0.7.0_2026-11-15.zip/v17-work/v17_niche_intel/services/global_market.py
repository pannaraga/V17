"""Global, evidence-aware market discovery and four-layer decisions.

Country-level trend indices are kept market-local. They are never treated as
absolute search volume or compared as if Google Trends were a common scale.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from ipaddress import ip_address
from math import isfinite
import re
from typing import Any, Callable, Mapping, Sequence
from urllib.parse import urlparse


@dataclass(frozen=True, slots=True)
class MarketProfile:
    country_code: str
    country_name: str
    language_code: str
    locale: str
    currency: str
    timezone: str
    localization_note: str = "Machine translation requires native-speaker review."
    metadata_status: str = "curated"

    @property
    def market_id(self) -> str:
        return f"{self.country_code}-{self.language_code}"

    @property
    def youtube_relevance_language(self) -> str:
        if self.language_code == "zh":
            if "Hant" in self.locale or self.country_code in {"TW", "HK", "MO"}:
                return "zh-Hant"
            return "zh-Hans"
        return self.language_code

    @property
    def translation_target(self) -> str:
        if self.youtube_relevance_language == "zh-Hant":
            return "zh-TW"
        if self.youtube_relevance_language == "zh-Hans":
            return "zh-CN"
        return self.language_code


# Initial coverage registry, not a claim that every provider supports every market.
DEFAULT_MARKETS = (
    MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York", "US English; validate regional vocabulary and cultural references."),
    MarketProfile("CA", "Canada", "en", "en-CA", "CAD", "America/Toronto", "Canadian English; consider French-Canadian audiences separately."),
    MarketProfile("GB", "United Kingdom", "en", "en-GB", "GBP", "Europe/London", "British English spelling, idiom, and references."),
    MarketProfile("AU", "Australia", "en", "en-AU", "AUD", "Australia/Sydney", "Australian English and local references."),
    MarketProfile("NZ", "New Zealand", "en", "en-NZ", "NZD", "Pacific/Auckland", "New Zealand English and local references."),
    MarketProfile("IE", "Ireland", "en", "en-IE", "EUR", "Europe/Dublin", "Irish English; validate local terminology."),
    MarketProfile("DE", "Germany", "de", "de-DE", "EUR", "Europe/Berlin", "Standard German; regional dialect review where relevant."),
    MarketProfile("AT", "Austria", "de", "de-AT", "EUR", "Europe/Vienna", "Austrian German vocabulary and spelling."),
    MarketProfile("CH", "Switzerland", "de", "de-CH", "CHF", "Europe/Zurich", "Choose German, French, or Italian audience explicitly; registry default is German."),
    MarketProfile("FR", "France", "fr", "fr-FR", "EUR", "Europe/Paris", "Metropolitan French; validate informal register and regional references."),
    MarketProfile("ES", "Spain", "es", "es-ES", "EUR", "Europe/Madrid", "Spain Spanish; distinguish Latin American variants."),
    MarketProfile("IT", "Italy", "it", "it-IT", "EUR", "Europe/Rome", "Italian idiom and cultural references."),
    MarketProfile("NL", "Netherlands", "nl", "nl-NL", "EUR", "Europe/Amsterdam", "Dutch language; consider Flemish as a separate audience."),
    MarketProfile("SE", "Sweden", "sv", "sv-SE", "SEK", "Europe/Stockholm"),
    MarketProfile("NO", "Norway", "no", "nb-NO", "NOK", "Europe/Oslo", "Bokmål default; Nynorsk may be relevant in some segments."),
    MarketProfile("DK", "Denmark", "da", "da-DK", "DKK", "Europe/Copenhagen"),
    MarketProfile("FI", "Finland", "fi", "fi-FI", "EUR", "Europe/Helsinki", "Finnish default; Swedish-speaking audience is separate."),
    MarketProfile("PL", "Poland", "pl", "pl-PL", "PLN", "Europe/Warsaw"),
    MarketProfile("PT", "Portugal", "pt", "pt-PT", "EUR", "Europe/Lisbon", "European Portuguese; do not reuse Brazilian Portuguese without review."),
    MarketProfile("BR", "Brazil", "pt", "pt-BR", "BRL", "America/Sao_Paulo", "Brazilian Portuguese; validate regional and informal register."),
    MarketProfile("MX", "Mexico", "es", "es-MX", "MXN", "America/Mexico_City", "Mexican Spanish; local idiom and references."),
    MarketProfile("AR", "Argentina", "es", "es-AR", "ARS", "America/Argentina/Buenos_Aires", "Rioplatense voseo and local idiom require native review."),
    MarketProfile("CO", "Colombia", "es", "es-CO", "COP", "America/Bogota", "Colombian Spanish; avoid assuming one national dialect."),
    MarketProfile("CL", "Chile", "es", "es-CL", "CLP", "America/Santiago", "Chilean Spanish colloquialisms require native review."),
    MarketProfile("JP", "Japan", "ja", "ja-JP", "JPY", "Asia/Tokyo", "Japanese register, politeness, scripts, and search phrasing require native review."),
    MarketProfile("KR", "South Korea", "ko", "ko-KR", "KRW", "Asia/Seoul", "Korean honorific/register and spacing require native review."),
    MarketProfile("SG", "Singapore", "en", "en-SG", "SGD", "Asia/Singapore", "English is multilingual and code-switching varies by audience."),
    MarketProfile("MY", "Malaysia", "ms", "ms-MY", "MYR", "Asia/Kuala_Lumpur", "Malay default; English, Mandarin, and Tamil segments need separate treatment."),
    MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta", "Bahasa Indonesia; colloquial Jakarta slang is not universal across regions."),
    MarketProfile("IN", "India", "hi", "hi-IN", "INR", "Asia/Kolkata", "Hindi default is not representative of India's many language markets; expand by language/region."),
    MarketProfile("PH", "Philippines", "en", "en-PH", "PHP", "Asia/Manila", "English default; Filipino and code-switched audiences need separate query variants."),
    MarketProfile("TH", "Thailand", "th", "th-TH", "THB", "Asia/Bangkok", "Thai script and native search phrasing require review."),
    MarketProfile("VN", "Vietnam", "vi", "vi-VN", "VND", "Asia/Ho_Chi_Minh", "Vietnamese diacritics and colloquial register require review."),
    MarketProfile("ZA", "South Africa", "en", "en-ZA", "ZAR", "Africa/Johannesburg", "English is one of multiple language markets; local context varies."),
    MarketProfile("AE", "United Arab Emirates", "ar", "ar-AE", "AED", "Asia/Dubai", "Arabic/English audience split; dialect and RTL review required."),
    MarketProfile("SA", "Saudi Arabia", "ar", "ar-SA", "SAR", "Asia/Riyadh", "Arabic register and local cultural context require native review."),
    MarketProfile("TR", "Türkiye", "tr", "tr-TR", "TRY", "Europe/Istanbul", "Turkish idiom and local search phrasing require review."),
    # Additional language-market segments within multilingual countries.
    MarketProfile("CA", "Canada · French audience", "fr", "fr-CA", "CAD", "America/Toronto", "Canadian French vocabulary and local references; do not substitute metropolitan French."),
    MarketProfile("CH", "Switzerland · French audience", "fr", "fr-CH", "CHF", "Europe/Zurich", "Swiss French vocabulary and local context."),
    MarketProfile("CH", "Switzerland · Italian audience", "it", "it-CH", "CHF", "Europe/Zurich", "Swiss Italian vocabulary and local context."),
    MarketProfile("IN", "India · English audience", "en", "en-IN", "INR", "Asia/Kolkata", "Indian English; validate regional idiom and code-switching."),
    MarketProfile("IN", "India · Tamil audience", "ta", "ta-IN", "INR", "Asia/Kolkata", "Tamil language and regional cultural context require native review."),
    MarketProfile("IN", "India · Telugu audience", "te", "te-IN", "INR", "Asia/Kolkata", "Telugu language and regional cultural context require native review."),
    MarketProfile("IN", "India · Bengali audience", "bn", "bn-IN", "INR", "Asia/Kolkata", "Bengali language and regional cultural context require native review."),
    MarketProfile("PH", "Philippines · Filipino audience", "tl", "fil-PH", "PHP", "Asia/Manila", "Filipino/Tagalog and English code-switching need separate native review."),
    MarketProfile("SG", "Singapore · Mandarin audience", "zh", "zh-SG", "SGD", "Asia/Singapore", "Simplified Chinese and local multilingual search behavior require review."),
    MarketProfile("SG", "Singapore · Malay audience", "ms", "ms-SG", "SGD", "Asia/Singapore", "Singapore Malay register and local context require review."),
    MarketProfile("MY", "Malaysia · Mandarin audience", "zh", "zh-MY", "MYR", "Asia/Kuala_Lumpur", "Malaysian Mandarin search vocabulary and code-switching require review."),
    MarketProfile("MY", "Malaysia · Tamil audience", "ta", "ta-MY", "MYR", "Asia/Kuala_Lumpur", "Malaysian Tamil audience and local context require review."),
    MarketProfile("AE", "UAE · English audience", "en", "en-AE", "AED", "Asia/Dubai", "UAE English audience is multilingual; local context and code-switching require review."),
)


def build_market_registry(supported_regions: Sequence[Mapping[str, str]]) -> tuple[MarketProfile, ...]:
    """Build country-language profiles from YouTube's live supported-region list.

    Babel/pycountry/pytz supply locale, active currency, country name, and a
    representative timezone. Curated profiles preserve known multilingual
    segments. This is not a claim that one language/timezone represents everyone.
    """
    from datetime import date
    try:
        import pycountry
        import pytz
        from babel.core import get_global
        from babel.numbers import get_territory_currencies
    except ImportError as exc:
        raise RuntimeError("Install the global metadata extra: pip install -e '.[global]'") from exc
    if isinstance(supported_regions, (str, bytes)) or not isinstance(supported_regions, Sequence) or not supported_regions:
        raise ValueError("supported_regions must be a non-empty sequence")
    curated = {(market.country_code, market.language_code): market for market in DEFAULT_MARKETS}
    territory_languages = get_global("territory_languages")
    primary_profiles: list[MarketProfile] = []
    secondary_profiles: list[MarketProfile] = []
    seen_codes: set[str] = set()
    seen_profiles: set[str] = set()
    if any(not isinstance(region, Mapping) for region in supported_regions):
        raise ValueError("each supported region must be an object")
    ordered_regions = sorted(supported_regions, key=lambda region: str(region.get("code", "")).upper())
    for region in ordered_regions:
        code = str(region.get("code", "")).upper()
        if len(code) != 2 or not code.isalpha():
            raise ValueError(f"Invalid supported YouTube region code: {code!r}")
        country = pycountry.countries.get(alpha_2=code)
        if code in seen_codes:
            raise ValueError(f"Duplicate supported YouTube region code: {code}")
        seen_codes.add(code)
        country_name = str(region.get("name") or (country.name if country else code))
        candidates = []
        if country is None:
            metadata_gaps = ["Region code is returned by YouTube but is absent from the local ISO metadata package."]
        else:
            metadata_gaps = []
        for language, details in territory_languages.get(code, {}).items():
            base_language = language.split("_")[0]
            if len(base_language) != 2:
                continue
            population = float(details.get("population_percent") or 0)
            status = details.get("official_status")
            if population >= 5 or status in {"official", "de_facto_official"}:
                candidates.append((base_language, population, status))
        if not candidates:
            candidates = [("en", 0.0, None)]
            metadata_gaps.append("No reliable CLDR language profile; English is a query fallback only.")
        candidates.sort(key=lambda row: (-row[1], row[2] not in {"official", "de_facto_official"}, row[0]))
        # Include every CLDR language that is either officially recognized or
        # represents at least 5% of the territory's population, not only the top language.
        selected = {row[0] for row in candidates}
        selected.add(candidates[0][0])
        currencies = get_territory_currencies(code, tender=True, start_date=date.today(), end_date=date.today())
        currency = currencies[0] if currencies else "UNKNOWN"
        if not currencies:
            metadata_gaps.append("No current tender currency metadata; currency is UNKNOWN.")
        timezones = pytz.country_timezones.get(code, [])
        timezone_name = timezones[0] if timezones else "UTC"
        if not timezones:
            metadata_gaps.append("No country timezone metadata; UTC is a technical fallback only.")
        primary_language = candidates[0][0]
        for language in sorted(selected, key=lambda item: (item != primary_language, item)):
            profile = curated.get((code, language)) or MarketProfile(
                code, country_name, language,
                f"{language.split('_')[0]}-{'-'.join(language.split('_')[1:]) + '-' if '_' in language else ''}{code}",
                currency, timezone_name,
                "Official or major language segment; dialect, register, code-switching, and natural search phrasing require native review. "
                + ("Country spans multiple time zones; this is a representative timezone only. " if len(timezones) > 1 else "")
                + " ".join(metadata_gaps),
                "cldr" if not metadata_gaps else "partial_fallback",
            )
            if profile.market_id not in seen_profiles:
                target = primary_profiles if language == primary_language else secondary_profiles
                target.append(profile)
                seen_profiles.add(profile.market_id)
        for existing in DEFAULT_MARKETS:
            if existing.country_code == code and existing.market_id not in seen_profiles:
                secondary_profiles.append(existing)
                seen_profiles.add(existing.market_id)
    # Spend the scarce search.list call bucket on one primary-language profile
    # per country before sampling secondary language segments.
    return tuple(primary_profiles + secondary_profiles)

LAYER_WEIGHTS: dict[str, float] = {
    "audience_demand": 0.25,
    "competitive_opening": 0.25,
    "monetization_economics": 0.25,
    "creator_execution_fit": 0.25,
}
LAYER_COMPONENTS: dict[str, dict[str, float]] = {
    "audience_demand": {"search_interest": 0.30, "demand_growth": 0.20, "seasonality_stability": 0.15, "audience_pain_evidence": 0.20, "consumption_behavior": 0.15},
    "competitive_opening": {"competitor_concentration_opportunity": 0.25, "median_views_opportunity": 0.20, "views_velocity_opportunity": 0.25, "validated_content_gaps": 0.30},
    "monetization_economics": {"first_party_rpm": 0.20, "advertiser_demand": 0.25, "revenue_route_diversity": 0.15, "purchase_intent": 0.20, "audience_purchasing_power": 0.20},
    "creator_execution_fit": {"language_cultural_fluency": 0.25, "format_capability_fit": 0.25, "production_feasibility": 0.25, "policy_rights_resilience": 0.25},
}
REQUIRED_LAYER_COMPONENTS = {
    "creator_execution_fit": {"language_cultural_fluency", "policy_rights_resilience"},
}
MINIMUM_POLICY_RIGHTS_RESILIENCE_SCORE = 50.0


def _validate_coverage_threshold(minimum_coverage: float) -> None:
    if (isinstance(minimum_coverage, bool) or not isinstance(minimum_coverage, (int, float))
            or not isfinite(float(minimum_coverage)) or not 0.0 <= float(minimum_coverage) <= 1.0):
        raise ValueError("minimum_coverage must be a finite number between 0 and 1")


def score_layer_components(components: Mapping[str, Mapping[str, float | None]], *,
                           minimum_coverage: float = 0.75) -> dict[str, Any]:
    """Score each decision layer only from explicit, validated component evidence."""
    _validate_coverage_threshold(minimum_coverage)
    unknown_layers = set(components) - set(LAYER_COMPONENTS)
    if unknown_layers:
        raise ValueError(f"Unknown decision layers: {', '.join(sorted(unknown_layers))}")
    scores: dict[str, float | None] = {}
    detail: dict[str, Any] = {}
    for layer, weights in LAYER_COMPONENTS.items():
        values = components.get(layer, {})
        unknown = set(values) - set(weights)
        if unknown:
            raise ValueError(f"Unknown {layer} components: {', '.join(sorted(unknown))}")
        observed: dict[str, float] = {}
        for name, value in values.items():
            if value is None:
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)) or not 0 <= float(value) <= 100:
                raise ValueError(f"{layer}.{name} must be a finite number between 0 and 100")
            observed[name] = float(value)
        coverage = round(sum(weights[name] for name in observed), 8)
        missing_required = REQUIRED_LAYER_COMPONENTS.get(layer, set()) - set(observed)
        if coverage < minimum_coverage or missing_required:
            scores[layer] = None
            detail[layer] = {"status": "insufficient_evidence", "coverage": coverage,
                             "missing_components": sorted(set(weights) - set(observed)),
                             "missing_required_components": sorted(missing_required)}
        else:
            contributions = {name: round(weights[name] / coverage * value, 4) for name, value in observed.items()}
            scores[layer] = round(sum(contributions.values()), 2)
            detail[layer] = {"status": "scored", "coverage": coverage,
                             "score": scores[layer], "contributions": contributions,
                             "missing_components": sorted(set(weights) - set(observed))}
    decision = score_four_layers(scores, minimum_coverage=minimum_coverage)
    return {"layers": detail, "decision": asdict(decision)}


def rank_market_decisions(markets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Rank only scored markets; confidence breaks ties, never substitutes for evidence."""
    eligible = [item for item in markets
                if item.get("decision", {}).get("status") == "scored"
                and item.get("decision", {}).get("coverage") == 1.0
                and item.get("ranking_eligible") is True
                and isinstance(item.get("decision", {}).get("score"), (int, float))
                and item.get("eligibility", {}).get("status") == "eligible"]
    return sorted(eligible, key=lambda item: (
        -float(item["decision"]["score"]), -float(item.get("confidence", 0.0)),
        str(item.get("country_code", ""))))


@dataclass(frozen=True, slots=True)
class FourLayerDecision:
    status: str
    score: float | None
    coverage: float
    layer_scores: dict[str, float]
    contributions: dict[str, float]
    missing_layers: tuple[str, ...]
    algorithm_version: str = "v17-four-layer-1.0.0"


def score_four_layers(layers: Mapping[str, float | None], *, minimum_coverage: float = 0.75) -> FourLayerDecision:
    _validate_coverage_threshold(minimum_coverage)
    unknown = set(layers) - set(LAYER_WEIGHTS)
    if unknown:
        raise ValueError(f"Unknown decision layers: {', '.join(sorted(unknown))}")
    observed: dict[str, float] = {}
    missing: list[str] = []
    for name in LAYER_WEIGHTS:
        value = layers.get(name)
        if value is None:
            missing.append(name)
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)) or not 0 <= float(value) <= 100:
            raise ValueError(f"{name} must be a finite number between 0 and 100")
        observed[name] = float(value)
    coverage = round(sum(LAYER_WEIGHTS[key] for key in observed), 8)
    if coverage < minimum_coverage or not observed:
        return FourLayerDecision("insufficient_evidence", None, coverage, observed, {}, tuple(missing))
    contributions = {key: round((LAYER_WEIGHTS[key] / coverage) * value, 4) for key, value in observed.items()}
    return FourLayerDecision("scored", round(sum(contributions.values()), 2), coverage,
                             observed, contributions, tuple(missing))


def build_localized_queries(seed: str, market: MarketProfile, *, translated_query: str | None = None,
                            curated_variants: tuple[str, ...] = ()) -> tuple[str, ...]:
    if not seed.strip():
        raise ValueError("seed keyword must be non-empty")
    candidates = (seed, translated_query or "", *curated_variants)
    return tuple(dict.fromkeys(item.strip() for item in candidates if item and item.strip()))


def _normalize_component_evidence(
    raw: Mapping[str, Any] | None, *, now: datetime, max_age_days: int,
) -> tuple[dict[str, dict[str, float]], dict[str, dict[str, dict[str, Any]]]]:
    """Validate score evidence and keep stale/unreviewed records out of scoring."""
    if raw is None:
        raw = {}
    if not isinstance(raw, Mapping):
        raise ValueError("decision evidence must be an object keyed by decision layer")
    unknown_layers = set(raw) - set(LAYER_COMPONENTS)
    if unknown_layers:
        raise ValueError(f"Unknown decision layers: {', '.join(sorted(unknown_layers))}")
    scores: dict[str, dict[str, float]] = {}
    records: dict[str, dict[str, dict[str, Any]]] = {}
    for layer, components in raw.items():
        if not isinstance(components, Mapping):
            raise ValueError(f"{layer} evidence must be an object")
        unknown_components = set(components) - set(LAYER_COMPONENTS[layer])
        if unknown_components:
            raise ValueError(f"Unknown {layer} components: {', '.join(sorted(unknown_components))}")
        scores[layer] = {}
        records[layer] = {}
        for name, item in components.items():
            if not isinstance(item, Mapping):
                raise ValueError(f"{layer}.{name} evidence must be an object")
            required = ("score", "source_ref", "source_family", "observed_at", "confidence", "method")
            missing = [key for key in required if key not in item]
            if missing:
                raise ValueError(f"{layer}.{name} missing required evidence fields: {', '.join(missing)}")
            score = item["score"]
            confidence = item["confidence"]
            if isinstance(score, bool) or not isinstance(score, (int, float)) or not isfinite(float(score)) or not 0 <= float(score) <= 100:
                raise ValueError(f"{layer}.{name}.score must be a finite number between 0 and 100")
            if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not isfinite(float(confidence)) or not 0 <= float(confidence) <= 1:
                raise ValueError(f"{layer}.{name}.confidence must be a finite number between 0 and 1")
            for field in ("source_ref", "source_family", "method"):
                if not isinstance(item[field], str) or not item[field].strip():
                    raise ValueError(f"{layer}.{name}.{field} must be a non-empty string")
            try:
                observed_at = datetime.fromisoformat(str(item["observed_at"]).replace("Z", "+00:00"))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{layer}.{name}.observed_at must be an ISO-8601 timestamp") from exc
            if observed_at.tzinfo is None or observed_at.utcoffset() is None:
                raise ValueError(f"{layer}.{name}.observed_at must include a timezone")
            age = now - observed_at.astimezone(timezone.utc)
            if age < -timedelta(minutes=5):
                raise ValueError(f"{layer}.{name}.observed_at cannot be in the future")
            record = {**dict(item), "observed_at": observed_at.isoformat(), "score": float(score),
                      "confidence": float(confidence)}
            if name == "first_party_rpm" and item["source_family"] != "owner_authorized_youtube_analytics":
                raise ValueError("first_party_rpm requires owner-authorized YouTube Analytics evidence")
            if name == "language_cultural_fluency" and item.get("native_review_status") == "native_reviewed" and item["source_family"] != "native_speaker_review":
                raise ValueError("native-reviewed language evidence requires source_family=native_speaker_review")
            if name == "language_cultural_fluency" and item.get("native_review_status") != "native_reviewed":
                record["status"] = "rejected_native_review_required"
            elif age > timedelta(days=max_age_days):
                record["status"] = "stale"
            else:
                record["status"] = "accepted"
                scores[layer][name] = float(score)
            records[layer][name] = record
    return scores, records


def _validate_review_source_ref(value: str, name: str) -> None:
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower().rstrip(".")
    invalid_host = (not host or host in {"localhost", "localhost.localdomain"}
        or host.endswith((".localhost", ".local", ".internal")) or "." not in host
        or not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", host))
    try:
        address = ip_address(host)
        invalid_host = invalid_host or not address.is_global
    except ValueError:
        pass
    if (parsed.scheme != "https" or invalid_host or parsed.username or parsed.password
            or parsed.port not in (None, 443)):
        raise ValueError(f"{name} must be a public HTTPS URL on the standard port without embedded credentials")


def _normalize_localized_query_variants(
    raw: Mapping[str, Any] | None, *, market_ids: set[str], now: datetime, max_age_days: int,
) -> dict[str, dict[str, Any]]:
    """Validate operator-curated local queries and their optional native-review provenance."""
    if raw is None:
        return {}
    if not isinstance(raw, Mapping):
        raise ValueError("localized_query_variants must be an object keyed by market ID")
    unknown = set(raw) - market_ids
    if unknown:
        raise ValueError(f"localized_query_variants contains unknown market IDs: {', '.join(sorted(unknown))}")
    normalized: dict[str, dict[str, Any]] = {}
    for market_id, item in raw.items():
        if not isinstance(item, Mapping):
            raise ValueError(f"localized_query_variants.{market_id} must be an object")
        unexpected = set(item) - {"queries", "review_status", "source_ref", "reviewed_at", "reviewer_ref",
            "dialect_reviewed", "accent_reviewed", "cultural_reviewed"}
        if unexpected:
            raise ValueError(f"localized_query_variants.{market_id} has unknown fields: {', '.join(sorted(unexpected))}")
        queries = item.get("queries")
        if isinstance(queries, (str, bytes)) or not isinstance(queries, Sequence) or not queries:
            raise ValueError(f"localized_query_variants.{market_id}.queries must be a non-empty list")
        if len(queries) > 12:
            raise ValueError(f"localized_query_variants.{market_id}.queries may contain at most 12 variants")
        if any(not isinstance(query, str) or not query.strip() for query in queries):
            raise ValueError(f"localized_query_variants.{market_id}.queries must contain non-empty strings")
        deduplicated = tuple(dict.fromkeys(query.strip() for query in queries))
        review_status = item.get("review_status", "not_reviewed")
        if not isinstance(review_status, str) or review_status not in {"native_reviewed", "pending", "not_reviewed"}:
            raise ValueError(f"localized_query_variants.{market_id}.review_status is invalid")
        source_ref = item.get("source_ref")
        reviewer_ref = item.get("reviewer_ref")
        reviewed_at_raw = item.get("reviewed_at")
        for field, value in (("source_ref", source_ref), ("reviewer_ref", reviewer_ref)):
            if value is not None and (not isinstance(value, str) or not value.strip()):
                raise ValueError(f"localized_query_variants.{market_id}.{field} must be a non-empty string")
        reviewed_at = None
        if review_status == "native_reviewed":
            if not isinstance(source_ref, str) or not source_ref.strip():
                raise ValueError(f"localized_query_variants.{market_id}.source_ref is required for native_reviewed queries")
            _validate_review_source_ref(source_ref, f"localized_query_variants.{market_id}.source_ref")
            if not isinstance(reviewed_at_raw, str) or not reviewed_at_raw.strip():
                raise ValueError(f"localized_query_variants.{market_id}.reviewed_at is required for native_reviewed queries")
            try:
                reviewed_at = datetime.fromisoformat(reviewed_at_raw.replace("Z", "+00:00"))
            except ValueError as exc:
                raise ValueError(f"localized_query_variants.{market_id}.reviewed_at must be an ISO-8601 timestamp") from exc
            if reviewed_at.tzinfo is None or reviewed_at.utcoffset() is None:
                raise ValueError(f"localized_query_variants.{market_id}.reviewed_at must include a timezone")
            age = now - reviewed_at.astimezone(timezone.utc)
            if age < -timedelta(minutes=5):
                raise ValueError(f"localized_query_variants.{market_id}.reviewed_at cannot be in the future")
            if age > timedelta(days=max_age_days):
                review_status = "stale"
            elif not all(item.get(field) is True for field in ("dialect_reviewed", "accent_reviewed", "cultural_reviewed")):
                review_status = "pending"
        elif reviewed_at_raw is not None:
            if not isinstance(reviewed_at_raw, str) or not reviewed_at_raw.strip():
                raise ValueError(f"localized_query_variants.{market_id}.reviewed_at must be a non-empty ISO-8601 string")
            try:
                reviewed_at = datetime.fromisoformat(reviewed_at_raw.replace("Z", "+00:00"))
            except ValueError as exc:
                raise ValueError(f"localized_query_variants.{market_id}.reviewed_at must be an ISO-8601 timestamp") from exc
            if reviewed_at.tzinfo is None or reviewed_at.utcoffset() is None:
                raise ValueError(f"localized_query_variants.{market_id}.reviewed_at must include a timezone")
        normalized[market_id] = {
            "queries": deduplicated, "review_status": review_status,
            "source_ref": source_ref, "reviewer_ref": reviewer_ref,
            "reviewed_at": reviewed_at.isoformat() if reviewed_at else None,
        }
    return normalized


def _normalize_market_eligibility(
    raw: Mapping[str, Any] | None, *, now: datetime, max_age_days: int,
) -> dict[str, Any]:
    if raw is None:
        return {"status": "not_evaluated", "reasons": []}
    if not isinstance(raw, Mapping):
        raise ValueError("market eligibility must be an object")
    status = raw.get("status")
    if not isinstance(status, str) or status not in {"eligible", "rejected", "hold", "not_evaluated"}:
        raise ValueError("market eligibility status must be eligible, rejected, hold, or not_evaluated")
    reasons = raw.get("reasons", [])
    if not isinstance(reasons, list) or any(not isinstance(reason, str) or not reason.strip() for reason in reasons):
        raise ValueError("market eligibility reasons must be a list of non-empty strings")
    if status == "not_evaluated":
        return {"status": status, "reasons": list(reasons)}
    for field in ("source_ref", "source_family", "observed_at", "method"):
        if not isinstance(raw.get(field), str) or not raw[field].strip():
            raise ValueError(f"market eligibility {field} must be a non-empty string")
    try:
        observed_at = datetime.fromisoformat(raw["observed_at"].replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise ValueError("market eligibility observed_at must be an ISO-8601 timestamp") from exc
    if observed_at.tzinfo is None or observed_at.utcoffset() is None:
        raise ValueError("market eligibility observed_at must include a timezone")
    age = now - observed_at.astimezone(timezone.utc)
    if age < -timedelta(minutes=5):
        raise ValueError("market eligibility observed_at cannot be in the future")
    if age > timedelta(days=max_age_days):
        return {**dict(raw), "status": "hold", "reasons": [*reasons, "Eligibility evidence is stale; revalidation required."],
                "evidence_status": "stale"}
    return {**dict(raw), "status": status, "reasons": list(reasons),
            "observed_at": observed_at.isoformat(), "evidence_status": "accepted"}


class GlobalMarketDiscoveryService:
    """Run isolated market scans; score only current, provenance-backed evidence."""

    def __init__(self, *, youtube_provider: Any = None,
                 trends_provider_factory: Callable[[MarketProfile], Any] | None = None,
                 translator: Callable[[str, str], str] | None = None):
        self.youtube = youtube_provider
        self.trends_factory = trends_provider_factory
        self.translator = translator

    def discover(self, *, topic: str, markets: tuple[MarketProfile, ...] = DEFAULT_MARKETS,
                 limit: int = 25, query_orders: tuple[str, ...] = ("relevance",),
                 query_variant_limit: int = 1,
                 decision_evidence: Mapping[str, Mapping[str, Any]] | None = None,
                 market_eligibility: Mapping[str, Mapping[str, Any]] | None = None,
                 localized_query_variants: Mapping[str, Mapping[str, Any]] | None = None,
                 evidence_max_age_days: int = 180,
                 search_call_budget: int | None = None,
                 other_quota_budget_units: int | None = None,
                 trends_call_budget: int | None = None,
                 other_quota_preconsumed_units: int = 0,
                 search_quota_limit: int = 100,
                 other_quota_limit: int = 10000,
                 market_registry_source: str = "curated_default") -> dict[str, Any]:
        if not isinstance(topic, str) or not topic.strip():
            raise ValueError("topic must be a non-empty string")
        if isinstance(markets, (str, bytes)) or not isinstance(markets, Sequence) or not markets:
            raise ValueError("markets must be a non-empty sequence of MarketProfile values")
        if any(not isinstance(market, MarketProfile) for market in markets):
            raise ValueError("markets must contain only MarketProfile values")
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
            raise ValueError("limit must be an integer of at least 1")
        if isinstance(query_variant_limit, bool) or not isinstance(query_variant_limit, int) or not 1 <= query_variant_limit <= 12:
            raise ValueError("query_variant_limit must be an integer from 1 to 12")
        allowed_orders = {"date", "rating", "relevance", "title", "videoCount", "viewCount"}
        if (isinstance(query_orders, (str, bytes)) or not isinstance(query_orders, Sequence)
                or not query_orders or any(not isinstance(order, str) or order not in allowed_orders for order in query_orders)):
            raise ValueError("query_orders must be a non-empty sequence of supported YouTube search orders")
        query_orders = tuple(dict.fromkeys(query_orders))
        if len({m.market_id for m in markets}) != len(markets):
            raise ValueError("market country-language pairs must be unique")
        if not isinstance(evidence_max_age_days, int) or isinstance(evidence_max_age_days, bool) or evidence_max_age_days < 1:
            raise ValueError("evidence_max_age_days must be a positive integer")
        if search_call_budget is not None and (not isinstance(search_call_budget, int) or isinstance(search_call_budget, bool) or search_call_budget < 0):
            raise ValueError("search_call_budget must be a non-negative integer")
        if other_quota_budget_units is not None and (not isinstance(other_quota_budget_units, int) or isinstance(other_quota_budget_units, bool) or other_quota_budget_units < 0):
            raise ValueError("other_quota_budget_units must be a non-negative integer")
        if trends_call_budget is not None and (not isinstance(trends_call_budget, int) or isinstance(trends_call_budget, bool) or trends_call_budget < 0):
            raise ValueError("trends_call_budget must be a non-negative integer")
        if not isinstance(other_quota_preconsumed_units, int) or isinstance(other_quota_preconsumed_units, bool) or other_quota_preconsumed_units < 0:
            raise ValueError("other_quota_preconsumed_units must be a non-negative integer")
        if not isinstance(search_quota_limit, int) or isinstance(search_quota_limit, bool) or search_quota_limit < 1:
            raise ValueError("search_quota_limit must be a positive integer")
        if not isinstance(other_quota_limit, int) or isinstance(other_quota_limit, bool) or other_quota_limit < 1:
            raise ValueError("other_quota_limit must be a positive integer")
        if not isinstance(market_registry_source, str) or not market_registry_source.strip():
            raise ValueError("market_registry_source must be non-empty")
        market_ids = {market.market_id for market in markets}
        for label, supplied in (("decision_evidence", decision_evidence), ("market_eligibility", market_eligibility)):
            if supplied is not None and not isinstance(supplied, Mapping):
                raise ValueError(f"{label} must be an object keyed by market ID")
            unknown = set(supplied or {}) - market_ids
            if unknown:
                raise ValueError(f"{label} contains unknown market IDs: {', '.join(sorted(unknown))}")
        now = datetime.now(timezone.utc)
        query_reviews = _normalize_localized_query_variants(
            localized_query_variants, market_ids=market_ids, now=now, max_age_days=evidence_max_age_days)
        estimated_search_calls = len(markets) * query_variant_limit * len(query_orders) if self.youtube else 0
        estimated_other_units = (len(markets) * query_variant_limit if self.youtube and limit > 0 else 0) + other_quota_preconsumed_units
        attempted_search_calls = 0
        attempted_other_units = other_quota_preconsumed_units
        attempted_trends_calls = 0
        trends_budget_limited = False
        budget_limited = False
        quota_blocked = False
        results = []
        for market in markets:
            query_review = query_reviews.get(market.market_id)
            localized = None
            localization_status = "seed_only"
            if self.translator and not query_review:
                try:
                    localized = self.translator(topic, market.translation_target)
                    localization_status = "machine_translated_native_review_required" if localized else "seed_only"
                except Exception as exc:
                    localization_status = f"translation_error:{type(exc).__name__}"
            curated_queries = query_review["queries"] if query_review else ()
            queries = build_localized_queries(topic, market, translated_query=localized,
                                              curated_variants=curated_queries)
            selected_query = (curated_queries[0] if curated_queries else localized or topic.strip())
            selected_query_source = (
                "native_reviewed_curated" if query_review and query_review["review_status"] == "native_reviewed"
                else "operator_curated_unverified" if query_review
                else "machine_translation" if localized else "seed"
            )
            if query_review:
                localization_status = {
                    "native_reviewed": "native_reviewed_curated_queries",
                    "stale": "operator_curated_queries_review_stale",
                }.get(query_review["review_status"], "operator_curated_queries_native_review_pending")
            market_result: dict[str, Any] = {
                "market_id": market.market_id, "country_code": market.country_code,
                "country_name": market.country_name, "language_code": market.language_code, "locale": market.locale,
                "currency": market.currency, "timezone": market.timezone,
                "metadata_status": market.metadata_status,
                "localization": {"status": localization_status, "queries": list(queries),
                                 "selected_query": selected_query,
                                 "selected_query_source": selected_query_source,
                                 "translation_target": market.translation_target,
                                 "youtube_relevance_language": market.youtube_relevance_language,
                                 "native_review_required": selected_query_source != "native_reviewed_curated",
                                 "native_validation_status": query_review["review_status"] if query_review else "not_verified",
                                 "query_review": ({key: value for key, value in query_review.items() if key != "queries"}
                                                  if query_review else None),
                                 "note": market.localization_note},
                "youtube": {"status": "not_configured", "videos": []},
                "google_trends": {"status": "not_configured"},
                "decision": asdict(score_four_layers({})),
                "decision_layers": score_layer_components({})["layers"],
                "decision_evidence": {},
                "eligibility": _normalize_market_eligibility(
                    (market_eligibility or {}).get(market.market_id), now=now, max_age_days=evidence_max_age_days),
                "limitations": [],
            }
            if self.youtube:
                preferred_queries = list(curated_queries) if curated_queries else list(queries)
                active_queries = list(dict.fromkeys(preferred_queries))[:query_variant_limit]
                search_cost = len(active_queries) * len(query_orders)
                detail_reserve = len(active_queries)
                effective_search_budget = search_call_budget if search_call_budget is not None else search_quota_limit
                effective_other_budget = other_quota_budget_units if other_quota_budget_units is not None else other_quota_limit
                search_budget_exceeded = attempted_search_calls + search_cost > effective_search_budget
                other_budget_exceeded = attempted_other_units + detail_reserve > effective_other_budget
                if quota_blocked or search_budget_exceeded or other_budget_exceeded:
                    budget_limited = True
                    market_result["youtube"] = {"status": "skipped_quota_budget", "videos": [],
                                                "estimated_search_calls": search_cost,
                                                "reserved_other_units": detail_reserve,
                                                "query_variant_count": len(active_queries)}
                    market_result["limitations"].append("Skipped to stay within the configured YouTube quota budget or because the project quota is exhausted.")
                else:
                    attempted_search_calls += search_cost
                    attempted_other_units += detail_reserve
                    video_by_id: dict[str, dict[str, Any]] = {}
                    failed_orders: list[str] = []
                    detail_failures = 0
                    query_results = []
                    statuses = []
                    quota_error_type = None
                    for query in active_queries:
                        try:
                            batch = self.youtube.search_videos(query, market.country_code, limit=limit,
                                query_orders=query_orders, relevance_language=market.youtube_relevance_language)
                            statuses.append(batch.status)
                            failed_orders.extend([f"{query}:{order}" for order in batch.failed_orders])
                            detail_failures += batch.detail_failures
                            query_results.append({"query": query, "status": batch.status, "sample_size": len(batch.videos)})
                            for video in batch.videos:
                                video_by_id.setdefault(video.video_id, {"video_id": video.video_id, "title": video.title,
                                    "channel_id": video.channel_id, "channel_title": video.channel_title,
                                    "views": video.views, "published_at": video.published_at.isoformat(),
                                    "duration_seconds": video.duration_seconds, "url": video.url})
                        except Exception as exc:
                            quota_error = type(exc).__name__ in {"QuotaExhaustedError", "YouTubeQuotaExceededError"} or "quota exhausted" in str(exc).lower() or "daily limit exceeded" in str(exc).lower()
                            statuses.append("quota_exhausted" if quota_error else "error")
                            query_results.append({"query": query, "status": statuses[-1], "error_type": type(exc).__name__})
                            if quota_error:
                                quota_blocked = True
                                budget_limited = True
                                quota_error_type = type(exc).__name__
                                break
                    successful = any(status in {"ok", "partial"} for status in statuses)
                    overall_status = "partial" if successful and (len(statuses) < len(active_queries) or any(status != "ok" for status in statuses)) else ("ok" if successful else ("quota_exhausted" if quota_blocked else "error"))
                    market_result["youtube"] = {"status": overall_status, "videos": list(video_by_id.values()),
                        "sample_size": len(video_by_id), "failed_orders": failed_orders,
                        "detail_failures": detail_failures, "query_results": query_results,
                        "query_variant_count": len(active_queries), "query_variants_sampled": active_queries,
                        "error_type": quota_error_type}
                    if not successful:
                        market_result["limitations"].append("YouTube returned no usable public video sample for this market.")
            if self.trends_factory:
                if trends_call_budget is not None and attempted_trends_calls >= trends_call_budget:
                    trends_budget_limited = True
                    market_result["google_trends"] = {"status": "skipped_quota_budget"}
                    market_result["limitations"].append("Google Trends query skipped to stay within the configured trends-call budget.")
                else:
                    attempted_trends_calls += 1
                    try:
                        trends = self.trends_factory(market)
                        market_result["google_trends"] = trends.interest_over_time(selected_query, geo=market.country_code)
                        if market_result["google_trends"].get("status") == "ok":
                            market_result["google_trends"]["metric_semantics"] = "market_local_relative_index_not_absolute_search_volume"
                    except Exception as exc:
                        market_result["google_trends"] = {"status": "error", "error_type": type(exc).__name__}
                        market_result["limitations"].append("Google Trends query failed for this market.")
            if not self.youtube and not self.trends_factory:
                market_result["limitations"].append("No global market data providers are configured; only the market/localization matrix is available.")

            supplied = (decision_evidence or {}).get(market.market_id, {})
            component_scores, evidence_records = _normalize_component_evidence(
                supplied, now=now, max_age_days=evidence_max_age_days)
            scored = score_layer_components(component_scores)
            market_result["decision"] = scored["decision"]
            market_result["decision_layers"] = scored["layers"]
            market_result["decision_evidence"] = evidence_records
            accepted = [record for layer in evidence_records.values() for record in layer.values()
                        if record.get("status") == "accepted"]
            by_source: dict[str, list[float]] = {}
            for record in accepted:
                by_source.setdefault(record["source_family"], []).append(record["confidence"])
            source_confidence = [sum(values) / len(values) for values in by_source.values()]
            market_result["confidence"] = round(sum(source_confidence) / len(source_confidence), 4) if source_confidence else 0.0
            market_result["confidence_source_families"] = sorted(by_source)
            market_result["independent_source_count"] = len(by_source)
            rights_score = component_scores.get("creator_execution_fit", {}).get("policy_rights_resilience")
            if rights_score is not None and rights_score < MINIMUM_POLICY_RIGHTS_RESILIENCE_SCORE and market_result["eligibility"].get("status") not in {"rejected", "hold"}:
                market_result["eligibility"] = {"status": "hold", "reasons": [
                    f"Policy/rights resilience score below minimum {MINIMUM_POLICY_RIGHTS_RESILIENCE_SCORE:.0f}."]}
            if market_result["eligibility"].get("status") in {"rejected", "hold"}:
                market_result["decision"] = asdict(score_four_layers({}))
                market_result["decision"]["status"] = "hard_rejected" if market_result["eligibility"]["status"] == "rejected" else "on_hold"
                market_result["decision"]["rejection_reasons"] = list(market_result["eligibility"].get("reasons", []))
            market_result["ranking_eligible"] = (
                market_result["decision"]["status"] == "scored"
                and market_result["decision"]["coverage"] == 1.0
                and market_result["eligibility"].get("status") == "eligible"
            )
            if market_result["decision"]["status"] == "insufficient_evidence":
                market_result["limitations"].append("Four-layer decision withheld: one or more layers lack current, provenance-backed component evidence.")
            elif not market_result["ranking_eligible"] and market_result["decision"]["status"] == "scored":
                market_result["limitations"].append("Provisional score only: ranking requires all four evidence-qualified layers, source-verified market eligibility, and no unresolved hard gate.")
            results.append(market_result)

        scan_complete = not budget_limited and not trends_budget_limited
        ranked = rank_market_decisions(results) if scan_complete else []
        from .advanced_intelligence import audit_market_coverage
        coverage_attempts = []
        for item in results:
            youtube_status = item.get("youtube", {}).get("status", "not_configured")
            if youtube_status in {"ok", "partial"}:
                normalized_status = youtube_status
            elif youtube_status in {"skipped_quota_budget", "not_configured"}:
                normalized_status = "not_attempted"
            else:
                normalized_status = "failed"
            coverage_attempts.append({"market_id": item["market_id"], "status": normalized_status,
                "sample_count": int(item.get("youtube", {}).get("sample_size", 0) or 0),
                "error_code": item.get("youtube", {}).get("error_type")})
        market_coverage = audit_market_coverage([market.market_id for market in markets], coverage_attempts)
        return {
            "status": "partial_quota_limited" if not scan_complete else ("ok" if any(r["youtube"]["status"] in {"ok", "partial"} or r["google_trends"].get("status") == "ok" for r in results) else "insufficient_evidence"),
            "topic": topic, "market_count": len(results), "markets": results,
            "market_coverage": market_coverage,
            "registry": {"source": market_registry_source,
                         "country_count": len({market.country_code for market in markets}),
                         "market_profile_count": len(markets),
                         "market_ids": [market.market_id for market in markets]},
            "ranked_markets": ranked,
            "quota": {
                "search_bucket": {"estimated_calls": estimated_search_calls,
                                  "attempted_calls": attempted_search_calls,
                                  "budget_calls": search_call_budget,
                                  "daily_limit_calls": search_quota_limit,
                                  "calls_per_search_order": 1,
                                  "query_variant_limit_per_market": query_variant_limit},
                "general_bucket": {"estimated_units": estimated_other_units,
                                   "attempted_or_reserved_units": attempted_other_units,
                                   "budget_units": other_quota_budget_units,
                                   "daily_limit_units": other_quota_limit,
                                   "preconsumed_units": other_quota_preconsumed_units,
                                   "detail_call_reserve_per_market": 1,
                                   "i18n_regions_list_cost": 1},
                "trends_bucket": {"estimated_calls": len(markets) if self.trends_factory else 0,
                                  "attempted_calls": attempted_trends_calls,
                                  "budget_calls": trends_call_budget,
                                  "budget_limited": trends_budget_limited},
                "scan_complete": scan_complete},
            "decision_model": {"version": "v17-four-layer-1.1.0", "weights": dict(LAYER_WEIGHTS),
                "layers": ["audience_demand", "competitive_opening", "monetization_economics", "creator_execution_fit"],
                "components": LAYER_COMPONENTS, "minimum_component_coverage": 0.75,
                "minimum_layer_coverage_for_score": 0.75, "minimum_layer_coverage_for_ranking": 1.0,
                "required_components": {key: sorted(value) for key, value in REQUIRED_LAYER_COMPONENTS.items()},
                "minimum_policy_rights_resilience_score": MINIMUM_POLICY_RIGHTS_RESILIENCE_SCORE,
                "evidence_requirements": ["score (0-100)", "source_ref", "source_family", "timezone-aware observed_at", "confidence (0-1)", "method"],
                "rule": "No market is ranked by RPM/CPM alone; each layer requires at least 75% weighted component coverage, ranking requires all four layers plus source-verified market eligibility, and missing evidence is never neutral-filled."},
            "global_limitations": [
                "Country coverage is limited to the configured registry and provider-supported regions.",
                "Machine translation is a query-discovery aid, not proof of native or culturally natural copy; native review is always required.",
                "Google Trends indices are market-local relative values, not absolute search volume and not directly comparable across geographies.",
                "Competitor RPM is not public; actual creator RPM requires owner-authorized YouTube Analytics.",
                "Four-layer component scores require explicit, current, source-linked evidence; public search samples do not manufacture monetization or creator-fit scores.",
                "A quota-limited partial scan is not ranked, avoiding first-markets-first selection bias. Search.list uses a separate call-count bucket; videos.list and i18nRegions.list use the general daily-units bucket.",
                "Provisional scores with a missing decision layer are not ranked; creator language fluency requires native review, policy/rights resilience is a hard gate, and market eligibility must be source-verified.",
            ],
        }
