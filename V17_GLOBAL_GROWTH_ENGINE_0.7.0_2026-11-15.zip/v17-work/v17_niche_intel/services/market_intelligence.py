from __future__ import annotations

from datetime import datetime, timezone
from urllib.parse import urlparse
from typing import Any, Mapping

from ..domain.confidence import assess_confidence
from .channel_strategy import ChannelStrategyService
from .growth_intelligence import analyze_growth_bundle
from ..domain.business_feasibility import evaluate_channel_feasibility
from ..domain.enums import EvidenceStatus
from ..domain.market_intelligence import (
    analyze_seasonality, assess_freshness, benchmark_audio_metrics,
    benchmark_thumbnail_metadata, calculate_serp_volatility,
    classify_search_intent, cluster_topics, competitor_overlap,
    detect_cannibalization, extract_audience_pain_points, segment_market,
    validate_experiment, analyze_content_freshness,
)
from ..domain.models import Evidence


class MarketIntelligenceService:
    """Analyze supplied, provenance-bearing observations without filling data gaps."""

    def analyze(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        keywords = payload.get("keywords", [])
        intents = [{"keyword": keyword, "intent": classify_search_intent(keyword)} for keyword in keywords]
        content_plan = payload.get("content_plan", [])
        historical = payload.get("historical_snapshots", [])
        provenance = []
        evidence = []
        now = datetime.now(timezone.utc)
        for item in payload.get("evidence", []):
            observed = datetime.fromisoformat(str(item["observed_at"]).replace("Z", "+00:00"))
            status = EvidenceStatus(item.get("status", "ok"))
            record = Evidence(metric=item["metric"], value=item.get("value"),
                source_family=item["source_family"], observed_at=observed, status=status,
                quality=float(item.get("quality", 1.0)), source_ref=item.get("source_ref"),
                metadata=item.get("metadata", {}))
            evidence.append(record)
            provenance.append({"metric": record.metric, "source_family": record.source_family,
                "source_ref": record.source_ref, "status": str(record.status),
                "quality": record.quality, "observed_at": observed.isoformat(),
                "freshness": assess_freshness(observed, now=now)})
        confidence = assess_confidence(evidence, now=now)
        trend_rows = payload.get("trend_observations", [])
        market_rows = payload.get("market_observations", [])
        experiment = payload.get("experiment")
        serp_by_keyword = payload.get("serp_snapshots_by_keyword", {})
        serp_volatility_by_keyword = {keyword: calculate_serp_volatility([
            {"observed_at": snapshot["observed_at"],
             "results": [item.get("url") if isinstance(item, Mapping) else item for item in snapshot.get("results", [])]}
            for snapshot in snapshots]) for keyword, snapshots in serp_by_keyword.items()} if serp_by_keyword else {}
        if serp_volatility_by_keyword:
            serp_volatility = {"status": "ok" if any(item["status"] == "ok" for item in serp_volatility_by_keyword.values()) else "insufficient_data",
                               "by_keyword": serp_volatility_by_keyword}
        else:
            serp_volatility = calculate_serp_volatility(payload.get("serp_snapshots", []))
        keyword_channels = payload.get("keyword_channels")
        if keyword_channels is None:
            keyword_channels = {}
            result_sets = payload.get("serp_results_by_keyword", {})
            if not result_sets and serp_by_keyword:
                result_sets = {keyword: snapshots[-1].get("results", []) for keyword, snapshots in serp_by_keyword.items() if snapshots}
            for keyword, results in result_sets.items():
                competitors = []
                for item in results:
                    url = item.get("url") if isinstance(item, Mapping) else item
                    parsed = urlparse(str(url))
                    host = (parsed.hostname or "").lower().removeprefix("www.")
                    path_parts = [part for part in parsed.path.split("/") if part]
                    if host.endswith("youtube.com") and path_parts and (path_parts[0].startswith("@") or path_parts[0] in {"channel", "user", "c"}):
                        identity = host + "/" + "/".join(path_parts[:2])
                    else:
                        identity = host
                    if identity: competitors.append(identity)
                keyword_channels[keyword] = competitors
        from ..providers.media_quality import measure_audio_file, measure_thumbnail_file
        thumbnail_samples = list(payload.get("thumbnail_samples", []))
        thumbnail_samples.extend(measure_thumbnail_file(path) for path in payload.get("thumbnail_files", []))
        audio_samples = list(payload.get("audio_samples", []))
        audio_samples.extend(measure_audio_file(path) for path in payload.get("audio_files", []))
        channel_constraints = payload.get("channel_constraints")
        return {
            "business_feasibility": evaluate_channel_feasibility(channel_constraints) if channel_constraints is not None else {"status": "not_configured", "business_feasibility_score": None, "risk_resilience_score": None},
            "channel_strategy": ChannelStrategyService().build(payload["channel_strategy"]) if payload.get("channel_strategy") is not None else {"status": "not_configured", "positioning": None, "opportunity_map": [], "content_pillars": []},
            "growth_diagnostics": analyze_growth_bundle(payload["growth_audit"]) if payload.get("growth_audit") is not None else {"status": "not_configured"},
            "search_intents": intents,
            "topic_clusters": cluster_topics(keywords) if keywords else [],
            "competitor_overlap": competitor_overlap(keyword_channels),
            "serp_volatility": serp_volatility,
            "cannibalization": detect_cannibalization(content_plan),
            "seasonality": analyze_seasonality(trend_rows),
            "market_segmentation": segment_market(market_rows),
            "thumbnail_benchmark": benchmark_thumbnail_metadata(thumbnail_samples),
            "audio_benchmark": benchmark_audio_metrics(audio_samples),
            "audience_pain_points": extract_audience_pain_points(payload.get("audience_texts", [])),
            "historical_tracking": self._history(historical),
            "content_freshness": analyze_content_freshness(payload.get("video_publications", [])),
            "experiment_validation": validate_experiment(**experiment) if experiment else {"status": "not_configured"},
            "data_provenance": provenance,
            "confidence": {"level": str(confidence.level), "independent_source_count": confidence.independent_source_count,
                "quality_index": confidence.quality_index, "source_families": list(confidence.source_families)},
            "analysis_timestamp": now.isoformat(),
            "limitations": [
                "Intent and clustering are deterministic heuristics; validate against actual SERPs.",
                "Thumbnail metadata is descriptive and does not establish CTR or causal performance.",
                "Audio metrics require measured source audio; they do not replace listening tests.",
                "One year of monthly observations does not confirm recurring seasonality.",
                "Experiment intervals are approximate and do not establish causality without randomized design.",
                "Cross-country comparison is withheld when source normalization is not comparable.",
            ],
        }

    @staticmethod
    def _history(snapshots: list[Mapping[str, Any]]) -> dict[str, Any]:
        grouped: dict[str, list[Mapping[str, Any]]] = {}
        for row in snapshots:
            grouped.setdefault(str(row["video_id"]), []).append(row)
        results = []
        for video_id, rows in sorted(grouped.items()):
            ordered = sorted(rows, key=lambda row: row["observed_at"])
            if len(ordered) < 2:
                continue
            first, last = ordered[0], ordered[-1]
            start = datetime.fromisoformat(str(first["observed_at"]).replace("Z", "+00:00"))
            end = datetime.fromisoformat(str(last["observed_at"]).replace("Z", "+00:00"))
            elapsed = (end - start).total_seconds() / 86400
            if elapsed <= 0 or first.get("views") is None or last.get("views") is None:
                continue
            delta = int(last["views"]) - int(first["views"])
            results.append({"video_id": video_id, "snapshot_count": len(rows),
                "interval_days": round(elapsed, 4), "view_delta": delta,
                "views_per_day": round(delta / elapsed, 4), "observed_interval_only": True})
        return {"status": "ok" if results else "insufficient_data",
                "videos_with_growth_measurement": len(results), "video_growth": results,
                "note": "Growth is calculated only from repeated timestamped observations of the same video."}
