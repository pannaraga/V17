"""Bounded, manually invoked worker for persisted V17 jobs.

Handlers are injected by the owning application. The runner never imports or
executes code named by job payloads and processes at most one job per call.
"""
from __future__ import annotations

from typing import Any, Callable, Mapping

from ..storage.repositories import JobCheckpointRepository

JobHandler = Callable[[dict[str, Any], dict[str, Any], Callable[[dict[str, Any]], None]], Mapping[str, Any] | None]


class PersistentJobRunner:
    """Claim and process one allowlisted handler with lease-backed checkpoints."""

    def __init__(self, repository: JobCheckpointRepository,
                 handlers: Mapping[str, JobHandler], *, lease_seconds: int = 300):
        if not isinstance(handlers, Mapping):
            raise ValueError("handlers must be a mapping")
        if isinstance(lease_seconds, bool) or not isinstance(lease_seconds, int) or not 5 <= lease_seconds <= 3600:
            raise ValueError("lease_seconds must be between 5 and 3600")
        self.repository = repository
        self.handlers = dict(handlers)
        self.lease_seconds = lease_seconds

    def run_once(self, *, worker_id: str) -> dict[str, Any]:
        job = self.repository.claim_next(worker_id=worker_id, lease_seconds=self.lease_seconds)
        if job is None:
            return {"status": "idle", "processed": False}
        job_id = job["job_id"]
        handler = self.handlers.get(job["job_type"])
        if handler is None:
            self.repository.transition(job_id, "failed", error="handler_not_registered", worker_id=worker_id)
            return {"status": "failed", "processed": True, "job_id": job_id,
                    "error": "handler_not_registered"}

        def save_checkpoint(checkpoint: dict[str, Any]) -> None:
            saved = self.repository.save_checkpoint(job_id, checkpoint, worker_id=worker_id,
                lease_seconds=self.lease_seconds)
            if not saved:
                raise RuntimeError("job_lease_lost_before_checkpoint")

        try:
            result = handler(job["config"], job["checkpoint"], save_checkpoint)
            if result is not None and not isinstance(result, Mapping):
                raise ValueError("job handler must return an object or None")
            result = dict(result or {})
            if "checkpoint" in result:
                save_checkpoint(result["checkpoint"])
            next_state = result.get("status", "completed")
            if next_state not in {"completed", "paused"}:
                raise ValueError("job handler status must be completed or paused")
            self.repository.transition(job_id, next_state, worker_id=worker_id)
            return {"status": next_state, "processed": True, "job_id": job_id,
                    "checkpoint_saved": "checkpoint" in result}
        except Exception as exc:
            error = type(exc).__name__
            try:
                self.repository.transition(job_id, "failed", error=error, worker_id=worker_id)
            except ValueError:
                # Lease ownership may have changed; do not overwrite the new owner's state.
                return {"status": "lease_lost", "processed": True, "job_id": job_id}
            return {"status": "failed", "processed": True, "job_id": job_id,
                    "error_type": type(exc).__name__}


    def run_batch(self, *, worker_id: str, max_jobs: int = 10) -> dict[str, Any]:
        """Process a bounded batch until idle; host scheduler owns recurring invocation."""
        if isinstance(max_jobs, bool) or not isinstance(max_jobs, int) or not 1 <= max_jobs <= 100:
            raise ValueError("max_jobs must be an integer from 1 to 100")
        results = []
        for _ in range(max_jobs):
            result = self.run_once(worker_id=worker_id)
            if result.get("status") == "idle":
                break
            results.append(result)
        return {"status": "idle" if not results else "batch_processed",
                "processed_count": len(results), "max_jobs": max_jobs,
                "results": results, "recurring_schedule": "not_configured_host_scheduler_required"}
