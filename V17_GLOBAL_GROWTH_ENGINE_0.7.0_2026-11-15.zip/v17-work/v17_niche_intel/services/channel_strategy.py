"""Evidence-linked channel foundation planning.

This service converts operator-defined positioning inputs and referenced public
observations into a reviewable strategy draft. It deliberately does not predict
views, revenue, subscriber growth, or market opportunity scores.
"""
from __future__ import annotations

from typing import Any, Mapping

_REQUIRED = ("niche", "target_audience", "audience_problem", "desired_outcome", "unique_method")
_IMPACT_ORDER = {"high": 0, "medium": 1, "low": 2}
_FREQUENCY_ORDER = {"high": 0, "medium": 1, "low": 2, "unknown": 3}


def _clean_text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty string")
    return value.strip()


def _evidence_refs(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return sorted({item.strip() for item in value if isinstance(item, str) and item.strip()})


class ChannelStrategyService:
    """Build a channel foundation from explicit inputs and traceable evidence."""

    def build(self, brief: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(brief, Mapping):
            raise TypeError("channel strategy brief must be an object")
        missing = [key for key in _REQUIRED if not isinstance(brief.get(key), str) or not brief[key].strip()]
        if missing:
            return {
                "status": "insufficient_inputs",
                "missing_inputs": missing,
                "positioning": None,
                "opportunity_map": [],
                "content_pillars": [],
                "excluded_claims": 0,
                "scores": {"opportunity_score": None, "growth_forecast": None},
                "limitations": ["No positioning is generated until all required channel-foundation inputs are supplied."],
            }

        niche = _clean_text(brief["niche"], "niche")
        audience = _clean_text(brief["target_audience"], "target_audience")
        problem = _clean_text(brief["audience_problem"], "audience_problem")
        outcome = _clean_text(brief["desired_outcome"], "desired_outcome")
        method = _clean_text(brief["unique_method"], "unique_method")
        advantages = brief.get("creator_advantages", [])
        if not isinstance(advantages, list) or any(not isinstance(x, str) or not x.strip() for x in advantages):
            raise ValueError("creator_advantages must be a list of non-empty strings")
        competitor_gaps = brief.get("competitor_gaps", [])
        audience_signals = brief.get("audience_signals", [])
        if not isinstance(competitor_gaps, list):
            raise ValueError("competitor_gaps must be a list")
        if not isinstance(audience_signals, list):
            raise ValueError("audience_signals must be a list")

        opportunity_map: list[dict[str, Any]] = []
        excluded_claims = 0
        source_families: set[str] = set()
        for item in competitor_gaps:
            if not isinstance(item, Mapping):
                excluded_claims += 1
                continue
            impact = str(item.get("audience_impact", "unknown")).lower()
            if impact not in _IMPACT_ORDER:
                raise ValueError("audience_impact must be high, medium, or low")
            refs = _evidence_refs(item.get("evidence_refs"))
            family = item.get("source_family")
            gap = item.get("gap")
            competitor = item.get("competitor_id")
            if not refs or not isinstance(family, str) or not family.strip() or not isinstance(gap, str) or not gap.strip() or not isinstance(competitor, str) or not competitor.strip():
                excluded_claims += 1
                continue
            source_families.add(family.strip())
            opportunity_map.append({
                "competitor_id": competitor.strip(),
                "observed_gap": gap.strip(),
                "audience_impact": impact,
                "priority": impact,
                "source_family": family.strip(),
                "evidence_refs": refs,
                "interpretation": "Potential differentiation hypothesis; validate against the linked source material and audience response.",
            })
        opportunity_map.sort(key=lambda row: (_IMPACT_ORDER[row["priority"]], row["competitor_id"], row["observed_gap"].casefold()))

        content_pillars: list[dict[str, Any]] = []
        for item in audience_signals:
            if not isinstance(item, Mapping):
                continue
            refs = _evidence_refs(item.get("evidence_refs"))
            family = item.get("source_family")
            signal_problem = item.get("problem")
            frequency = str(item.get("frequency", "unknown")).lower()
            if frequency not in _FREQUENCY_ORDER:
                raise ValueError("audience signal frequency must be high, medium, low, or unknown")
            if not refs or not isinstance(family, str) or not family.strip() or not isinstance(signal_problem, str) or not signal_problem.strip():
                continue
            source_families.add(family.strip())
            content_pillars.append({
                "name": signal_problem.strip().capitalize(),
                "audience_problem": signal_problem.strip(),
                "priority": frequency,
                "series_format": "problem-to-solution demonstration",
                "editorial_rule": "Show the problem, explain the decision, demonstrate the method, and state the limitations.",
                "source_family": family.strip(),
                "evidence_refs": refs,
            })
        content_pillars.sort(key=lambda row: (_FREQUENCY_ORDER[row["priority"]], row["audience_problem"].casefold()))

        positioning = {
            "statement": f"For {audience} who {problem}, this channel helps them {outcome} through {method}.",
            "category": niche,
            "target_audience": audience,
            "core_problem": problem,
            "promised_outcome": outcome,
            "differentiated_method": method,
            "creator_advantages": [item.strip() for item in advantages],
            "status": "proposed_not_validated",
        }
        status = "ready_for_validation" if opportunity_map and content_pillars else "needs_more_evidence"
        return {
            "status": status,
            "positioning": positioning,
            "opportunity_map": opportunity_map,
            "content_pillars": content_pillars,
            "excluded_claims": excluded_claims,
            "evidence_quality": {
                "distinct_source_families": len(source_families),
                "source_families": sorted(source_families),
                "competitor_gaps_with_references": len(opportunity_map),
                "audience_signals_with_references": len(content_pillars),
            },
            "launch_sequence": [
                {"phase": "Validate the audience", "action": "Check the target audience and core problem against current search results and representative audience comments."},
                {"phase": "Prove the differentiated method", "action": "Produce a small pilot series that demonstrates the method against the documented competitor gaps."},
                {"phase": "Establish a repeatable format", "action": "Use the strongest evidence-backed audience problems as recurring editorial pillars; review production capacity before fixing cadence."},
                {"phase": "Learn and refine", "action": "Use owner-authorized Analytics to review impressions, click-through rate, retention, returning viewers, and audience feedback; log each change as an experiment."},
            ],
            "measurement_contract": {
                "discovery": ["impressions", "search traffic", "unique viewers"],
                "packaging": ["impressions click-through rate"],
                "satisfaction": ["average view duration", "audience retention", "returning viewers"],
                "guardrails": ["production hours per video", "publishing reliability", "copyright and reused-content review"],
                "note": "Metrics require owner-authorized first-party Analytics; competitor public data cannot substitute for private channel retention or CTR.",
            },
            "scores": {"opportunity_score": None, "growth_forecast": None},
            "limitations": [
                "Competitor weaknesses are hypotheses until each cited source is reviewed in context.",
                "Audience signal frequency is an operator-supplied label, not a statistically estimated population rate.",
                "Positioning is a strategic proposal and must be validated with real viewers and channel performance.",
                "No view, subscriber, revenue, monetization, or growth forecast is generated.",
            ],
        }
