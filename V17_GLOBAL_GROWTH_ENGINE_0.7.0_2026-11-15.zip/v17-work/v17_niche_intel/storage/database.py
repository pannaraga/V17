from __future__ import annotations
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from zoneinfo import ZoneInfo
from typing import Iterator

_SCHEMA = """
CREATE TABLE IF NOT EXISTS research_runs (
 id TEXT PRIMARY KEY, topic TEXT NOT NULL CHECK(length(trim(topic)) > 0),
 mode TEXT NOT NULL CHECK(mode IN ('market_entry','existing_channel','both')),
 country_code TEXT, algorithm_version TEXT NOT NULL, config_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS source_observations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 run_id TEXT NOT NULL REFERENCES research_runs(id) ON DELETE CASCADE,
 observation_key TEXT NOT NULL UNIQUE, metric TEXT NOT NULL, value_json TEXT,
 source_family TEXT NOT NULL, observed_at TEXT NOT NULL, status TEXT NOT NULL,
 quality REAL NOT NULL CHECK(quality >= 0 AND quality <= 1), source_ref TEXT, metadata_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_observations_run_metric ON source_observations(run_id, metric, observed_at);
CREATE TABLE IF NOT EXISTS api_credentials (
 credential_id TEXT PRIMARY KEY, provider TEXT NOT NULL, project_id TEXT NOT NULL,
 use_case TEXT NOT NULL, environment TEXT NOT NULL, secret_ref TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('active','invalid','disabled','reauth_required')),
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_api_credentials_route ON api_credentials(provider,use_case,environment,project_id,status);
CREATE TABLE IF NOT EXISTS project_quota (
 project_id TEXT NOT NULL, use_case TEXT NOT NULL, used INTEGER NOT NULL CHECK(used >= 0),
 quota_limit INTEGER NOT NULL CHECK(quota_limit > 0), updated_at TEXT NOT NULL,
 PRIMARY KEY(project_id,use_case)
);
CREATE TABLE IF NOT EXISTS research_results (
 run_id TEXT PRIMARY KEY REFERENCES research_runs(id) ON DELETE CASCADE,
 result_json TEXT NOT NULL, saved_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS job_checkpoints (
 job_id TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE, job_type TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('pending','running','paused','completed','failed')),
 config_json TEXT NOT NULL, checkpoint_json TEXT NOT NULL DEFAULT '{}',
 attempt_count INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0),
 worker_id TEXT, lease_expires_at TEXT, error_text TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_job_checkpoints_status_updated ON job_checkpoints(status,updated_at);
CREATE TABLE IF NOT EXISTS video_snapshots (
 id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL REFERENCES research_runs(id) ON DELETE CASCADE,
 video_id TEXT NOT NULL, observed_at TEXT NOT NULL, views INTEGER, likes INTEGER, comments INTEGER,
 UNIQUE(run_id,video_id,observed_at)
);
CREATE TABLE IF NOT EXISTS serp_snapshots (
 id INTEGER PRIMARY KEY AUTOINCREMENT, keyword TEXT NOT NULL, country TEXT NOT NULL,
 language TEXT, observed_at TEXT NOT NULL, results_json TEXT NOT NULL, source TEXT NOT NULL,
 UNIQUE(keyword,country,observed_at)
);
CREATE INDEX IF NOT EXISTS idx_video_snapshots_video_time ON video_snapshots(video_id,observed_at);
CREATE TABLE IF NOT EXISTS channel_analytics_private (
 id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT REFERENCES research_runs(id) ON DELETE SET NULL,
 channel_id TEXT NOT NULL, video_id TEXT NOT NULL, report_date TEXT NOT NULL,
 metrics_json TEXT NOT NULL, imported_at TEXT NOT NULL, provenance_json TEXT NOT NULL DEFAULT '{}',
 UNIQUE(channel_id,video_id,report_date)
);
CREATE TABLE IF NOT EXISTS channel_analytics_daily_private (
 id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id TEXT NOT NULL, report_date TEXT NOT NULL,
 metrics_json TEXT NOT NULL, imported_at TEXT NOT NULL, provenance_json TEXT NOT NULL DEFAULT '{}', UNIQUE(channel_id,report_date)
);
CREATE TABLE IF NOT EXISTS channel_analytics_country_private (
 id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id TEXT NOT NULL, country_code TEXT NOT NULL,
 start_date TEXT NOT NULL, end_date TEXT NOT NULL, currency TEXT NOT NULL,
 views REAL NOT NULL CHECK(views >= 0), estimated_revenue REAL NOT NULL CHECK(estimated_revenue >= 0),
 rpm REAL, imported_at TEXT NOT NULL, provenance_json TEXT NOT NULL DEFAULT '{}',
 UNIQUE(channel_id,country_code,start_date,end_date,currency)
);
CREATE INDEX IF NOT EXISTS idx_channel_analytics_country_private_lookup
 ON channel_analytics_country_private(channel_id,start_date,end_date);
CREATE TABLE IF NOT EXISTS project_quota_daily (
 project_id TEXT NOT NULL, quota_date TEXT NOT NULL,
 used INTEGER NOT NULL CHECK(used >= 0), quota_limit INTEGER NOT NULL CHECK(quota_limit > 0), updated_at TEXT NOT NULL,
 PRIMARY KEY(project_id,quota_date)
);
CREATE TABLE IF NOT EXISTS project_search_quota_daily (
 project_id TEXT NOT NULL, quota_date TEXT NOT NULL,
 used INTEGER NOT NULL CHECK(used >= 0), quota_limit INTEGER NOT NULL CHECK(quota_limit > 0), updated_at TEXT NOT NULL,
 PRIMARY KEY(project_id,quota_date)
);
CREATE TABLE IF NOT EXISTS experiment_registry (
 experiment_id TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE,
 objective TEXT NOT NULL, primary_metric TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('planned','running','paused','completed','failed','cancelled')),
 config_json TEXT NOT NULL, result_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_experiment_registry_status ON experiment_registry(status,updated_at);
CREATE TABLE IF NOT EXISTS decision_log (
 decision_id TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE,
 topic TEXT NOT NULL, recommendation TEXT NOT NULL, evidence_refs_json TEXT NOT NULL,
 expected_metric TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('proposed','accepted','rejected','implemented','validated')),
 outcome_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_decision_log_topic_status ON decision_log(topic,status,updated_at);
CREATE TABLE IF NOT EXISTS oauth_accounts (
 account_id TEXT PRIMARY KEY, provider TEXT NOT NULL, account_label TEXT NOT NULL,
 access_token_ref TEXT NOT NULL, refresh_token_ref TEXT NOT NULL, client_secret_ref TEXT,
 scopes_json TEXT NOT NULL, channel_ids_json TEXT NOT NULL, client_id TEXT,
 status TEXT NOT NULL CHECK(status IN ('active','invalid','disabled','revoked','reauth_required')),
 expires_at TEXT, created_at TEXT NOT NULL
);
"""

class Database:
    """SQLite unit-of-work boundary for local reproducible research."""
    def __init__(self, path: str | Path = "v17_niche_intel.sqlite3") -> None:
        self.path = str(path)
        self._lock = RLock()
        if self.path != ":memory:":
            Path(self.path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA foreign_keys = ON")
        existing_tables = {row[0] for row in self._connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        search_bucket_existed = "project_search_quota_daily" in existing_tables
        if self.path != ":memory:":
            self._connection.execute("PRAGMA journal_mode = WAL")
            self._connection.execute("PRAGMA synchronous = NORMAL")
        self._connection.executescript(_SCHEMA)
        experiment_columns = {row[1] for row in self._connection.execute("PRAGMA table_info(experiment_registry)")}
        if "result_json" not in experiment_columns:
            self._connection.execute("ALTER TABLE experiment_registry ADD COLUMN result_json TEXT NOT NULL DEFAULT '{}'")
        job_columns = {row[1] for row in self._connection.execute("PRAGMA table_info(job_checkpoints)")}
        if "worker_id" not in job_columns:
            self._connection.execute("ALTER TABLE job_checkpoints ADD COLUMN worker_id TEXT")
        if "lease_expires_at" not in job_columns:
            self._connection.execute("ALTER TABLE job_checkpoints ADD COLUMN lease_expires_at TEXT")
        # Additive migrations keep databases created by earlier V17 phases usable.
        oauth_columns={row[1] for row in self._connection.execute("PRAGMA table_info(oauth_accounts)")}
        if "client_secret_ref" not in oauth_columns:
            self._connection.execute("ALTER TABLE oauth_accounts ADD COLUMN client_secret_ref TEXT")
        if "client_id" not in oauth_columns:
            self._connection.execute("ALTER TABLE oauth_accounts ADD COLUMN client_id TEXT")
        for table in ("channel_analytics_private", "channel_analytics_daily_private", "channel_analytics_country_private"):
            columns = {row[1] for row in self._connection.execute(f"PRAGMA table_info({table})")}
            if "provenance_json" not in columns:
                self._connection.execute(f"ALTER TABLE {table} ADD COLUMN provenance_json TEXT NOT NULL DEFAULT '{{}}'")
        quota_columns = {row[1] for row in self._connection.execute("PRAGMA table_info(project_quota_daily)")}
        if "use_case" in quota_columns:
            # Older V17 builds tracked quota per use case, which can overstate a
            # project's real quota. Consolidate usage across all routes per project/day.
            self._connection.execute("ALTER TABLE project_quota_daily RENAME TO project_quota_daily_legacy")
            self._connection.execute("""CREATE TABLE project_quota_daily (
                project_id TEXT NOT NULL, quota_date TEXT NOT NULL,
                used INTEGER NOT NULL CHECK(used >= 0), quota_limit INTEGER NOT NULL CHECK(quota_limit > 0),
                updated_at TEXT NOT NULL, PRIMARY KEY(project_id,quota_date))""")
            self._connection.execute("""INSERT INTO project_quota_daily(project_id,quota_date,used,quota_limit,updated_at)
                SELECT project_id,quota_date,SUM(used),MIN(quota_limit),MAX(updated_at)
                FROM project_quota_daily_legacy GROUP BY project_id,quota_date""")
            self._connection.execute("DROP TABLE project_quota_daily_legacy")
        if not search_bucket_existed:
            # Legacy quota dates were UTC; current YouTube buckets reset at midnight PT.
            # Move each aggregate row using its last update timestamp before splitting buckets.
            legacy_rows = self._connection.execute(
                "SELECT project_id,quota_date,used,quota_limit,updated_at FROM project_quota_daily").fetchall()
            migrated: dict[tuple[str, str], dict[str, object]] = {}
            for row in legacy_rows:
                try:
                    observed = datetime.fromisoformat(str(row["updated_at"]).replace("Z", "+00:00"))
                    if observed.tzinfo is None:
                        observed = observed.replace(tzinfo=timezone.utc)
                    local_date = observed.astimezone(ZoneInfo("America/Los_Angeles")).date().isoformat()
                except (TypeError, ValueError):
                    local_date = str(row["quota_date"])
                key = (str(row["project_id"]), local_date)
                bucket = migrated.setdefault(key, {"used": 0, "quota_limit": int(row["quota_limit"]),
                                                    "updated_at": str(row["updated_at"])})
                bucket["used"] = int(bucket["used"]) + int(row["used"])
                bucket["quota_limit"] = min(int(bucket["quota_limit"]), int(row["quota_limit"]))
                bucket["updated_at"] = max(str(bucket["updated_at"]), str(row["updated_at"]))
            self._connection.execute("DELETE FROM project_quota_daily")
            for (project_id, quota_date), values in migrated.items():
                self._connection.execute("INSERT INTO project_quota_daily VALUES (?,?,?,?,?)",
                    (project_id, quota_date, values["used"], values["quota_limit"], values["updated_at"]))
            # Older V17 releases charged search.list at 100 general-bucket units.
            # We cannot disaggregate mixed historical usage, so seed a conservative
            # search-call estimate while retaining the old general usage (safe overcount).
            self._connection.execute("""INSERT OR IGNORE INTO project_search_quota_daily
                (project_id,quota_date,used,quota_limit,updated_at)
                SELECT project_id,quota_date,MIN(100,CAST(used / 100 AS INTEGER)),100,updated_at
                FROM project_quota_daily WHERE used >= 100""")

    @property
    def connection(self) -> sqlite3.Connection:
        return self._connection

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            yield self._connection

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                yield self._connection
            except Exception:
                self._connection.rollback()
                raise
            else:
                self._connection.commit()

    def close(self) -> None:
        with self._lock:
            self._connection.close()
