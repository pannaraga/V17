"""Theme tokens and responsive styling for the V17 Streamlit workspace."""
from __future__ import annotations

from string import Template

_LIGHT = {
    "canvas": "#F4F5F1", "surface": "#FFFFFF", "elevated": "#FFFFFF",
    "text": "#17232B", "muted": "#64727A", "border": "#DCE3DF",
    "primary": "#176B62", "primary_text": "#FFFFFF", "accent": "#C6E86B",
    "danger": "#B74747", "warning": "#9B681A", "focus": "#176B62", "shadow": "0 12px 34px rgba(23, 35, 43, .07)",
}
_DARK = {
    "canvas": "#101719", "surface": "#182326", "elevated": "#202E31",
    "text": "#EAF1EE", "muted": "#A1B2AD", "border": "#304144",
    "primary": "#78CFC0", "primary_text": "#10201D", "accent": "#C6E86B",
    "danger": "#FF8989", "warning": "#E7BD70", "focus": "#C6E86B", "shadow": "0 14px 40px rgba(0, 0, 0, .22)",
}

_CSS = Template(r"""
<style>
:root { color-scheme: $color_scheme; }
:root, :root[data-v17-theme="$theme"] {
  --v17-canvas: $canvas; --v17-surface: $surface; --v17-elevated: $elevated;
  --v17-text: $text; --v17-muted: $muted; --v17-border: $border;
  --v17-primary: $primary; --v17-primary-text: $primary_text; --v17-accent: $accent;
  --v17-danger: $danger; --v17-warning: $warning; --v17-focus: $focus; --v17-shadow: $shadow;
}
$system_dark
html, body, [data-testid="stAppViewContainer"] { background: var(--v17-canvas); color: var(--v17-text); }
[data-testid="stHeader"] { background: transparent; }
[data-testid="stToolbar"] { right: 1rem; }
[data-testid="stSidebar"] { background: var(--v17-surface); border-right: 1px solid var(--v17-border); }
[data-testid="stSidebar"] > div:first-child { padding-top: 1.2rem; }
.block-container { max-width: 1480px; padding-top: 2rem; padding-bottom: 3rem; }
[data-testid="stVerticalBlock"] { gap: .9rem; }
[data-testid="stMetric"] { background: var(--v17-surface); border: 1px solid var(--v17-border); border-radius: 16px; padding: 1rem 1.1rem; box-shadow: var(--v17-shadow); }
[data-testid="stMetricLabel"] { color: var(--v17-muted); font-size: .78rem; letter-spacing: .045em; text-transform: uppercase; }
[data-testid="stMetricValue"] { color: var(--v17-text); font-weight: 720; letter-spacing: -.045em; }
[data-testid="stTabs"] [role="tablist"] { gap: .35rem; border-bottom: 1px solid var(--v17-border); }
[data-testid="stTabs"] button[role="tab"] { border-radius: 10px 10px 0 0; padding: .75rem 1rem; color: var(--v17-muted); }
[data-testid="stTabs"] button[role="tab"][aria-selected="true"] { color: var(--v17-primary); border-bottom: 2px solid var(--v17-primary); background: color-mix(in srgb, var(--v17-primary) 8%, transparent); }
[data-testid="stExpander"] { border: 1px solid var(--v17-border); border-radius: 14px; background: var(--v17-surface); }
[data-testid="stForm"] { border: 1px solid var(--v17-border); border-radius: 14px; background: var(--v17-surface); padding: 1rem; }
[data-testid="stTextInput"] input, [data-testid="stTextArea"] textarea, [data-testid="stNumberInput"] input, [data-testid="stDateInput"] input {
  background: var(--v17-elevated); color: var(--v17-text); border-color: var(--v17-border); border-radius: 10px;
}
[data-testid="stSelectbox"] [data-baseweb="select"] > div { background: var(--v17-elevated); border-color: var(--v17-border); border-radius: 10px; }
[data-testid="stButton"] button, [data-testid="stFormSubmitButton"] button { border-radius: 10px; min-height: 2.7rem; font-weight: 650; transition: transform .16s ease, box-shadow .16s ease, border-color .16s ease; }
[data-testid="stButton"] button[kind="primary"], [data-testid="stFormSubmitButton"] button[kind="primary"] { background: var(--v17-primary); color: var(--v17-primary-text); border: 1px solid var(--v17-primary); }
[data-testid="stButton"] button:hover, [data-testid="stFormSubmitButton"] button:hover { transform: translateY(-1px); box-shadow: var(--v17-shadow); }
[data-testid="stDataFrame"], [data-testid="stTable"] { border: 1px solid var(--v17-border); border-radius: 12px; overflow: hidden; }
[data-testid="stAlert"] { border-radius: 12px; }
[data-testid="stMarkdownContainer"] code { border-radius: 6px; }
.v17-eyebrow { color: var(--v17-primary); font-size: .72rem; font-weight: 750; letter-spacing: .16em; text-transform: uppercase; }
.v17-hero { position: relative; overflow: hidden; padding: clamp(1.25rem, 3vw, 2.2rem); border: 1px solid var(--v17-border); border-radius: 22px; background: linear-gradient(125deg, var(--v17-surface) 0%, var(--v17-elevated) 100%); box-shadow: var(--v17-shadow); }
.v17-hero:after { content: ""; position: absolute; width: 220px; height: 220px; right: -80px; top: -110px; border-radius: 50%; border: 1px solid color-mix(in srgb, var(--v17-primary) 35%, transparent); box-shadow: 0 0 0 22px color-mix(in srgb, var(--v17-primary) 5%, transparent), 0 0 0 44px color-mix(in srgb, var(--v17-primary) 3%, transparent); pointer-events: none; }
.v17-hero h1 { color: var(--v17-text); font-size: clamp(1.8rem, 4vw, 3.1rem); line-height: 1.05; letter-spacing: -.055em; font-weight: 760; margin: .45rem 0 .7rem; }
.v17-hero p { color: var(--v17-muted); max-width: 720px; font-size: 1rem; line-height: 1.65; margin: 0; }
.v17-section-kicker { color: var(--v17-muted); font-size: .72rem; font-weight: 750; letter-spacing: .13em; text-transform: uppercase; }
.v17-note { border-left: 3px solid var(--v17-primary); background: color-mix(in srgb, var(--v17-primary) 7%, var(--v17-surface)); padding: .75rem 1rem; border-radius: 0 10px 10px 0; color: var(--v17-muted); }
.v17-divider { height: 1px; background: var(--v17-border); margin: .6rem 0 1rem; }
:focus-visible { outline: 3px solid var(--v17-focus) !important; outline-offset: 3px !important; }
@media (max-width: 768px) {
  .block-container { padding: 1rem .8rem 2rem; }
  [data-testid="stTabs"] [role="tablist"] { overflow-x: auto; flex-wrap: nowrap; }
  [data-testid="stTabs"] button[role="tab"] { white-space: nowrap; padding: .65rem .75rem; }
  [data-testid="stMetric"] { padding: .8rem; }
  .v17-hero { border-radius: 16px; }
  [data-testid="stSidebar"] { min-width: min(88vw, 360px); }
}
@media (max-width: 480px) {
  [data-testid="stHorizontalBlock"] { flex-wrap: wrap; }
  [data-testid="stHorizontalBlock"] > [data-testid="column"] { min-width: 100% !important; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { scroll-behavior: auto !important; animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; }
}
</style>
""")


def build_theme_css(theme: str = "system") -> str:
    """Return self-contained CSS for light, dark, or OS-following appearance."""
    selected = str(theme).strip().lower()
    if selected not in {"light", "dark", "system"}:
        raise ValueError(f"Unsupported theme: {theme}")
    palette = _DARK if selected == "dark" else _LIGHT
    if selected == "system":
        system_dark = """@media (prefers-color-scheme: dark) { :root { color-scheme: dark;
          --v17-canvas: #101719; --v17-surface: #182326; --v17-elevated: #202E31;
          --v17-text:#EAF1EE; --v17-muted:#A1B2AD; --v17-border:#304144;
          --v17-primary:#78CFC0; --v17-primary-text:#10201D; --v17-accent:#C6E86B;
          --v17-danger:#FF8989; --v17-warning:#E7BD70; --v17-focus: #C6E86B; --v17-shadow:0 14px 40px rgba(0,0,0,.22);
        } }"""
    else:
        system_dark = ""
    return _CSS.substitute(
        theme=selected,
        color_scheme="light dark" if selected == "system" else selected,
        system_dark=system_dark,
        **palette,
    )
