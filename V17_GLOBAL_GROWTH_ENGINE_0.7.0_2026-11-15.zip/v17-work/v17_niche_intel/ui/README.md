# UI layer

`theme.py` owns the Signal Atelier semantic color tokens and responsive CSS used by the Streamlit dashboard. It has no Streamlit dependency so theme rendering rules can be unit-tested without launching the dashboard.

Supported themes:
- `light`: porcelain canvas, white surfaces, ink text, mineral teal actions.
- `dark`: midnight graphite canvas, layered slate surfaces, soft mint actions.
- `system`: light defaults with `prefers-color-scheme: dark` overrides.

The dashboard owns navigation and interaction state; this module owns appearance only. Keep research/provider/business logic out of the UI theme layer.
