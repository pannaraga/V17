from __future__ import annotations
from dataclasses import dataclass
from ipaddress import ip_address
from urllib.parse import urlsplit
from typing import Any

class ScrapePolicyError(ValueError): pass

@dataclass(frozen=True, slots=True)
class ScrapeResult:
    url: str
    markdown: str
    status_code: int | None
    metadata: dict[str, Any]


def _validate_public_url(url: str) -> None:
    parsed=urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ScrapePolicyError("Only credential-free public HTTPS URLs are allowed")
    if parsed.port not in (None, 443):
        raise ScrapePolicyError("Only the standard HTTPS port is allowed")
    host=parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".localhost", ".local", ".internal")):
        raise ScrapePolicyError("Local and internal targets are not allowed")
    try:
        ip=ip_address(host)
    except ValueError:
        ip=None
    if ip is not None and not ip.is_global:
        raise ScrapePolicyError("Non-public IP targets are not allowed")

class IncognitoScraper:
    """Privacy-first adapter. Inject a Firecrawl-compatible client; no cookies/profile are ever reused."""
    def __init__(self, client: Any, *, max_age_seconds: int = 0) -> None:
        if max_age_seconds < 0: raise ValueError("max_age_seconds cannot be negative")
        self.client=client; self.max_age_seconds=max_age_seconds

    def scrape(self, url: str) -> ScrapeResult:
        _validate_public_url(url)
        payload=self.client.scrape(url, profile=None, cookies=None, headers=None,
                                   zero_data_retention=True, max_age=self.max_age_seconds,
                                   only_main_content=True)
        if not isinstance(payload, dict): raise RuntimeError("Scraper returned an unsupported response")
        metadata=payload.get("metadata") or {}
        return ScrapeResult(payload.get("url",url), payload.get("markdown") or "",
                            metadata.get("statusCode"), metadata)

class FirecrawlHTTPClient:
    """Small Firecrawl v2 REST client with no browser profile, cookies, or persisted session."""
    def __init__(self, api_key: str, *, timeout_seconds: int = 45, base_url: str="https://api.firecrawl.dev"):
        if not api_key: raise ValueError("Firecrawl API key is required")
        if timeout_seconds <= 0: raise ValueError("timeout_seconds must be positive")
        self.api_key=api_key; self.timeout_seconds=timeout_seconds; self.base_url=base_url.rstrip("/")

    def scrape(self, url: str, **privacy_options):
        import json, socket, urllib.request
        from urllib.error import HTTPError, URLError
        _validate_public_url(url)
        host=urlsplit(url).hostname
        try:
            addresses={item[4][0] for item in socket.getaddrinfo(host,None)}
        except OSError as exc: raise RuntimeError("Target DNS resolution failed") from exc
        if not addresses: raise ScrapePolicyError("Target DNS returned no addresses")
        for address in addresses:
            try: ip=ip_address(address)
            except ValueError: continue
            if not ip.is_global: raise ScrapePolicyError("DNS resolved to a non-public address")
        payload={"url":url,"formats":["markdown"],"onlyMainContent":True,"maxAge":0,
                 "storeInCache":False,"zeroDataRetention":True,"redactPII":True,"lockdown":False,"checkPromptInjection":True,"threatProtection":{"riskScoreThreshold":75},"proxy":"basic"}
        request=urllib.request.Request(self.base_url+"/v2/scrape",data=json.dumps(payload).encode(),
            headers={"Authorization":f"Bearer {self.api_key}","Content-Type":"application/json"},method="POST")
        try:
            with urllib.request.urlopen(request,timeout=self.timeout_seconds) as response: data=json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            # Never echo response body; it can contain sensitive provider diagnostics.
            raise RuntimeError(f"Firecrawl request failed with HTTP {exc.code}") from exc
        except URLError as exc: raise RuntimeError("Firecrawl network request failed") from exc
        if not data.get("success",True): raise RuntimeError("Firecrawl reported an unsuccessful scrape")
        result=data.get("data",data)
        return {"url":result.get("metadata",{}).get("url",url),"markdown":result.get("markdown", ""),
                "metadata":result.get("metadata",{})}
