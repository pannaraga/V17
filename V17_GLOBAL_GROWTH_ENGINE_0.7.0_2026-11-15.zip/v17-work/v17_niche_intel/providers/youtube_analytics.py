from __future__ import annotations
from datetime import date, datetime, timezone
from math import isfinite

from ..services.metric_registry import plan_daily_analytics_query, plan_country_analytics_query
from ..services.provenance import build_provenance_record

READONLY_SCOPE = "https://www.googleapis.com/auth/yt-analytics.readonly"
MONETARY_READONLY_SCOPE = "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"


def classify_report_freshness(*, requested_end_date: date, records: list[dict]) -> dict:
    """Report observed coverage without pretending Analytics is real-time."""
    observed_days = [row.get("day") for row in records if row.get("day")]
    latest = max(observed_days) if observed_days else None
    if latest is None:
        status = "no_observed_data"
        lag_days = None
    else:
        latest_day = date.fromisoformat(str(latest))
        lag_days = max(0, (requested_end_date - latest_day).days)
        status = "current_through_requested_end" if lag_days == 0 else "partial_or_processing_lag"
    return {"status": status, "requested_end_date": requested_end_date.isoformat(),
        "latest_observed_report_date": latest, "lag_days": lag_days,
        "interpretation_limit": "YouTube Analytics processing is delayed; latest returned day is not a real-time watermark."}


class YouTubeAnalyticsProvider:
    """Owner-authorized, read-only YouTube Analytics API adapter."""
    def __init__(self, client):
        self.client = client

    def query_daily(self, *, channel_id: str, start_date: date, end_date: date,
                    metrics: str = "views,estimatedMinutesWatched,averageViewDuration,likes,comments",
                    dimensions: str = "day", video_ids: tuple[str, ...] = (), currency: str = "USD") -> dict:
        if not channel_id or start_date > end_date:
            raise ValueError("valid channel_id and date range are required")
        filters = None
        if video_ids:
            if len(set(video_ids)) != len(video_ids) or any(not item.strip() for item in video_ids):
                raise ValueError("video_ids must be unique non-empty identifiers")
            dimensions = "day,video" if len(video_ids) > 1 else "day"
            filters = "video==" + ",".join(video_ids)
        elif dimensions != "day":
            raise ValueError("daily channel reports support dimensions='day'; pass video_ids for day,video")
        plan = plan_daily_analytics_query(metrics, video_ids=video_ids, dimensions=dimensions)
        query_params = {"ids": f"channel=={channel_id}", "startDate": start_date.isoformat(),
            "endDate": end_date.isoformat(), "metrics": metrics, "dimensions": dimensions,
            "sort": "day", "currency": currency.upper(), "video_ids": list(video_ids)}
        query = self.client.reports().query(
            ids=f"channel=={channel_id}", startDate=start_date.isoformat(),
            endDate=end_date.isoformat(), metrics=metrics, dimensions=dimensions, sort="day", currency=currency.upper())
        if filters:
            query = query.filters(filters=filters)
        response = query.execute()
        fetched_at = datetime.now(timezone.utc)
        provenance = build_provenance_record(source_family="youtube_analytics_api",
            source_ref="reports.query", raw_payload=response, observed_at=fetched_at, fetched_at=fetched_at,
            request_params=query_params, transform_version="v17-analytics-normalizer-v1",
            sample_window={"start_date": start_date.isoformat(), "end_date": end_date.isoformat()})
        headers = response.get("columnHeaders", [])
        names = [header.get("name") for header in headers]
        rows = [dict(zip(names, row)) for row in response.get("rows", [])]
        if len(video_ids) == 1:
            for row in rows:
                row["video"] = video_ids[0]
        return {"columnHeaders": headers, "rows": response.get("rows", []), "records": rows,
                "kind": response.get("kind"), "channel_id": channel_id,
                "start_date": start_date.isoformat(), "end_date": end_date.isoformat(),
                "data_freshness": classify_report_freshness(requested_end_date=end_date, records=rows),
                "source": "owner_authorized_youtube_analytics", "private_data": True,
                "query_plan": {"endpoint": plan.endpoint, "metrics": list(plan.metrics),
                    "dimensions": list(plan.dimensions), "required_scopes": list(plan.required_scopes),
                    "registry_version": plan.registry_version}, "provenance": provenance}

    def query_country_economics(self, *, channel_id: str, start_date: date, end_date: date,
                                currency: str = "USD") -> dict:
        """Fetch first-party country-level views and estimated revenue; requires monetary read-only scope."""
        if not channel_id or start_date > end_date:
            raise ValueError("valid channel_id and date range are required")
        if len(currency) != 3 or not currency.isalpha():
            raise ValueError("currency must be a three-letter ISO currency code")
        plan = plan_country_analytics_query("views,estimatedRevenue")
        query_params = {"ids": f"channel=={channel_id}", "startDate": start_date.isoformat(),
            "endDate": end_date.isoformat(), "metrics": "views,estimatedRevenue",
            "dimensions": "country", "sort": "-estimatedRevenue", "currency": currency.upper()}
        response = self.client.reports().query(ids=f"channel=={channel_id}",
            startDate=start_date.isoformat(), endDate=end_date.isoformat(),
            metrics="views,estimatedRevenue", dimensions="country", sort="-estimatedRevenue",
            currency=currency.upper()).execute()
        fetched_at = datetime.now(timezone.utc)
        provenance = build_provenance_record(source_family="youtube_analytics_api",
            source_ref="reports.query", raw_payload=response, observed_at=fetched_at, fetched_at=fetched_at,
            request_params=query_params, transform_version="v17-analytics-normalizer-v1",
            sample_window={"start_date": start_date.isoformat(), "end_date": end_date.isoformat()})
        headers = response.get("columnHeaders", [])
        names = [header.get("name") for header in headers]
        records = []
        for values in response.get("rows", []):
            row = dict(zip(names, values))
            country = str(row.get("country") or "").upper()
            if len(country) != 2 or not country.isalpha():
                raise ValueError("YouTube Analytics returned an invalid country code")
            views = float(row.get("views") or 0)
            revenue = float(row.get("estimatedRevenue") or 0)
            if not isfinite(views) or not isfinite(revenue) or views < 0 or revenue < 0:
                raise ValueError("YouTube Analytics returned non-finite or negative country metrics")
            row["country"] = country
            row["rpm"] = revenue / views * 1000 if views > 0 else None
            row["currency"] = currency.upper()
            row["source"] = "owner_authorized_youtube_analytics"
            records.append(row)
        return {"columnHeaders": headers, "rows": response.get("rows", []), "records": records,
            "channel_id": channel_id, "start_date": start_date.isoformat(), "end_date": end_date.isoformat(),
            "currency": currency.upper(), "source": "owner_authorized_youtube_analytics",
            "private_data": True, "report_grain": "country_period",
            "query_plan": {"endpoint": plan.endpoint, "metrics": list(plan.metrics),
                "dimensions": list(plan.dimensions), "required_scopes": list(plan.required_scopes),
                "registry_version": plan.registry_version}, "provenance": provenance,
            "interpretation_limit": "Actual RPM for this channel and period only; not a competitor or future-market RPM forecast."}
