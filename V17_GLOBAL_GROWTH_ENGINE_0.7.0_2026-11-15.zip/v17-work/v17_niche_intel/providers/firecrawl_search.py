"""Public web SERP sampling through Firecrawl Search API (no browser/session state)."""
from __future__ import annotations

import json
from datetime import datetime, timezone
import urllib.error
import urllib.request
from typing import Any


class FirecrawlSearchProvider:
    def __init__(self, api_key: str, *, timeout_seconds: int = 30):
        if not api_key.strip(): raise ValueError("Firecrawl API key is required")
        if timeout_seconds <= 0: raise ValueError("timeout_seconds must be positive")
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds

    def search(self, keyword: str, *, country: str = "US", location: str | None = None,
               limit: int = 5) -> dict[str, Any]:
        if not keyword.strip(): raise ValueError("keyword must be non-empty")
        if not 1 <= limit <= 10: raise ValueError("SERP sample limit must be between 1 and 10")
        payload = {"query": keyword, "limit": limit, "sources": [{"type": "web"}],
            "country": country.upper(), "safe": True, "timeout": self.timeout_seconds * 1000,
            "scrapeOptions": {"formats": [{"type": "markdown"}], "onlyMainContent": True,
                "maxAge": 0, "storeInCache": False, "redactPII": True, "proxy": "basic"}}
        if location: payload["location"] = location
        request = urllib.request.Request("https://api.firecrawl.dev/v2/search",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
            method="POST")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                result = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            # Do not include request headers or credentials in errors.
            raise RuntimeError(f"Firecrawl Search returned HTTP {exc.code}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise RuntimeError("Firecrawl Search request failed") from exc
        data = result.get("data", result)
        items = data.get("web", data.get("results", [])) if isinstance(data, dict) else []
        normalized = []
        for item in items[:limit]:
            url = item.get("url")
            if not url: continue
            normalized.append({"url": str(url), "title": str(item.get("title") or ""),
                "description": str(item.get("description") or item.get("snippet") or "")})
        return {"status": "ok" if normalized else "no_data", "keyword": keyword,
            "country": country.upper(), "location": location, "results": normalized,
            "observed_at": datetime.now(timezone.utc).isoformat(),
            "source": "firecrawl_search", "cache_disabled": True, "proxy_mode": "basic"}
