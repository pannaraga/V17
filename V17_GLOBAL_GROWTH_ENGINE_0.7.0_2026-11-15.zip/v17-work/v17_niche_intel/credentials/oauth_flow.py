from __future__ import annotations
import secrets
import time
from dataclasses import dataclass
from urllib.parse import urlparse, parse_qs

ANALYTICS_READONLY_SCOPE = "https://www.googleapis.com/auth/yt-analytics.readonly"
ANALYTICS_MONETARY_READONLY_SCOPE = "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"
YOUTUBE_READONLY_SCOPE = "https://www.googleapis.com/auth/youtube.readonly"

@dataclass(frozen=True, slots=True)
class OAuthAuthorization:
    authorization_url: str
    state: str
    redirect_uri: str

class GoogleOAuthConsentFlow:
    """Single-use state + PKCE OAuth flow; caller must bind callback to the same local session."""
    def __init__(self, client_config: dict, *, redirect_uri: str="http://127.0.0.1:8765/oauth2/callback"):
        parsed=urlparse(redirect_uri)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"}:
            if parsed.scheme != "https": raise ValueError("OAuth redirect must be HTTPS or loopback HTTP")
        self.client_config=client_config; self.redirect_uri=redirect_uri; self._pending={}

    def begin(self, *, scopes: tuple[str,...]=(ANALYTICS_READONLY_SCOPE,)) -> OAuthAuthorization:
        allowed = {ANALYTICS_READONLY_SCOPE, ANALYTICS_MONETARY_READONLY_SCOPE, YOUTUBE_READONLY_SCOPE}
        if not scopes or not set(scopes).issubset(allowed):
            raise ValueError("Only approved read-only YouTube and Analytics OAuth scopes are allowed")
        now = time.monotonic()
        self._pending = {key: value for key, value in self._pending.items() if value[3] > now}
        if len(self._pending) >= 10:
            raise RuntimeError("Too many pending OAuth consent attempts; complete or restart an existing flow")
        try: from google_auth_oauthlib.flow import Flow
        except ImportError as exc: raise RuntimeError("Install OAuth extra: pip install -e '.[oauth]'") from exc
        verifier=secrets.token_urlsafe(64); state=secrets.token_urlsafe(32)
        flow=Flow.from_client_config(self.client_config, scopes=list(scopes), state=state,
                                     redirect_uri=self.redirect_uri, code_verifier=verifier)
        url,_=flow.authorization_url(access_type="offline", prompt="consent", include_granted_scopes="false")
        self._pending[state]=(flow,verifier,frozenset(scopes),time.monotonic()+600)
        return OAuthAuthorization(url,state,self.redirect_uri)

    def complete(self, *, state: str, authorization_response: str):
        pending=self._pending.pop(state,None)
        if pending is None: raise ValueError("OAuth state is missing, expired, or already used")
        flow,_,scopes,expires_at=pending
        if time.monotonic() > expires_at:
            raise ValueError("OAuth state has expired; start a new consent flow")
        callback = urlparse(authorization_response)
        expected = urlparse(self.redirect_uri)
        if (callback.scheme, callback.hostname, callback.port, callback.path) != (expected.scheme, expected.hostname, expected.port, expected.path):
            raise ValueError("OAuth callback redirect URI does not match the registered redirect URI")
        if callback.username or callback.password or callback.fragment:
            raise ValueError("OAuth callback URL contains forbidden components")
        params = parse_qs(callback.query)
        callback_state=params.get("state",[None])[0]
        if callback_state != state: raise ValueError("OAuth callback state mismatch")
        if params.get("error"):
            raise PermissionError("Google OAuth consent was denied or cancelled")
        if not params.get("code"):
            raise ValueError("OAuth callback is missing the authorization code")
        flow.fetch_token(authorization_response=authorization_response)
        credentials=flow.credentials
        granted=frozenset(credentials.scopes or ())
        if not scopes.issubset(granted): raise PermissionError("Google did not grant all requested read-only scopes")
        return credentials
