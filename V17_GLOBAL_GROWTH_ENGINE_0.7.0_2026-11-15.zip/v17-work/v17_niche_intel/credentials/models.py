from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class APIKeyCredential:
    credential_id: str
    provider: str
    project_id: str
    use_case: str
    environment: str
    secret_ref: str


@dataclass(frozen=True)
class OAuthAccount:
    account_id: str
    account_label: str
    access_token_ref: str
    refresh_token_ref: str
    scopes: frozenset[str]
    channel_ids: frozenset[str]
    expires_at: str | None = None
