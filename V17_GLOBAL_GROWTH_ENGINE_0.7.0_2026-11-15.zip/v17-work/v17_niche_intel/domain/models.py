from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from .enums import EvidenceStatus

@dataclass(frozen=True, slots=True)
class Evidence:
    """One observed fact, with provenance and quality metadata."""
    metric: str
    value: Any | None
    source_family: str
    observed_at: datetime
    status: EvidenceStatus
    quality: float = 1.0
    source_ref: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.metric.strip():
            raise ValueError("metric must be non-empty")
        if not self.source_family.strip():
            raise ValueError("source_family must be non-empty")
        if self.observed_at.tzinfo is None or self.observed_at.utcoffset() is None:
            raise ValueError("observed_at must include timezone information")
        if not 0.0 <= float(self.quality) <= 1.0:
            raise ValueError("quality must be between 0 and 1")
        if self.status == EvidenceStatus.OK and self.value is None:
            raise ValueError("successful evidence requires a value")
        if self.status != EvidenceStatus.OK and self.value is not None:
            raise ValueError("non-successful evidence must not carry a value")
