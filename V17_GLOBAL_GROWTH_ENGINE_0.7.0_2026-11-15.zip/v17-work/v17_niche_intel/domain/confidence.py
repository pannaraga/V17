from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable
from .enums import ConfidenceLevel, EvidenceStatus
from .models import Evidence

@dataclass(frozen=True, slots=True)
class ConfidenceResult:
    level: str
    independent_source_count: int
    quality_index: float
    source_families: tuple[str, ...]

def assess_confidence(evidence: Iterable[Evidence], *, now: datetime | None = None,
                      freshness_half_life_days: float = 30.0) -> ConfidenceResult:
    if freshness_half_life_days <= 0:
        raise ValueError("freshness_half_life_days must be positive")
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("now must include timezone information")
    valid = [item for item in evidence if item.status == EvidenceStatus.OK and item.value is not None]
    if not valid:
        return ConfidenceResult(ConfidenceLevel.LOW, 0, 0.0, ())
    family_quality: dict[str, float] = {}
    for item in valid:
        age_days = max(0.0, (reference - item.observed_at).total_seconds() / 86400)
        freshness = 0.5 ** (age_days / freshness_half_life_days)
        adjusted = max(0.0, min(1.0, item.quality)) * freshness
        family_quality[item.source_family] = max(family_quality.get(item.source_family, 0.0), adjusted)
    families = tuple(sorted(family_quality))
    quality_index = round(sum(family_quality.values()) / len(family_quality), 4)
    count = len(families)
    if count >= 3 and quality_index >= 0.75:
        level = ConfidenceLevel.HIGH
    elif count >= 2 and quality_index >= 0.50:
        level = ConfidenceLevel.MEDIUM
    else:
        level = ConfidenceLevel.LOW
    return ConfidenceResult(level, count, quality_index, families)
