from __future__ import annotations
import re

_ISO_DURATION = re.compile(
    r"^P(?:(?P<days>\d+)D)?(?:T(?:(?P<hours>\d+)H)?(?:(?P<minutes>\d+)M)?(?:(?P<seconds>\d+(?:\.\d+)?)S)?)?$"
)

def parse_iso_duration(value: str) -> int:
    match = _ISO_DURATION.fullmatch(value or "")
    if not match:
        raise ValueError(f"Invalid ISO-8601 duration: {value!r}")
    parts = match.groupdict()
    if not any(parts.values()):
        raise ValueError(f"Invalid empty ISO-8601 duration: {value!r}")
    total = (int(parts["days"] or 0) * 86400 + int(parts["hours"] or 0) * 3600
             + int(parts["minutes"] or 0) * 60 + float(parts["seconds"] or 0))
    return int(total)
