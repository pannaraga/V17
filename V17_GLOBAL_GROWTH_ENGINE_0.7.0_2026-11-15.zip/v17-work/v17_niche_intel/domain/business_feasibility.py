"""Evidence-aware channel operating feasibility and policy-risk flags.

This module scores only explicit operator-supplied constraints. It is a planning
heuristic, not a monetization, legal, copyright, or growth prediction.
"""
from __future__ import annotations

from math import isfinite
from typing import Any, Mapping

_REQUIRED = ("weekly_hours", "hours_per_video", "target_videos_per_week", "repeatable_idea_count")
_REVIEW_STATES = {"complete", "not_reviewed", "flagged", "unknown"}


def _number(data: Mapping[str, Any], key: str, *, minimum: float = 0.0) -> float:
    value = data[key]
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)):
        raise ValueError(f"{key} must be a finite number")
    value = float(value)
    if value < minimum:
        raise ValueError(f"{key} must be >= {minimum}")
    return value


def evaluate_channel_feasibility(inputs: Mapping[str, Any]) -> dict[str, Any]:
    """Estimate publishing capacity, repeatable supply, and readiness flags.

    Required numeric inputs are deliberately not defaulted. An absent input
    produces ``insufficient_data`` instead of a neutral score.
    """
    missing = [key for key in _REQUIRED if key not in inputs or inputs[key] is None]
    if missing:
        return {"status": "insufficient_data", "business_feasibility_score": None,
                "risk_resilience_score": None, "missing_inputs": missing,
                "risk_flags": [], "assumptions": ["No missing input is neutral-filled."]}

    weekly_hours = _number(inputs, "weekly_hours")
    hours_per_video = _number(inputs, "hours_per_video", minimum=0.000001)
    target = _number(inputs, "target_videos_per_week", minimum=0.000001)
    ideas = _number(inputs, "repeatable_idea_count")
    capacity = weekly_hours / hours_per_video
    gap = max(0.0, target - capacity)
    capacity_ratio = min(1.0, capacity / target)
    runway_weeks = ideas / target

    routes = inputs.get("monetization_routes", [])
    if not isinstance(routes, list) or any(not isinstance(x, str) or not x.strip() for x in routes):
        raise ValueError("monetization_routes must be a list of non-empty strings")
    routes = sorted({x.strip().lower() for x in routes})

    reviews: dict[str, str] = {}
    risk_flags: list[str] = []
    for key, flag in (("copyright_review", "copyright"), ("reused_content_review", "reused_content")):
        state = str(inputs.get(key, "unknown")).lower()
        if state not in _REVIEW_STATES:
            raise ValueError(f"{key} must be one of {sorted(_REVIEW_STATES)}")
        reviews[flag] = state
        if state == "not_reviewed" or state == "unknown":
            risk_flags.append(f"{flag}_not_reviewed")
        elif state == "flagged":
            risk_flags.append(f"{flag}_risk_flagged")

    if gap > 0:
        risk_flags.append("publishing_capacity_gap")
    if runway_weeks < 8:
        risk_flags.append("limited_repeatable_content_supply")
    if not routes:
        risk_flags.append("monetization_route_not_defined")

    capacity_points = 40.0 * capacity_ratio
    supply_points = 25.0 * min(1.0, runway_weeks / 12.0)
    monetization_points = 15.0 if routes else 0.0
    review_points = sum(10.0 if state == "complete" else 4.0 if state in {"not_reviewed", "unknown"} else 0.0
                        for state in reviews.values())
    score = round(capacity_points + supply_points + monetization_points + review_points, 2)
    risk_resilience = round(100.0 - sum(
        25.0 if flag.endswith("risk_flagged") else
        15.0 if flag.endswith("not_reviewed") else
        10.0 if flag == "publishing_capacity_gap" else
        8.0 if flag == "limited_repeatable_content_supply" else 5.0
        for flag in risk_flags
    ), 2)
    risk_resilience = max(0.0, risk_resilience)

    return {
        "status": "ok", "business_feasibility_score": score,
        "risk_resilience_score": risk_resilience,
        "capacity_videos_per_week": round(capacity, 3),
        "capacity_gap_per_week": round(gap, 3),
        "capacity_coverage_ratio": round(capacity_ratio, 4),
        "repeatable_content_runway_weeks": round(runway_weeks, 2),
        "monetization_routes": routes, "review_states": reviews,
        "risk_flags": sorted(risk_flags),
        "score_components": {"capacity": round(capacity_points, 2),
                             "content_supply": round(supply_points, 2),
                             "monetization_route": monetization_points,
                             "rights_review_readiness": review_points},
        "assumptions": [
            "Production hours per video are treated as the complete recurring workload.",
            "Idea count is a planning proxy, not proof of audience demand or originality.",
            "Review completion is an operator attestation, not legal advice or platform approval.",
            "Scores are heuristic decision aids, not probabilities or outcome guarantees.",
        ],
    }
