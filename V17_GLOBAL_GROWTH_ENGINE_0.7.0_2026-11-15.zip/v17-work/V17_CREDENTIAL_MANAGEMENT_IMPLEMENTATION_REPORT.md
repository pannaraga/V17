# V17 — Consolidated Implementation & Verification Report

**Date:** 2026-11-11  
**Status:** Core implementation and local verification complete; live credential/provider acceptance remains operator-dependent.

## Delivered

### Research and market intelligence
- Market Entry, Existing Channel, and Both service modes.
- Read-only YouTube Data API provider with balanced relevance/date sampling, deduplication, video detail enrichment, and format classification.
- Google Trends adapter with language locale selection and relative-interest semantics.
- Firecrawl Search collector for public web SERPs by keyword/country/location, timestamped persistence, historical rank volatility, and competitor-domain overlap.
- Public YouTube comment sampling (top-level text only, max five sampled videos per research run), PII masking, and aggregate pain-point extraction without persisting raw comments or author metadata.
- 30-day public YouTube API-derived data retention with automatic purge at research start and an operator-triggered daily purge command; private owner Analytics and Firecrawl SERP snapshots remain in separate tables.
- Search intent classification (English and Indonesian heuristics), topic clustering, competitor overlap, timestamped SERP rank volatility, content cannibalization flags, seasonality, country/language segmentation, content freshness, audience pain-point term discovery, provenance, freshness/confidence assessment, historical video snapshots, and experiment validation.
- Evidence-bundle analysis via `MarketIntelligenceService` and `v17 intelligence evidence.json`.
- Thumbnail metadata analysis from local image files (dimensions, RGB channel statistics, brightness/contrast proxy).
- Audio signal analysis from local audio files (sample peak, RMS, clipping ratio, silence ratio, sample rate, duration).
- Markdown, JSON, and CSV research exports.

### Channel operating feasibility (added in final audit)
- Added `domain/business_feasibility.py` and exposed it through `MarketIntelligenceService` using optional `channel_constraints`.
- Computes operator-input publishing capacity, weekly capacity gap, repeatable-content runway, monetization-route readiness, and rights-review readiness.
- Emits separate heuristic business-feasibility and risk-resilience scores with explicit risk flags and score components.
- Missing required inputs return `insufficient_data`; no neutral values are inserted. Rights-review states are operator attestations, not legal advice or platform approval.

### Existing-channel analytics
- Google OAuth consent URL creation using PKCE, single-use state, 10-minute expiry, exact redirect URI validation, provider error validation, approved read-only YouTube/Analytics scopes, and a loopback-only callback listener for local dashboard sessions (manual URL fallback for hosted deployments).
- OAuth accounts explicitly bound to authorized channel IDs and scopes.
- Client ID stored as non-secret metadata; client secret and access/refresh tokens stored in the OS keyring.
- Refresh token workflow, reauthorization status on invalid/revoked grants, local disable/enable, and explicit remote token revocation.
- YouTube Analytics daily channel report integration. Single-video reports use `dimensions=day` plus a video filter; multiple video IDs can use `dimensions=day,video` plus an explicit video filter.
- Private Analytics data stored in separate private tables and kept out of public competitor evidence.
- Validated CSV import rejects malformed and non-finite numeric metrics.

### Credential and quota safety
- Multiple API keys and OAuth identities, project/use-case/environment routing, secret references, and keyring/environment secret stores.
- Automatic quota metering at provider request boundaries: `search.list` = 1 unit in its separate 100-calls/day Search Queries bucket; `videos.list`, `i18nRegions.list`, and other read endpoints = 1 unit in the general 10,000-units/day bucket. Both are project-wide and reset at midnight Pacific Time.
- Quota is shared per Google Cloud Project per day across all keys and use cases.
- Invalid API keys are detected from Google error responses, marked invalid, and retried only with another active key in the same project route.
- Quota exhaustion is surfaced; no cross-project fallback is allowed for a registered route.
- Legacy per-use-case quota rows migrate to project-wide usage by summing historical use.
- Environment API keys require `YOUTUBE_API_PROJECT_ID`; unmetered environment keys are not silently used.
- Dashboard inventory shows credential metadata and quota without displaying secret values.
- AES-256-GCM encrypted backup/restore packages SQLite plus referenced secret material, remaps references into a destination keyring, refuses overwrite, verifies SQLite integrity, and sets restrictive backup file permissions.
- `doctor` performs a keyring write/read/delete health probe without exposing the probe value.

### Privacy-first incognito scraping
- Public HTTPS targets only, standard HTTPS port only, DNS resolution checks, and rejection of private/reserved target IPs.
- No reused cookies, authentication headers, or browser profiles.
- Cache disabled, zero-data-retention request, PII redaction, prompt-injection checks, and basic proxy mode. Lockdown is disabled because Firecrawl lockdown is cache-only and would prevent a fresh network fetch.
- No CAPTCHA bypass, login/session scraping, stealth proxy mode, rate-limit circumvention, or access-control bypass.
- CLI: `v17 scrape https://public.example/path`.

### Interfaces and operations
- Streamlit dashboard for research, credential inventory, OAuth setup, Analytics retrieval, and advanced evidence JSON analysis.
- Signal Atelier UI refresh: branded editorial hero, Overview / Connections / Public Intelligence / Advanced Lab navigation, and conditional channel-only research inputs.
- Light / Dark / System theme selector with semantic tokens, responsive layouts, visible keyboard focus, reduced-motion handling, and progressive disclosure for detailed JSON.
- CLI for research, Analytics retrieval, CSV import, evidence-bundle analysis, public SERP collection, privacy-first scraping, snapshot, encrypted backup/restore, report, compare/history listing, and doctor checks.
- Architecture and method documentation updated.

## Verification evidence

Executed from the project root:

```bash
python -m pytest -q
python -m compileall -q v17_niche_intel tests
python -m pip install -e . --no-deps --no-build-isolation
v17 --help
v17 intelligence /tmp/v17-evidence.json --output /tmp/v17-intelligence-report.json
v17 --database /tmp/v17-smoke.sqlite3 research "cara membuat kopi" --country ID --language id --mode market_entry --limit 5 --output /tmp/v17-research.json
```

Results:
- **135 tests passed** (including five UI theme tests).
- `compileall` passed.
- Editable package installation passed.
- CLI help passed.
- Evidence-bundle CLI smoke test passed and produced JSON output.
- Market Entry CLI smoke test passed and produced a persisted research JSON report without requiring live credentials.
- Legacy project quota migration test passed.
- Incognito scraping and Firecrawl Search tests passed with mocked API responses; no live Firecrawl scrape or search was performed. Firecrawl zero-data-retention must be enabled on the operator's account for this request option to succeed.
- No live Google API or OAuth request was performed; no real user credential was supplied. No Firecrawl API key or ZDR account activation was supplied for a live collection test.
- Streamlit is not installed in this execution environment, so the dashboard was syntax-compiled but not launched interactively.
- `ruff` is not installed, so linting was not run.
- `doctor` reported the local OS keyring backend as unavailable in this execution container; persistent keyring operations must be verified on the operator's target machine.

## Explicit operational limits / next acceptance gates

1. **OAuth callback deployment:** local loopback callback listener is implemented and tested with a mocked flow. Hosted HTTPS callback deployment, production domain configuration, and live Google OAuth acceptance still require the operator's Google OAuth client and deployment environment.
2. **Real credentials:** user-owned API keys, Google Cloud Project IDs, OAuth client configuration, and channel authorization must be entered by the operator. Live OAuth consent, token refresh, revocation, and Analytics report combinations require an operator test with their own Google account.
3. **Competitor intelligence automation:** Firecrawl Search collection and historical SERP volatility/competitor-domain overlap are implemented. Repeated collection is operator-triggered; no scheduler is configured. Content-plan cannibalization still requires the channel's content inventory and intent assignments.
4. **Media benchmarks:** thumbnail and audio analysis run on local files the operator owns or is authorized to analyze. No YouTube video/audio is downloaded; OCR/face detection, LUFS, true-peak oversampling, and SNR measurement are not implemented.
5. **Audience research:** public top-level YouTube comments are sampled through the API (up to five videos per research run); author metadata and raw comments are not stored. Additional survey/comment text can be supplied as evidence. No demographic attributes are inferred.
6. **Historical and experiments:** snapshots are collected when `v17 snapshot <run_id>` is run; no scheduler is configured. Schedule `v17 purge-expired` daily to enforce retention while idle. Experiment analysis requires baseline/treatment samples and is directional, not proof of causality.
7. **Production operations:** encrypted backup/restore and local keyring health probes are implemented, but automated off-site backup scheduling, deployed secret-vault monitoring, CI/CD deployment, and production monitoring have not been configured or tested.
8. **Streamlit runtime:** install `pip install -e '.[all]'`, launch `streamlit run v17_niche_intel/dashboard.py`, then test the dashboard in the target local environment.

## Policy boundary

All credentials may belong to the same operator, but ownership does not multiply Google quota. Multiple API keys in one Cloud Project share that project's quota. Different project routes must represent genuinely distinct use cases/environments; quota exhaustion pauses that route. OAuth accounts do not multiply YouTube Data API quota. Public scraping remains subject to source terms, robots directives, rate limits, and platform developer policies.


### UI/UX verification limits
- Theme CSS and dashboard Python syntax were verified.
- Light/dark foreground and background token pairs were checked mathematically; rendered browser contrast and full WCAG conformance are not claimed.
- Streamlit is not installed in this execution environment, so interactive runtime, screenshot, and cross-browser visual QA remain unverified. Install the `app` extra and run `streamlit run v17_niche_intel/dashboard.py` in the target environment for that final gate.


## Global market and decision-evidence hardening — 2026-11-13 addendum

- Added dynamic YouTube-supported region discovery via `i18nRegions.list`, CLDR country-language/currency enrichment, representative timezone metadata, and explicit fallback metadata states. The curated fallback remains 50 profiles across 37 countries when live discovery is unavailable.
- Added YouTube `relevanceLanguage` filtering hints, script-specific Chinese language codes, translation-target mapping, and always-on native-review status. Machine translation is not presented as culturally validated.
- Connected source-linked component evidence to the four-layer scoring path. Enforced timezone-aware provenance, 0–100 normalized scores, confidence, freshness, source-family aggregation, and strict first-party RPM provenance.
- Added creator-fit mandatory evidence (native-reviewed language/cultural fluency and policy/rights resilience), a 50/100 policy-rights hold threshold, source-verified market-eligibility gates, and full four-layer coverage for ranking.
- Added quota preflight/reservation, separate `search.list` (1 unit/call, 100 calls/day default) and general API (10,000 units/day default) quota buckets, Pacific-Time quota reset accounting, conservative legacy quota migration, approved-limit environment configuration, project quota exhaustion stop behavior, evidence JSON upload/schema, layer-level dashboard display, expanded KPI/formula documentation, and reusable portfolio/forecast/experiment KPI calculators.
- Verification after this addendum: **201 pytest tests passed**, `compileall` passed, editable install passed, CLI help passed, strategy CLI smoke passed, and market-entry CLI smoke passed with providers correctly marked `not_configured`.
- Live Google API/OAuth, Trends, Streamlit visual/keyboard QA, deep-translator runtime, native-speaker review, and Scrapling MCP remain unverified because their credentials/runtime/server are not connected in this environment.


## Global localization and discovery strategy hardening — 2026-11-13 addendum

- Added `localized_query_variants` to the global evidence contract, JSON Schema, example template, dashboard upload parser, and global discovery service. Operators can provide up to 12 query variants per country-language market.
- A fresh native-reviewed query takes precedence and carries `source_ref`, timezone-aware `reviewed_at`, and optional `reviewer_ref`; stale review is downgraded and cannot be reported as native-reviewed. Operator-curated but unreviewed variants remain explicitly unverified.
- The service uses the first curated variant for the current quota-bounded search and Trends request, preserves the original seed and other variants in the output, and skips unnecessary machine translation when curated queries exist. It does not claim to search every dialect/variant in one pass.
- Hardened coverage-threshold validation against booleans, NaN, infinity, and out-of-range values; hardened global market, query-order, limit, and review-status validation.
- Added `docs/YOUTUBE_DISCOVERY_OPTIMIZATION_FRAMEWORK.md`: Search vs Browse/Suggested/Shorts distinction, surface-specific KPI dictionary, diagnostic matrix, content-to-intent workflow, retention/packaging loop, and controlled experiment protocol.
- Verification after this addendum: **212 pytest tests passed**; `compileall`, JSON parsing, JSON Schema Draft 2020-12 validation of the schema and example template, editable install, CLI help, strategy CLI smoke, and no-credential market-entry smoke passed.
- Streamlit, Google API client, pytrends, deep-translator, and Ruff are not installed in this environment. Live provider requests, Streamlit interaction/visual/keyboard QA, live native-language review, and lint remain unverified.
